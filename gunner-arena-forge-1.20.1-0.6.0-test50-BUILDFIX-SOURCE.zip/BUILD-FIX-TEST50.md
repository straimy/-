# test50 build-fix

Build-only hardening after first real GitHub Actions ForgeGradle failure.

Changes:
- ForgeGradle declaration aligned with official 47.4.10 MDK (`plugins` DSL, `[6.0,6.2)`).
- Foojay toolchain resolver 0.7.0 added to root and client UI settings, matching official MDK.
- Java 17 toolchain retained.
- `copyIdeResources = true` added.
- Server run uses `--nogui`.

This does NOT claim the compile error is fixed until GitHub Actions passes.

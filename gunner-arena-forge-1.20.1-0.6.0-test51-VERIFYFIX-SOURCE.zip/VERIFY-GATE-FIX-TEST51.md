# test51 verify-source fix

This revision fixes the source gate after the test50 ForgeGradle scaffold was changed.

The previous test50 archive failed at `[1/85] Metadata/build scaffold` because
`verify-source.sh` still expected the old test49 version and old `buildscript`
ForgeGradle declaration.

Changes:
- source gate expects `0.6.0-test51-verifyfix`;
- integration manifest release line matches;
- ForgeGradle assertion checks the new official `plugins` DSL declaration;
- no gameplay logic changed.

This revision is not considered Forge-compiled until GitHub Actions reaches and
passes the real `Build Forge Core` task.

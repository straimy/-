#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo '[1/85] Metadata/build scaffold'
grep -q '^minecraft_version=1.20.1$' gradle.properties
grep -q '^forge_version=47.4.10$' gradle.properties
grep -q '^mod_version=0.6.0-test51-verifyfix$' gradle.properties
grep -q "id 'net.minecraftforge.gradle' version '\[6.0,6.2\)'" build.gradle
grep -q 'JavaLanguageVersion.of(17)' build.gradle

echo '[2/85] Server-only display compatibility'
grep -q 'displayTest="IGNORE_SERVER_VERSION"' src/main/resources/META-INF/mods.toml

echo '[3/85] No legacy dynamic-proxy command registration'
! grep -R -nE 'Proxy\.newProxyInstance|InvocationHandler' src/main/java

echo '[4/85] No global destructive entity kill command'
! grep -R -nF 'kill @e' src/main/java src/main/resources

echo '[5/85] Typed Brigadier registration'
grep -R -q 'RegisterCommandsEvent' src/main/java
grep -R -q 'CommandDispatcher<CommandSourceStack>' src/main/java

echo '[6/85] CG BETA trigger and adapter'
grep -R -q 'new BlockPos(44, 63, 3)' src/main/java
grep -R -q '#cg_chunk_count' src/main/java

echo '[7/85] No physical-client imports in Core'
! grep -R -nE '^import net\.minecraft\.client\.|^import net\.minecraftforge\.client\.' src/main/java

echo '[8/85] Pure Java 17 compile'
rm -rf .verify-pure
mkdir -p .verify-pure/classes
find src/main/java/arena -type f -name '*.java' ! -path '*/forge/*' ! -name 'GunnerArenaMod.java' | sort > .verify-pure/sources.txt
javac --release 17 -d .verify-pure/classes @.verify-pure/sources.txt

echo '[9/85] Runtime doctor present'
grep -R -q 'GA DOCTOR' src/main/java/arena/forge/GunnerCommands.java
grep -R -q 'ForgeRegistries.ITEMS.containsKey' src/main/java/arena/forge/GunnerCommands.java

echo '[10/85] Pre-auth command/interact fence'
grep -q 'public void onCommand(CommandEvent event)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'root.equals("login") || root.equals("register")' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'public void onPickup(EntityItemPickupEvent event)' src/main/java/arena/forge/ArenaRuntime.java

echo '[11/85] Safe region source integration'
grep -q 'Commands.literal("spawnregion")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'safeRegions.isSafe(victim)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'safe-regions.properties' src/main/java/arena/forge/ArenaRuntime.java

echo '[12/85] Confirmed flare crash quarantine'
grep -q 'jeg:flare_gun' src/main/java/arena/weapon/WeaponSafetyPolicy.java
grep -q 'FlareProjectileEntity' src/main/java/arena/weapon/WeaponSafetyPolicy.java
grep -q 'WeaponSafetyPolicy.isQuarantined' src/main/java/arena/forge/GunnerCommands.java

echo '[13/85] Quarantine diagnostics command'
grep -q 'literal("quarantine")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'debugQuarantine' src/main/java/arena/forge/GunnerCommands.java

echo '[14/85] Safe region visualization'
grep -q 'literal("show")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'tickVisualization' src/main/java/arena/forge/SafeRegionService.java
grep -q 'ParticleTypes.END_ROD' src/main/java/arena/forge/SafeRegionService.java

echo '[15/85] Hazard runtime diagnostics'
grep -q 'literal("status")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'debugHazards' src/main/java/arena/forge/GunnerCommands.java

echo '[16/85] KVICloud TAB/name display prefixes'
grep -q 'onNameFormat(PlayerEvent.NameFormat event)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'onTabListNameFormat(PlayerEvent.TabListNameFormat event)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'refreshTabListName' src/main/java/arena/forge/ArenaRuntime.java

echo '[17/85] Safe-zone projectile/JEG fence'
grep -q 'onEntityJoinLevel(EntityJoinLevelEvent event)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'projectile.getOwner() instanceof ServerPlayer owner' src/main/java/arena/forge/ArenaRuntime.java

echo '[18/85] Java 17 build enforcement'
grep -q 'Refusing to build Forge 1.20.1 with Java' build-linux.sh
grep -q 'JAVA_MAJOR' build-linux.sh

echo '[19/85] Dedicated runtime preflight'
test -x dedicated-preflight.sh
grep -q 'DEDICATED_PREFLIGHT_OK' dedicated-preflight.sh
grep -q 'Embeddium' dedicated-preflight.sh

echo '[20/85] Single Forge safe-region adapter'
COUNT_SAFE_ADAPTERS="$(grep -R --include='*.java' -l 'public final class SafeRegionService' src/main/java/arena/forge | wc -l | tr -d ' ')"
[[ "$COUNT_SAFE_ADAPTERS" == "1" ]] || { echo "Expected exactly one Forge SafeRegionService, found $COUNT_SAFE_ADAPTERS" >&2; exit 1; }

echo '[21/85] Runtime smoke gate present'
test -x runtime-smoke.sh
grep -q 'RUNTIME_SMOKE_PASS' runtime-smoke.sh
grep -q 'FlareProjectileEntity' runtime-smoke.sh

echo '[22/85] Required runtime files present'  
test -f BUILD-AND-RUNTIME-TEST.md
test -f AUTH-RUNTIME-TEST13.md
test -f src/main/resources/META-INF/mods.toml

echo '[23/85] Confirmed flare projectile hard fence'
grep -q 'isQuarantinedProjectile(projectile)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'ttv.migami.jeg.entity.projectile.FlareProjectileEntity' src/main/java/arena/forge/ArenaRuntime.java

echo '[24/85] Runtime hardening notes present'
test -f CRASH-FENCE-TEST23.md

echo '[25/85] CI Forge build gate present'
test -f .github/workflows/forge-build.yml
grep -q "actions/setup-java@v4" .github/workflows/forge-build.yml
grep -q "java-version: '17'" .github/workflows/forge-build.yml
grep -q './build-forge17.sh' .github/workflows/forge-build.yml

echo '[26/85] CI build notes present'
test -f CI-FORGE-BUILD-TEST24.md

echo '[27/85] Java 17 resolver wrapper'
test -x java17-env.sh
test -x build-forge17.sh
grep -q 'JAVA_HOME_17' java17-env.sh
grep -q 'source "$ROOT/java17-env.sh"' build-forge17.sh

echo '[28/85] Forge build handoff notes'
test -f FORGE-BUILD-HANDOFF-TEST25.md

echo '[29/85] Stage-1 runtime evidence command'
grep -q 'literal("stage1")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'STATIC_RUNTIME_READY' src/main/java/arena/forge/GunnerCommands.java

echo '[30/85] Stage-1 evidence notes'
test -f STAGE1-EVIDENCE-TEST26.md

echo '[31/85] Stage-1 proof harness'
test -x stage1-proof.sh
grep -q 'JAR_BUILD_PROOF_OK' stage1-proof.sh
grep -q 'runtime-smoke.sh' stage1-proof.sh

echo '[32/85] Stage-1 proof documentation'
test -f STAGE1-PROOF-TEST27.md
grep -q 'does not deploy' STAGE1-PROOF-TEST27.md

echo '[33/85] Safe-region knockback fence'
grep -q 'onKnockBack(LivingKnockBackEvent event)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'safeRegions.isSafe(player)' src/main/java/arena/forge/ArenaRuntime.java

echo '[34/85] Void recovery fence'
grep -q 'needsVoidRecovery(player)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'recoverToLobby(server, player)' src/main/java/arena/forge/ArenaRuntime.java


echo '[35/85] Auth/session race hardening'
grep -q 'auth.isAuthenticated(player) && auth.isInitialized(player)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'Predicate<ServerPlayer> eligible' src/main/java/arena/forge/player/ArenaPlayerManager.java

echo '[36/85] Live Core hardening notes'
test -f LIVE-HARDENING-TEST29.md

echo '[37/85] Death reward idempotency guard'
grep -q 'class DeathEventGuard' src/main/java/arena/combat/DeathEventGuard.java
grep -q 'deathGuard.tryAccept' src/main/java/arena/forge/ArenaRuntime.java

echo '[38/85] Death guard lifecycle cleanup'
grep -q 'deathGuard.onRespawn' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'deathGuard.forget' src/main/java/arena/forge/ArenaRuntime.java

echo '[39/85] Assist history logout cleanup'
grep -q 'damage.forgetAttacker(player.getUUID())' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'public void forgetAttacker(UUID attacker)' src/main/java/arena/combat/DamageTracker.java

echo '[40/85] Assist history expiry pruning'
grep -q 'damage.pruneExpired(serverTick)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'public int pruneExpired(long nowTick)' src/main/java/arena/combat/DamageTracker.java

echo '[41/85] Round-boundary combat evidence reset'
[[ "$(grep -c 'damage.clearAll();' src/main/java/arena/forge/ArenaRuntime.java)" -ge 3 ]]
[[ "$(grep -c 'deathGuard.clear();' src/main/java/arena/forge/ArenaRuntime.java)" -ge 3 ]]

echo '[42/85] Overkill stat clamp + assist readiness'
grep -q 'Math.min(Math.max(0.0, event.getAmount()), Math.max(0.0F, victim.getHealth()))' src/main/java/arena/forge/ArenaRuntime.java
grep -q '!isArenaReady(assistant)' src/main/java/arena/forge/ArenaRuntime.java

echo '[43/85] Damage tracker behavioral self-test'
javac --release 17 -cp .verify-pure/classes -d .verify-pure/classes verify-tests/DamageTrackerSelfTest.java
java -cp .verify-pure/classes DamageTrackerSelfTest | grep -q 'DAMAGE_TRACKER_SELF_TEST_OK'
test -f LIVE-CORE-HARDENING-TEST31.md

echo '[44/85] Combat logout reward fence'
grep -q 'consumeCombatLogout' src/main/java/arena/combat/DamageTracker.java
grep -q 'Combat logout kill' src/main/java/arena/forge/ArenaRuntime.java

echo '[45/85] Combat logout behavioral self-test'
javac --release 17 -cp .verify-pure/classes -d .verify-pure/classes verify-tests/CombatLogoutSelfTest.java
java -cp .verify-pure/classes CombatLogoutSelfTest | grep -q 'COMBAT_LOGOUT_SELF_TEST_OK'

echo '[46/85] Profile save failures are observable/retryable'
grep -q 'saveFailures' src/main/java/arena/profile/ProfileService.java
grep -q 'dirtyCount' src/main/java/arena/profile/ProfileService.java

echo '[47/85] Test32 hardening notes present'
test -f LIVE-CORE-HARDENING-TEST32.md

echo '[48/85] Round participant identity fence'
grep -q 'activeRoundNumber' src/main/java/arena/forge/player/ArenaPlayerSession.java
grep -q 'prepareForRound(player, roundNumber)' src/main/java/arena/forge/player/ArenaPlayerManager.java
grep -q 'arenaSession.state() != ArenaPlayerState.QUEUED' src/main/java/arena/forge/player/ArenaPlayerManager.java

echo '[49/85] Mid-round join receives fresh match state exactly once'
grep -q 's.isInRound(roundNumber)' src/main/java/arena/forge/player/ArenaPlayerManager.java
grep -q 'runtime.rounds().roundNumber()' src/main/java/arena/forge/GunnerCommands.java

echo '[50/85] Failed profile logout is retained instead of discarded'
grep -q 'retainedOffline' src/main/java/arena/profile/ProfileService.java
grep -q 'if (saved)' src/main/java/arena/profile/ProfileService.java

echo '[51/85] Round/session behavioral self-test'
javac --release 17 -cp .verify-pure/classes -d .verify-pure/classes src/main/java/arena/forge/player/ArenaPlayerState.java src/main/java/arena/forge/player/ArenaPlayerSession.java verify-tests/ArenaPlayerSessionSelfTest.java
java -cp .verify-pure/classes ArenaPlayerSessionSelfTest | grep -q 'ARENA_PLAYER_SESSION_SELF_TEST_OK'

echo '[52/85] Profile retention behavioral self-test + notes'
javac --release 17 -cp .verify-pure/classes -d .verify-pure/classes verify-tests/ProfileRetentionSelfTest.java
java -cp .verify-pure/classes ProfileRetentionSelfTest | grep -q 'PROFILE_RETENTION_SELF_TEST_OK'
test -f LIVE-CORE-HARDENING-TEST33.md

echo '[53/85] Separate client UI module scaffold'
test -f client-ui/build.gradle
test -f client-ui/src/main/resources/META-INF/mods.toml
grep -q 'modId="${mod_id}"' client-ui/src/main/resources/META-INF/mods.toml
grep -q 'side="CLIENT"' client-ui/src/main/resources/META-INF/mods.toml

echo '[54/85] Fullscreen main menu source'
grep -q 'class MainArenaScreen' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java
grep -q 'ИГРАТЬ' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java
grep -q 'МАГАЗИН' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java
grep -q 'ПРОФИЛЬ' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java

echo '[55/85] Responsive UI layout behavioral self-test'
mkdir -p .verify-ui/classes
javac --release 17 -d .verify-ui/classes client-ui/src/main/java/arena/client/ui/UiLayout.java client-ui/verify-tests/UiLayoutSelfTest.java
java -cp .verify-ui/classes UiLayoutSelfTest | grep -q 'UI_LAYOUT_SELF_TEST_OK'

echo '[56/85] Client-only dev key/menu bootstrap'
grep -q 'value = Dist.CLIENT' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
grep -q 'RegisterKeyMappingsEvent' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
grep -q 'ClientUiOpener.open(0)' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java

echo '[57/85] Test34 client UI notes present'
test -f CLIENT-UI-TEST34.md

echo '[58/85] Side-neutral server snapshot model'
test -f src/main/java/arena/net/ArenaSnapshot.java
grep -q 'public ArenaSnapshot createSnapshot(ServerPlayer player)' src/main/java/arena/forge/ArenaRuntime.java

echo '[59/85] Core UI network channel'
grep -q 'new ResourceLocation("gunnerarena", "ui")' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'SnapshotRequest.class' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'PacketDistributor.PLAYER.with(player)' src/main/java/arena/forge/net/ArenaNetwork.java

echo '[60/85] Client UI network channel + polling'
grep -q 'new ResourceLocation("gunnerarena", "ui")' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
grep -q 'ArenaClientNetwork.requestSnapshot()' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
grep -q 'snapshotPollTicks >= 20' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java

echo '[61/85] UI renders server snapshot data'
grep -q 'ClientSnapshotStore.get()' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java
grep -q 'ClientSnapshotStore.get()' client-ui/src/main/java/arena/client/ui/ProfileScreen.java
grep -q 'ClientSnapshotStore.get()' client-ui/src/main/java/arena/client/ui/ShopScreen.java

echo '[62/85] Snapshot behavioral self-tests'
javac --release 17 -cp .verify-pure/classes -d .verify-pure/classes verify-tests/ArenaSnapshotSelfTest.java
java -cp .verify-pure/classes ArenaSnapshotSelfTest | grep -q 'ARENA_SNAPSHOT_SELF_TEST_OK'
mkdir -p .verify-ui-snapshot/classes
javac --release 17 -d .verify-ui-snapshot/classes client-ui/src/main/java/arena/client/net/ArenaClientSnapshot.java client-ui/src/main/java/arena/client/net/ClientSnapshotStore.java client-ui/verify-tests/ClientSnapshotSelfTest.java
java -cp .verify-ui-snapshot/classes ClientSnapshotSelfTest | grep -q 'CLIENT_SNAPSHOT_SELF_TEST_OK'

echo '[63/85] Test35 Core-UI protocol notes present'
test -f CLIENT-UI-NETWORK-TEST35.md

echo '[64/85] Server-authoritative shop protocol'
grep -q 'PROTOCOL_VERSION = "5"' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'BuyRequest.class' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'handleBuy(ServerPlayer player, String weaponId)' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'WeaponSafetyPolicy.isQuarantined(weaponId)' src/main/java/arena/forge/net/ArenaNetwork.java

echo '[65/85] Server catalog derives runtime availability'
grep -q 'forgeLoadouts().isAvailable(def.id())' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'public boolean isAvailable(String weaponId)' src/main/java/arena/forge/loadout/ForgeLoadoutService.java

echo '[66/85] Client shop catalog + buy wiring'
grep -q 'requestCatalog()' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
grep -q 'ArenaClientNetwork.buy(selected.id())' client-ui/src/main/java/arena/client/ui/ShopScreen.java
grep -q 'CRASH QUARANTINE' client-ui/src/main/java/arena/client/ui/ShopScreen.java

echo '[67/85] Client shop state behavioral self-test'
mkdir -p .verify-ui-shop/classes
javac --release 17 -d .verify-ui-shop/classes client-ui/src/main/java/arena/client/net/ArenaClientShopItem.java client-ui/src/main/java/arena/client/net/ClientShopStore.java client-ui/verify-tests/ClientShopStoreSelfTest.java
java -cp .verify-ui-shop/classes ClientShopStoreSelfTest | grep -q 'CLIENT_SHOP_STORE_SELF_TEST_OK'

echo '[68/85] Buy anti-spam lifecycle cleanup'
grep -q 'LAST_BUY_TICK' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'ArenaNetwork.forget(player)' src/main/java/arena/forge/ArenaRuntime.java

echo '[69/85] Test36 client shop notes present'
test -f CLIENT-UI-SHOP-TEST36.md

echo '[70/85] UI protocol v3 server-open packet'
grep -q 'PROTOCOL_VERSION = "5"' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'OpenUiPacket.class' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'public static void openUi(ServerPlayer player, UiTarget target)' src/main/java/arena/forge/net/ArenaNetwork.java

echo '[71/85] Client handles server-open packet'
grep -q 'PROTOCOL_VERSION = "5"' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
grep -q 'ClientUiOpener.open' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
test -f client-ui/src/main/java/arena/client/ui/ClientUiOpener.java

echo '[72/85] Server command UI test path'
grep -q 'literal("menu")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'literal("shop")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'literal("profile")' src/main/java/arena/forge/GunnerCommands.java

echo '[73/85] Client key demoted to dev fallback'
grep -q 'GLFW_KEY_F8' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
grep -q 'ClientUiOpener.open(0)' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java

echo '[74/85] Test37 server-driven UI notes present'
test -f CLIENT-UI-SERVER-OPEN-TEST37.md

echo '[75/85] UI access policy + stale Core state'
grep -q 'class UiAccessPolicy' client-ui/src/main/java/arena/client/ui/UiAccessPolicy.java
grep -q 'СВЯЗЬ С CORE' client-ui/src/main/java/arena/client/ui/UiAccessPolicy.java

echo '[76/85] PLAY is server-state gated'
grep -q 'UiAccessPolicy.canPlay' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java
grep -q 'playButton.active' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java

echo '[77/85] Shop snapshot/catalog freshness gates'
grep -q 'catalogFresh' client-ui/src/main/java/arena/client/net/ClientShopStore.java
grep -q 'UiAccessPolicy.canShop' client-ui/src/main/java/arena/client/ui/ShopScreen.java

echo '[78/85] Shop refreshes catalog while open'
grep -q 'mc.screen instanceof ShopScreen' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java

echo '[79/85] Disconnect clears cached UI state'
grep -q 'ClientSnapshotStore.clear(); ClientShopStore.clear();' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java

echo '[80/85] Test38 UI access behavioral self-test + notes'
mkdir -p .verify-ui-access/classes
javac --release 17 -d .verify-ui-access/classes client-ui/src/main/java/arena/client/net/ArenaClientSnapshot.java client-ui/src/main/java/arena/client/ui/UiAccessPolicy.java client-ui/src/main/java/arena/client/ui/UiAccessPolicySelfTest.java
java -cp .verify-ui-access/classes arena.client.ui.UiAccessPolicySelfTest | grep -q 'UI_ACCESS_POLICY_OK'
test -f CLIENT-UI-HARDENING-TEST38.md


echo '[81/85] Unified UI navigation routes'
test -f client-ui/src/main/java/arena/client/ui/ArenaNavigation.java
grep -q 'UiRoute.MAIN' client-ui/src/main/java/arena/client/ui/ArenaNavigation.java
grep -q 'installNavigation()' client-ui/src/main/java/arena/client/ui/MainArenaScreen.java
grep -q 'installNavigation()' client-ui/src/main/java/arena/client/ui/ShopScreen.java
grep -q 'installNavigation()' client-ui/src/main/java/arena/client/ui/ProfileScreen.java

echo '[82/85] No nested screen parent chain'
! grep -q 'private final Screen parent' client-ui/src/main/java/arena/client/ui/ShopScreen.java
! grep -q 'private final Screen parent' client-ui/src/main/java/arena/client/ui/ProfileScreen.java
grep -q 'escapeTarget(route)' client-ui/src/main/java/arena/client/ui/AbstractArenaScreen.java

echo '[83/85] Profile freshness + self-refresh'
grep -q 'ArenaClientNetwork.requestSnapshot()' client-ui/src/main/java/arena/client/ui/ProfileScreen.java
grep -q 'ClientSnapshotStore.fresh' client-ui/src/main/java/arena/client/ui/ProfileScreen.java
grep -q 'СВЯЗЬ С CORE' client-ui/src/main/java/arena/client/ui/ProfileScreen.java

echo '[84/85] Dev opener disabled by default + navigation behavioral test'
grep -q 'gunnerarena.ui.devKey' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
javac --release 17 -d .verify-ui/classes client-ui/src/main/java/arena/client/ui/UiRoute.java client-ui/src/main/java/arena/client/ui/UiNavigationPolicy.java client-ui/verify-tests/UiNavigationSelfTest.java
java -cp .verify-ui/classes UiNavigationSelfTest | grep -q 'UI_NAVIGATION_SELF_TEST_OK'

echo '[85/85] Test39 UI source-complete notes present'
test -f CLIENT-UI-FINALIZE-TEST39.md

echo SOURCE_GATE_OK

echo '[86/89] Custom weapon tuning model'
test -f src/main/java/arena/weapon/WeaponTuning.java
grep -q 'shotIntervalMillis' src/main/java/arena/weapon/WeaponTuning.java

echo '[87/89] Four launch weapon tuning profiles'
test -f src/main/java/arena/weapon/CustomWeaponArsenal.java
grep -q 'gunnerarena:p9' src/main/java/arena/weapon/CustomWeaponArsenal.java
grep -q 'gunnerarena:px18' src/main/java/arena/weapon/CustomWeaponArsenal.java
grep -q 'gunnerarena:vkr47' src/main/java/arena/weapon/CustomWeaponArsenal.java
grep -q 'gunnerarena:raven_m96' src/main/java/arena/weapon/CustomWeaponArsenal.java

echo '[88/89] Custom arsenal behavioral self-test'
mkdir -p .verify-weapons/classes
javac --release 17 -d .verify-weapons/classes src/main/java/arena/weapon/WeaponDefinition.java src/main/java/arena/weapon/WeaponCatalog.java src/main/java/arena/weapon/WeaponTuning.java src/main/java/arena/weapon/CustomWeaponArsenal.java verify-tests/CustomWeaponArsenalSelfTest.java
java -cp .verify-weapons/classes CustomWeaponArsenalSelfTest | grep -q 'CUSTOM_WEAPON_ARSENAL_OK'

echo '[89/89] Test40 new weapon notes present'
test -f NEW-WEAPONS-TEST40.md

echo SOURCE_GATE_TEST40_OK

echo '[90/93] Server-authoritative fire-state controller'
test -f src/main/java/arena/weapon/FireStateController.java
grep -q 'case SEMI' src/main/java/arena/weapon/FireStateController.java
grep -q 'case AUTO' src/main/java/arena/weapon/FireStateController.java
grep -q 'case BURST_3' src/main/java/arena/weapon/FireStateController.java

echo '[91/93] VKR exact three-shot burst scheduling'
grep -q 'state.burstRemaining = tuning.burstSize()' src/main/java/arena/weapon/FireStateController.java
grep -q 'MAX_SHOTS_PER_UPDATE = 1' src/main/java/arena/weapon/FireStateController.java

echo '[92/93] Fire-state behavioral self-test'
mkdir -p .verify-fire/classes
javac --release 17 -d .verify-fire/classes src/main/java/arena/weapon/WeaponDefinition.java src/main/java/arena/weapon/WeaponCatalog.java src/main/java/arena/weapon/WeaponTuning.java src/main/java/arena/weapon/CustomWeaponArsenal.java src/main/java/arena/weapon/FireStateController.java verify-tests/FireStateControllerSelfTest.java
java -cp .verify-fire/classes FireStateControllerSelfTest | grep -q 'FIRE_STATE_CONTROLLER_OK'

echo '[93/93] Test41 fire controller notes present'
test -f NEW-WEAPONS-FIRE-TEST41.md

echo SOURCE_GATE_TEST41_OK

echo '[94/99] Server-authoritative ammo state controller'
test -f src/main/java/arena/weapon/AmmoStateController.java
grep -q 'EMPTY_MAGAZINE' src/main/java/arena/weapon/AmmoStateController.java
grep -q 'RELOADING' src/main/java/arena/weapon/AmmoStateController.java

echo '[95/99] Reload completion transfers reserve only at completion'
grep -q 'finishReloadIfDue' src/main/java/arena/weapon/AmmoStateController.java
grep -q 'state.reserve -= moved' src/main/java/arena/weapon/AmmoStateController.java

echo '[96/99] Ammo behavioral self-test'
mkdir -p .verify-ammo/classes
javac --release 17 -d .verify-ammo/classes src/main/java/arena/weapon/WeaponDefinition.java src/main/java/arena/weapon/WeaponCatalog.java src/main/java/arena/weapon/WeaponTuning.java src/main/java/arena/weapon/CustomWeaponArsenal.java src/main/java/arena/weapon/AmmoStateController.java verify-tests/AmmoStateControllerSelfTest.java
java -cp .verify-ammo/classes AmmoStateControllerSelfTest | grep -q 'AMMO_STATE_CONTROLLER_OK'

echo '[97/99] Fire + ammo runtime integration controller'
test -f src/main/java/arena/weapon/WeaponRuntimeController.java
grep -q 'tryConsumeShot' src/main/java/arena/weapon/WeaponRuntimeController.java

echo '[98/99] Weapon runtime behavioral self-test'
mkdir -p .verify-weapon-runtime/classes
javac --release 17 -d .verify-weapon-runtime/classes src/main/java/arena/weapon/WeaponDefinition.java src/main/java/arena/weapon/WeaponCatalog.java src/main/java/arena/weapon/WeaponTuning.java src/main/java/arena/weapon/CustomWeaponArsenal.java src/main/java/arena/weapon/FireStateController.java src/main/java/arena/weapon/AmmoStateController.java src/main/java/arena/weapon/WeaponRuntimeController.java verify-tests/WeaponRuntimeControllerSelfTest.java
java -cp .verify-weapon-runtime/classes WeaponRuntimeControllerSelfTest | grep -q 'WEAPON_RUNTIME_CONTROLLER_OK'

echo '[99/99] Test42 ammo/reload notes present'
test -f NEW-WEAPONS-AMMO-TEST42.md

echo SOURCE_GATE_TEST42_OK

echo '[86/90] Four custom weapon Forge registrations'
grep -q 'DeferredRegister.create(ForgeRegistries.ITEMS' src/main/java/arena/forge/item/GunnerArenaItems.java
[[ "$(grep -c 'ITEMS.register' src/main/java/arena/forge/item/GunnerArenaItems.java)" -ge 5 ]]

echo '[87/90] Mod constructor attaches item DeferredRegister'
grep -q 'GunnerArenaItems.register(FMLJavaModLoadingContext.get().getModEventBus())' src/main/java/arena/GunnerArenaMod.java

echo '[88/90] Registered custom items use explicit combat-readiness gate'
grep -q 'CustomWeaponAvailability.isCombatReady' src/main/java/arena/forge/loadout/ForgeLoadoutService.java
grep -q 'COMBAT_READY' src/main/java/arena/forge/item/CustomWeaponAvailability.java

echo '[89/90] Temporary item models + translations present'
for x in p9 px18 vkr47 raven_m96; do test -f "src/main/resources/assets/gunnerarena/models/item/$x.json"; done
test -f src/main/resources/assets/gunnerarena/lang/ru_ru.json

echo '[90/90] Test43 registration notes present'
test -f NEW-WEAPONS-ITEMS-TEST43.md

echo 'SOURCE_GATE_TEST43_OK'

echo '[91/97] Forge custom weapon combat adapter'
test -f src/main/java/arena/forge/weapon/ForgeCustomWeaponCombatService.java
grep -q 'ProjectileUtil.getEntityHitResult' src/main/java/arena/forge/weapon/ForgeCustomWeaponCombatService.java
grep -q 'damageSources().playerAttack' src/main/java/arena/forge/weapon/ForgeCustomWeaponCombatService.java

echo '[92/97] Registered custom weapons enabled only after adapter exists'
grep -q 'gunnerarena:raven_m96' src/main/java/arena/forge/item/CustomWeaponAvailability.java
! grep -q 'COMBAT_READY = Set.of();' src/main/java/arena/forge/item/CustomWeaponAvailability.java

echo '[93/97] Held trigger input is server-ticked'
grep -q 'player.startUsingItem(hand)' src/main/java/arena/forge/item/ArenaWeaponItem.java
grep -q 'customWeaponCombat.tick' src/main/java/arena/forge/ArenaRuntime.java

echo '[94/97] Server-side reload and fire-mode controls'
grep -q 'Commands.literal("reload")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'Commands.literal("firemode")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'player.isCrouching()' src/main/java/arena/forge/ArenaRuntime.java

echo '[95/97] Custom shots feed lifetime accuracy stats'
grep -q 'void recordShot' src/main/java/arena/forge/player/ArenaPlayerManager.java
grep -q 'players.recordShot' src/main/java/arena/forge/ArenaRuntime.java

echo '[96/97] Combat runtime state cleanup'
grep -q 'customWeaponCombat.forget(player)' src/main/java/arena/forge/ArenaRuntime.java

echo '[97/97] Test44 combat adapter notes present'
test -f NEW-WEAPONS-COMBAT-TEST44.md

echo SOURCE_GATE_TEST44_OK

echo '[98/103] Custom weapon state hard lifecycle cleanup'
grep -q 'customWeaponCombat.forget(victim)' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'customWeaponCombat.forget(player)' src/main/java/arena/forge/ArenaRuntime.java
[[ "$(grep -c 'customWeaponCombat.clearAll()' src/main/java/arena/forge/ArenaRuntime.java)" -ge 3 ]]
grep -q 'public void clearAll()' src/main/java/arena/weapon/WeaponRuntimeController.java

echo '[99/103] Weapon lifecycle behavioral self-test'
mkdir -p .verify-weapon-lifecycle/classes
javac --release 17 -d .verify-weapon-lifecycle/classes src/main/java/arena/weapon/WeaponDefinition.java src/main/java/arena/weapon/WeaponCatalog.java src/main/java/arena/weapon/WeaponTuning.java src/main/java/arena/weapon/CustomWeaponArsenal.java src/main/java/arena/weapon/FireStateController.java src/main/java/arena/weapon/AmmoStateController.java src/main/java/arena/weapon/WeaponRuntimeController.java verify-tests/CustomWeaponLifecycleSelfTest.java
java -cp .verify-weapon-lifecycle/classes CustomWeaponLifecycleSelfTest | grep -q 'CUSTOM_WEAPON_LIFECYCLE_OK'

echo '[100/103] Side-neutral custom weapon combat policy'
test -f src/main/java/arena/weapon/CustomWeaponCombatPolicy.java
grep -q 'CustomWeaponCombatPolicy.decide' src/main/java/arena/forge/ArenaRuntime.java
mkdir -p .verify-weapon-policy/classes
javac --release 17 -d .verify-weapon-policy/classes src/main/java/arena/weapon/CustomWeaponCombatPolicy.java verify-tests/CustomWeaponCombatPolicySelfTest.java
java -cp .verify-weapon-policy/classes CustomWeaponCombatPolicySelfTest | grep -q 'CUSTOM_WEAPON_COMBAT_POLICY_OK'

echo '[101/103] Core/UI protocol v4 weapon input hooks'
grep -q 'PROTOCOL_VERSION = "5"' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'WeaponActionRequest.class' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'PROTOCOL_VERSION = "5"' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
grep -q 'requestReload()' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
grep -q 'requestCycleFireMode()' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java

echo '[102/103] Production reload/fire-mode keybinds'
grep -q 'GLFW.GLFW_KEY_R' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
grep -q 'GLFW.GLFW_KEY_V' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java
grep -q 'mc.screen == null' client-ui/src/main/java/arena/client/ui/GunnerArenaUiMod.java

echo '[103/103] Test45 new weapons source-complete notes present'
test -f NEW-WEAPONS-SOURCE-COMPLETE-TEST45.md

echo SOURCE_GATE_TEST45_OK

echo '[104/110] Bot autofill population policy'
test -f src/main/java/arena/bot/BotPopulationPolicy.java
grep -q 'realPlayers < 5' src/main/java/arena/bot/BotPopulationPolicy.java
grep -q 'realPlayers < 10' src/main/java/arena/bot/BotPopulationPolicy.java

echo '[105/110] AI Gunner 1.5 high-level brain states'
test -f src/main/java/arena/bot/BotBrain.java
grep -q 'RETURN_TO_GAME' src/main/java/arena/bot/BotBrain.java
grep -q 'PATHFIND' src/main/java/arena/bot/BotBrain.java
grep -q 'TAKE_COVER' src/main/java/arena/bot/BotBrain.java

echo '[106/110] Reserved bot identity/token director'
test -f src/main/java/arena/bot/BotDirector.java
test -f src/main/java/arena/bot/BotTokenService.java
grep -q 'KairoX' src/main/java/arena/bot/BotDirector.java
grep -q 'MessageDigest.isEqual' src/main/java/arena/bot/BotTokenService.java

echo '[107/110] External bot auth and admin controls'
grep -q 'Commands.literal("botauth")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'Commands.literal("bots")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'gunnerarena_bot' src/main/java/arena/forge/GunnerCommands.java

echo '[108/110] Real-player count excludes authenticated bots'
grep -q '!online.getTags().contains("gunnerarena_bot")' src/main/java/arena/forge/ArenaRuntime.java
grep -q 'bots.tick(realPlayers, serverTick)' src/main/java/arena/forge/ArenaRuntime.java

echo '[109/110] Bot director + AI brain behavioral self-test'
mkdir -p .verify-bots/classes
javac --release 17 -d .verify-bots/classes src/main/java/arena/bot/*.java verify-tests/BotDirectorSelfTest.java
java -cp .verify-bots/classes BotDirectorSelfTest | grep -q 'BOT_DIRECTOR_OK'

echo '[110/110] Test46 AI Gunner/autofill notes present'
test -f AI-GUNNER-1.5-BOT-AUTOFILL-TEST46.md

echo SOURCE_GATE_TEST46_OK

echo '[111/119] RPG progression + 24-node launch catalog'
test -f src/main/java/arena/rpg/RpgProgression.java
test -f src/main/java/arena/rpg/SkillCatalog.java
[[ "$(grep -c 'add(s(' src/main/java/arena/rpg/SkillCatalog.java)" -eq 24 ]]
grep -q 'MAX_LEVEL = 100' src/main/java/arena/rpg/RpgProgression.java

echo '[112/119] Server-authoritative skill unlock validation'
grep -q 'checkUnlock' src/main/java/arena/rpg/RpgService.java
grep -q 'MISSING_PREREQUISITE' src/main/java/arena/rpg/RpgService.java
grep -q 'MAX_PASSIVES = 8' src/main/java/arena/rpg/RpgService.java
grep -q 'MAX_MAJORS = 3' src/main/java/arena/rpg/RpgService.java
grep -q 'MAX_ACTIVES = 1' src/main/java/arena/rpg/RpgService.java

echo '[113/119] RPG progression/effects behavioral tests'
rm -rf .verify-rpg && mkdir -p .verify-rpg/classes
javac --release 17 -d .verify-rpg/classes src/main/java/arena/profile/PlayerProfile.java src/main/java/arena/rpg/*.java verify-tests/RpgProgressionSelfTest.java verify-tests/RpgEffectsSelfTest.java
java -cp .verify-rpg/classes RpgProgressionSelfTest | grep -q 'RPG_PROGRESSION_OK'
java -cp .verify-rpg/classes RpgEffectsSelfTest | grep -q 'RPG_EFFECTS_OK'

echo '[114/119] Persistent RPG profile data version 2'
grep -q 'DATA_VERSION = 2' src/main/java/arena/profile/PlayerProfile.java
rm -rf .verify-rpg-store && mkdir -p .verify-rpg-store/classes
javac --release 17 -d .verify-rpg-store/classes src/main/java/arena/profile/PlayerProfile.java src/main/java/arena/profile/ProfileStorage.java verify-tests/RpgPersistenceSelfTest.java
java -cp .verify-rpg-store/classes RpgPersistenceSelfTest | grep -q 'RPG_PERSISTENCE_OK'

echo '[115/119] Arena rewards feed long-term XP'
grep -q 'rpg.grantXp(profile, 120)' src/main/java/arena/forge/player/ArenaPlayerManager.java
grep -q 'rpg.grantXp(profile, 45)' src/main/java/arena/forge/player/ArenaPlayerManager.java

echo '[116/119] RPG effects wired into server-owned combat/economy'
grep -q 'SkillEffect.Type.CREDIT_GAIN' src/main/java/arena/forge/player/ArenaPlayerManager.java
grep -q 'bindDamageMultiplier' src/main/java/arena/forge/weapon/ForgeCustomWeaponCombatService.java
grep -q 'SkillEffect.Type.DAMAGE_MULT' src/main/java/arena/forge/ArenaRuntime.java

echo '[117/119] RPG commands + specialization'
grep -q 'Commands.literal("skills")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'Commands.literal("specialization")' src/main/java/arena/forge/GunnerCommands.java
grep -q 'Commands.literal("skillpoints")' src/main/java/arena/forge/GunnerCommands.java

echo '[118/119] Core/UI v5 skill-tree protocol + client screen'
grep -q 'PROTOCOL_VERSION = "5"' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'SkillTreePacket.class' src/main/java/arena/forge/net/ArenaNetwork.java
grep -q 'PROTOCOL_VERSION = "5"' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java
test -f client-ui/src/main/java/arena/client/ui/SkillsScreen.java
rm -rf .verify-client-skill && mkdir -p .verify-client-skill/classes
javac --release 17 -d .verify-client-skill/classes client-ui/src/main/java/arena/client/net/ArenaClientSkillEntry.java client-ui/src/main/java/arena/client/net/ClientSkillTreeStore.java client-ui/verify-tests/SkillTreeStoreSelfTest.java
java -cp .verify-client-skill/classes SkillTreeStoreSelfTest | grep -q 'SKILL_TREE_STORE_OK'

echo '[119/119] Test47 RPG source-complete notes present'
test -f RPG-SKILL-TREE-SOURCE-COMPLETE-TEST47.md

echo SOURCE_GATE_TEST47_OK

echo '[120/126] FULL integration manifest'
test -f INTEGRATION-MANIFEST.properties
grep -q '^network_protocol=5$' INTEGRATION-MANIFEST.properties
grep -q '^release_line=0.6.0-test51-verifyfix$' INTEGRATION-MANIFEST.properties

echo '[121/126] Integrated 1.20.1 resource-pack scaffold'
test -f resource-pack/pack.mcmeta
grep -q '"pack_format": 15' resource-pack/pack.mcmeta
test -f resource-pack/pack.png

echo '[122/126] Four stable custom-weapon resource paths'
for w in p9 px18 vkr47 raven_m96; do
  test -f "resource-pack/assets/gunnerarena/models/item/$w.json"
  test -f "resource-pack/assets/gunnerarena/textures/item/$w.png"
  grep -q "gunnerarena:item/$w" "resource-pack/assets/gunnerarena/models/item/$w.json"
done

echo '[123/126] Reproducible resource-pack builder'
test -x build-resource-pack.sh
grep -q 'zip -X' build-resource-pack.sh
grep -q 'sha1sum' build-resource-pack.sh
grep -q 'sha256sum' build-resource-pack.sh

echo '[124/126] FULL release assembler is fail-closed'
test -x assemble-full-release.sh
grep -q 'compiled Core jar is required' assemble-full-release.sh
grep -q 'compiled Client UI jar is required' assemble-full-release.sh

echo '[125/126] FULL integration proof harness'
test -x full-integration-proof.sh
grep -q 'FULL_INTEGRATION_SOURCE_PROOF_OK' full-integration-proof.sh

echo '[126/126] Test48 FULL integration notes present'
test -f FULL-INTEGRATION-TEST48.md

echo SOURCE_GATE_TEST48_OK

echo '[127/130] Offline Java17/Forge MDK build handoff'
test -x stage1-build-input.sh
grep -q "EXPECTED_MDK_SHA1='31133abd261aa4d23672d1820db06ccec80326ad'" stage1-build-input.sh
grep -q 'Java 17 required' stage1-build-input.sh

echo '[128/130] Build environment evidence reporter'
test -x build-environment-report.sh
grep -q 'forge_mdk_cached=' build-environment-report.sh

echo '[129/130] Release line advanced to test51 verify-fix'
grep -q '^mod_version=0.6.0-test51-verifyfix$' gradle.properties
grep -q '^release_line=0.6.0-test51-verifyfix$' INTEGRATION-MANIFEST.properties

echo '[130/130] Stage-1 blocker notes present'
test -f STAGE1-BLOCKER-TEST49.md

echo SOURCE_GATE_TEST51_OK

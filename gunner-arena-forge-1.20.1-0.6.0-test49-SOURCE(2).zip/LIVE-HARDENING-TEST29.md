# Test29 — Live Core authentication/session hardening

Stage 2 started in source.

## Changes
- Combat now requires both the SAuth tag and a fully initialized Gunner Arena session.
- Round start/reset/loadout operations skip players who are still at the login/register gate.
- Round stop/lobby movement skips unauthenticated/uninitialized connections.
- Hazard targeting also requires a fully initialized arena session.
- This closes the short auth-tag -> ArenaRuntime initialization race where a player could otherwise be seen as authenticated before profile/session setup completed.

## Status
Source-level hardening only. Requires Forge compile and dedicated runtime verification.

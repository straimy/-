import arena.profile.PlayerProfile;
import arena.rpg.*;

public final class RpgEffectsSelfTest {
    public static void main(String[] args) {
        SkillCatalog catalog = new SkillCatalog();
        RpgEffects effects = new RpgEffects(catalog);
        PlayerProfile p = new PlayerProfile();
        p.unlockedSkills.add("survival_plating");
        p.unlockedSkills.add("survival_laststand");
        p.unlockedSkills.add("combat_focus");
        p.unlockedSkills.add("combat_pressure");
        if (effects.maxHealth(p) != 26.0) fail("health cap");
        double dmg = effects.value(p, SkillEffect.Type.DAMAGE_MULT);
        if (Math.abs(dmg - .05) > .0001) fail("damage aggregation");
        System.out.println("RPG_EFFECTS_OK");
    }
    private static void fail(String s) { throw new AssertionError(s); }
}

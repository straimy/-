import arena.weapon.CustomWeaponArsenal;
import arena.weapon.FireStateController;
import arena.weapon.WeaponDefinition;
import arena.weapon.WeaponTuning;

public final class FireStateControllerSelfTest {
    public static void main(String[] args) {
        CustomWeaponArsenal arsenal = new CustomWeaponArsenal();
        FireStateController fire = new FireStateController();

        WeaponTuning p9 = arsenal.get("gunnerarena:p9");
        long p9Step = p9.shotIntervalMillis();
        check(fire.update("a", p9, true, 1_000).shotsToFire() == 1, "P9 press should fire");
        check(fire.update("a", p9, true, 1_000 + p9Step + 10).shotsToFire() == 0, "SEMI must not repeat while held");
        fire.update("a", p9, false, 1_000 + p9Step + 20);
        check(fire.update("a", p9, true, 1_000 + p9Step + 30).shotsToFire() == 1, "SEMI should fire after release+press");

        WeaponTuning px = arsenal.get("gunnerarena:px18");
        fire.setMode("b", px, WeaponDefinition.FireMode.AUTO);
        long autoStep = px.shotIntervalMillis();
        check(fire.update("b", px, true, 2_000).fired(), "AUTO initial shot");
        check(!fire.update("b", px, true, 2_000 + autoStep - 1).fired(), "AUTO RPM cooldown");
        check(fire.update("b", px, true, 2_000 + autoStep).fired(), "AUTO fires at interval");

        WeaponTuning vkr = arsenal.get("gunnerarena:vkr47");
        fire.setMode("c", vkr, WeaponDefinition.FireMode.BURST_3);
        long burstStep = vkr.shotIntervalMillis();
        var first = fire.update("c", vkr, true, 3_000);
        check(first.shotsToFire() == 1 && first.burstRemaining() == 2, "burst shot 1/3");
        var second = fire.update("c", vkr, false, 3_000 + burstStep);
        check(second.shotsToFire() == 1 && second.burstRemaining() == 1, "burst continues after release 2/3");
        var third = fire.update("c", vkr, false, 3_000 + burstStep * 2);
        check(third.shotsToFire() == 1 && third.burstRemaining() == 0, "burst shot 3/3");
        check(!fire.update("c", vkr, false, 3_000 + burstStep * 3).fired(), "burst must stop at three");
        check(fire.update("c", vkr, true, 3_000 + burstStep * 4).fired(), "fresh press starts next burst");

        fire.setMode("d", vkr, WeaponDefinition.FireMode.SEMI);
        check(fire.cycleMode("d", vkr) == WeaponDefinition.FireMode.BURST_3, "SEMI -> BURST");
        check(fire.cycleMode("d", vkr) == WeaponDefinition.FireMode.AUTO, "BURST -> AUTO");
        check(fire.cycleMode("d", vkr) == WeaponDefinition.FireMode.SEMI, "AUTO -> SEMI");

        boolean rejected = false;
        try { fire.setMode("e", p9, WeaponDefinition.FireMode.AUTO); }
        catch (IllegalArgumentException expected) { rejected = true; }
        check(rejected, "P9 must reject unsupported AUTO");

        fire.update("cleanup", p9, true, 9_000);
        check(fire.trackedSessions() > 0, "tracked session expected");
        fire.forgetActor("cleanup");
        check(fire.trackedSessions() >= 0, "cleanup should be safe");

        System.out.println("FIRE_STATE_CONTROLLER_OK");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}

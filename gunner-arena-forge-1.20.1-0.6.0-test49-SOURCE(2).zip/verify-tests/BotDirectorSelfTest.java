import arena.bot.*;

public final class BotDirectorSelfTest {
    public static void main(String[] args) {
        if (BotPopulationPolicy.desiredBots(0) != 4) fail("0 players => 4 bots");
        if (BotPopulationPolicy.desiredBots(4) != 4) fail("4 players => 4 bots");
        if (BotPopulationPolicy.desiredBots(5) != 2) fail("5 players => 2 bots");
        if (BotPopulationPolicy.desiredBots(9) != 2) fail("9 players => 2 bots");
        if (BotPopulationPolicy.desiredBots(10) != 0) fail("10 players => 0 bots");

        BotDirector d = new BotDirector();
        d.tick(0, 0);
        if (d.slots().size() != 4) fail("autofill 4");
        BotSlot s = d.slots().get(0);
        if (!d.authenticate(s.name(), s.launchToken())) fail("token auth");
        if (d.authenticate(s.name(), s.launchToken() + "x")) fail("bad token accepted");
        d.tick(7, 20);
        if (d.slots().size() != 2) fail("shrink to 2");
        d.targetOverride(3);
        d.tick(20, 40);
        if (d.slots().size() != 3) fail("override 3");
        d.autofill(false);
        if (!d.slots().isEmpty()) fail("disable clears");

        BotBrain b = new BotBrain();
        var engage = b.decide(BotProfile.ASSAULT, new BotCombatSnapshot(true,true,20,true,false,1,10,20,true));
        if (engage.state() != BotBrainState.ENGAGE || !engage.fire()) fail("engage");
        var reload = b.decide(BotProfile.ASSAULT, new BotCombatSnapshot(true,true,20,true,false,1,0,20,true));
        if (reload.state() != BotBrainState.RELOAD || !reload.reload()) fail("reload");
        var heal = b.decide(BotProfile.SURVIVOR, new BotCombatSnapshot(true,false,0,true,false,.3,10,20,true));
        if (heal.state() != BotBrainState.HEAL) fail("heal");
        var path = b.decide(BotProfile.RUSHER, new BotCombatSnapshot(true,false,0,false,false,1,10,20,false));
        if (path.state() != BotBrainState.PATHFIND || !path.useBaritone()) fail("pathfind");
        System.out.println("BOT_DIRECTOR_OK");
    }
    private static void fail(String m) { throw new AssertionError(m); }
}

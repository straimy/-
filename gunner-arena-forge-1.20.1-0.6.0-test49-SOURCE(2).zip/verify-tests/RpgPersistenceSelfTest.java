import arena.profile.*;
import java.nio.file.*;
import java.util.*;

public final class RpgPersistenceSelfTest {
    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("ga-rpg-profile");
        ProfileStorage storage = new ProfileStorage(dir);
        PlayerProfile p = new PlayerProfile(); p.uuid = UUID.randomUUID(); p.lastKnownName="RpgTester";
        p.level=25; p.xp=12345; p.skillPoints=77; p.specialization="MARKSMAN"; p.unlockedSkills.add("combat_focus"); p.unlockedSkills.add("combat_precision");
        storage.save(p);
        PlayerProfile q=storage.load(p.uuid,"fallback");
        if(q.level!=25 || q.xp!=12345 || q.skillPoints!=77) fail("progression");
        if(!"MARKSMAN".equals(q.specialization)) fail("spec");
        if(!q.unlockedSkills.equals(p.unlockedSkills)) fail("skills");
        if(q.dataVersion!=PlayerProfile.DATA_VERSION) fail("version");
        System.out.println("RPG_PERSISTENCE_OK");
    }
    static void fail(String s){throw new AssertionError(s);}
}

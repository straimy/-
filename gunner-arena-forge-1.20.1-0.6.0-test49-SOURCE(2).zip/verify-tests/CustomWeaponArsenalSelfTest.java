import arena.weapon.CustomWeaponArsenal;
import arena.weapon.WeaponCatalog;
import arena.weapon.WeaponDefinition;
import arena.weapon.WeaponTuning;

public final class CustomWeaponArsenalSelfTest {
    public static void main(String[] args) {
        WeaponCatalog catalog = new WeaponCatalog();
        CustomWeaponArsenal arsenal = new CustomWeaponArsenal();
        arsenal.validateAgainst(catalog);
        if (arsenal.all().size() != 4) throw new AssertionError("expected four launch weapons");

        WeaponTuning p9 = arsenal.get("gunnerarena:p9");
        if (p9 == null || !p9.supports(WeaponDefinition.FireMode.SEMI) || p9.supports(WeaponDefinition.FireMode.AUTO)) throw new AssertionError("P9 modes");
        if (p9.shotIntervalMillis() < 140 || p9.shotIntervalMillis() > 144) throw new AssertionError("P9 rpm conversion");

        WeaponTuning vkr = arsenal.get("gunnerarena:vkr47");
        if (vkr == null || vkr.burstSize() != 3 || !vkr.supports(WeaponDefinition.FireMode.BURST_3)) throw new AssertionError("VKR burst");
        if (vkr.adsSpread() >= vkr.hipSpread()) throw new AssertionError("VKR ADS spread");

        WeaponTuning raven = arsenal.get("gunnerarena:raven_m96");
        if (raven == null || raven.headDamage() != 36.0) throw new AssertionError("Raven damage");
        if (raven.roundsPerMinute() >= vkr.roundsPerMinute()) throw new AssertionError("Raven cadence");

        System.out.println("CUSTOM_WEAPON_ARSENAL_OK");
    }
}

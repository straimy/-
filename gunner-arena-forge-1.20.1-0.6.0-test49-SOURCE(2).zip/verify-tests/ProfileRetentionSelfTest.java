import arena.economy.CurrencyService;
import arena.profile.PlayerProfile;
import arena.profile.ProfileService;
import arena.profile.ProfileStorage;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public final class ProfileRetentionSelfTest {
    public static void main(String[] args) throws Exception {
        Path blocker = Files.createTempFile("ga-profile-blocker", ".tmp");
        Path impossibleDirectory = blocker.resolve("players");
        ProfileService service = new ProfileService(new ProfileStorage(impossibleDirectory), new CurrencyService());
        UUID id = UUID.randomUUID();

        PlayerProfile first = service.login(id, "Tester");
        first.coins = 777;
        service.markDirty(id);
        boolean saved = service.logout(id);
        if (saved) throw new AssertionError("logout unexpectedly saved into impossible path");
        if (service.retainedOfflineCount() != 1) throw new AssertionError("failed logout was not retained");

        PlayerProfile recovered = service.login(id, "TesterAgain");
        if (recovered.coins != 777) throw new AssertionError("reconnect rolled back retained progression");
        if (!"TesterAgain".equals(recovered.lastKnownName)) throw new AssertionError("name was not refreshed");
        if (service.retainedOfflineCount() != 0) throw new AssertionError("retained marker not consumed on reconnect");

        Files.deleteIfExists(blocker);
        System.out.println("PROFILE_RETENTION_SELF_TEST_OK");
    }
}

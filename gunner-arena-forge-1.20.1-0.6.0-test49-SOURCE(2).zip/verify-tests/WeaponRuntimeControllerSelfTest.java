import arena.weapon.*;

public final class WeaponRuntimeControllerSelfTest {
    public static void main(String[] args) {
        WeaponCatalog catalog = new WeaponCatalog();
        CustomWeaponArsenal arsenal = new CustomWeaponArsenal();
        WeaponRuntimeController runtime = new WeaponRuntimeController();

        WeaponDefinition vkr = catalog.get("gunnerarena:vkr47");
        WeaponTuning tuning = arsenal.get(vkr.id());
        runtime.setMode("v", tuning, WeaponDefinition.FireMode.BURST_3);
        runtime.ammoController().setAmmo("v", vkr, 2, 60);
        long step = tuning.shotIntervalMillis();

        var a = runtime.update("v", vkr, tuning, true, 1000);
        check(a.fired() && a.ammo().magazine() == 1, "burst first shot");
        var b = runtime.update("v", vkr, tuning, false, 1000 + step);
        check(b.fired() && b.ammo().magazine() == 0, "burst second shot");
        var c = runtime.update("v", vkr, tuning, false, 1000 + step * 2);
        check(!c.fired() && c.shotBlockReason() == AmmoStateController.ShotBlockReason.EMPTY_MAGAZINE, "third burst shot blocked by empty magazine");
        check(c.ammo().magazine() == 0, "no negative ammo");

        var reload = runtime.reload("v", vkr, tuning, 3000);
        check(reload.started(), "runtime reload starts");
        var blocked = runtime.update("v", vkr, tuning, true, 3000 + step);
        check(!blocked.fired(), "runtime does not fire while reloading");
        var ready = runtime.ammo("v", vkr, 3000 + tuning.reloadMillis());
        check(ready.magazine() == 30 && ready.reserve() == 30, "VKR fills magazine from reserve");

        runtime.forgetActor("v");
        check(runtime.ammo("v", vkr, 9000).magazine() == 30, "forgot actor reinitializes ammo");

        System.out.println("WEAPON_RUNTIME_CONTROLLER_OK");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}

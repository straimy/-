import arena.profile.PlayerProfile;
import arena.rpg.*;

public final class RpgProgressionSelfTest {
    public static void main(String[] args) {
        SkillCatalog catalog = new SkillCatalog();
        if (catalog.all().size() != 24) fail("expected 24 launch skills");
        for (SkillBranch branch : SkillBranch.values()) if (catalog.branch(branch).size() != 4) fail("branch size " + branch);
        if (RpgProgression.levelForXp(0) != 1) fail("level 1");
        if (RpgProgression.levelForXp(RpgProgression.xpForLevel(25)) != 25) fail("level curve");

        PlayerProfile p = new PlayerProfile();
        RpgService rpg = new RpgService(catalog);
        var level = rpg.grantXp(p, RpgProgression.xpForLevel(25));
        if (p.level != 25 || level.awardedSkillPoints() != 240) fail("xp/points");
        if (rpg.unlock(p, "combat_precision").code() != RpgService.UnlockCode.MISSING_PREREQUISITE) fail("prereq");
        if (!rpg.unlock(p, "combat_focus").ok()) fail("unlock root");
        if (!rpg.unlock(p, "combat_precision").ok()) fail("unlock child");
        if (p.skillPoints != 185) fail("cost spending");
        if (rpg.chooseSpecialization(p, "MARKSMAN") != RpgService.SpecCode.OK) fail("spec");
        if (rpg.chooseSpecialization(p, "SCOUT") != RpgService.SpecCode.ALREADY_CHOSEN) fail("spec lock");
        int refund = rpg.resetSkills(p);
        if (refund != 55 || !p.unlockedSkills.isEmpty() || p.skillPoints != 240) fail("reset/refund");
        System.out.println("RPG_PROGRESSION_OK");
    }
    private static void fail(String s) { throw new AssertionError(s); }
}

import arena.net.ArenaSnapshot;

public final class ArenaSnapshotSelfTest {
    public static void main(String[] args) {
        ArenaSnapshot s = new ArenaSnapshot(true, true, "Player\nX", "PLAYING", 3, 119, 750,
            12, 5, 7, 1200, 2, 10, 4, 3, 999, 20, 15, 6, 8, 2, 3600,
            2, 1, 1, 300);
        if (!"Player X".equals(s.playerName())) throw new AssertionError("name sanitize");
        if (s.remainingSeconds() != 6) throw new AssertionError("timer ceil");
        if (Math.abs(s.kd() - 2.5D) > 0.0001D) throw new AssertionError("kd");
        if (Math.abs(s.accuracy() - 0.75D) > 0.0001D) throw new AssertionError("accuracy");

        ArenaSnapshot clamped = new ArenaSnapshot(true, true, "P", "PLAYING", -1, -20, -5,
            -1, -1, 0, -1, -1, -1, -1, -1, -1, 2, 99, -1, -1, 9, -1,
            -1, -1, -1, -1);
        if (clamped.roundNumber() != 0 || clamped.roundCredits() != 0) throw new AssertionError("negative clamp");
        if (clamped.level() != 1) throw new AssertionError("level clamp");
        if (clamped.shotsHit() != 2 || clamped.shotsFired() != 2) throw new AssertionError("shot clamp");
        if (clamped.roundsWon() != clamped.roundsPlayed()) throw new AssertionError("wins clamp");
        System.out.println("ARENA_SNAPSHOT_SELF_TEST_OK");
    }
}

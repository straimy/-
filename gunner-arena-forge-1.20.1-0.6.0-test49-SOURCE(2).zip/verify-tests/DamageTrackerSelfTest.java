import arena.combat.DamageTracker;
import java.util.*;

public final class DamageTrackerSelfTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        UUID victim = UUID.randomUUID();
        UUID a = UUID.randomUUID();
        UUID b = UUID.randomUUID();
        DamageTracker tracker = new DamageTracker();

        tracker.record(victim, a, 4.0, 100);
        tracker.record(victim, b, 1.0, 100);
        check(tracker.trackedContributions() == 2, "expected two contributors");
        tracker.forgetAttacker(b);
        check(tracker.trackedContributions() == 1, "logout cleanup must remove attacker globally");

        tracker.record(victim, b, 4.0, 100);
        int removed = tracker.pruneExpired(100 + DamageTracker.ASSIST_WINDOW_TICKS + 1);
        check(removed == 2, "expired contributions must be pruned");
        check(tracker.trackedVictims() == 0, "empty victim histories must be removed");

        tracker.record(victim, a, 5.0, 500);
        List<UUID> assists = tracker.consumeAssists(victim, null, 500, 20.0);
        check(assists.size() == 1 && assists.get(0).equals(a), "valid assist should survive");
        check(tracker.trackedVictims() == 0, "consume must clear victim history");

        System.out.println("DAMAGE_TRACKER_SELF_TEST_OK");
    }
}

import arena.weapon.*;

public final class CustomWeaponLifecycleSelfTest {
    public static void main(String[] args) {
        WeaponCatalog catalog = new WeaponCatalog();
        CustomWeaponArsenal arsenal = new CustomWeaponArsenal();
        WeaponRuntimeController runtime = new WeaponRuntimeController();
        WeaponDefinition vkr = catalog.get("gunnerarena:vkr47");
        WeaponTuning tuning = arsenal.get("gunnerarena:vkr47");

        runtime.update("alice", vkr, tuning, true, 1_000L);
        runtime.reload("bob", vkr, tuning, 1_000L);
        if (runtime.fireController().trackedSessions() == 0) throw new AssertionError("fire state not created");
        if (runtime.ammoController().trackedSessions() == 0) throw new AssertionError("ammo state not created");

        runtime.clearAll();
        if (runtime.fireController().trackedSessions() != 0) throw new AssertionError("fire state survived round clear");
        if (runtime.ammoController().trackedSessions() != 0) throw new AssertionError("ammo state survived round clear");
        System.out.println("CUSTOM_WEAPON_LIFECYCLE_OK");
    }
}

import arena.combat.DamageTracker;
import java.util.UUID;

public final class CombatLogoutSelfTest {
    public static void main(String[] args) {
        DamageTracker tracker = new DamageTracker();
        UUID victim = UUID.randomUUID();
        UUID older = UUID.randomUUID();
        UUID recent = UUID.randomUUID();
        long now = 1000L;

        tracker.record(victim, older, 8.0, now - 40L);
        tracker.record(victim, recent, 5.0, now - 5L);
        var result = tracker.consumeCombatLogout(victim, now, 20.0);
        if (!recent.equals(result.killer())) throw new AssertionError("most recent attacker must get combat-log kill");
        if (!result.assistants().contains(older)) throw new AssertionError("older qualifying attacker must become assistant");
        if (tracker.trackedVictims() != 0) throw new AssertionError("combat logout must consume victim evidence");

        UUID cleanVictim = UUID.randomUUID();
        UUID stale = UUID.randomUUID();
        tracker.record(cleanVictim, stale, 10.0, now - DamageTracker.ASSIST_WINDOW_TICKS - 1L);
        var clean = tracker.consumeCombatLogout(cleanVictim, now, 20.0);
        if (clean.inCombat()) throw new AssertionError("stale damage must not punish a disconnect");

        System.out.println("COMBAT_LOGOUT_SELF_TEST_OK");
    }
}

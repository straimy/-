import arena.weapon.CustomWeaponCombatPolicy;

public final class CustomWeaponCombatPolicySelfTest {
    public static void main(String[] args) {
        expect(CustomWeaponCombatPolicy.Decision.ALLOW,
            CustomWeaponCombatPolicy.decide(true, true, true, true, false));
        expect(CustomWeaponCombatPolicy.Decision.NOT_AUTHENTICATED,
            CustomWeaponCombatPolicy.decide(false, true, true, true, false));
        expect(CustomWeaponCombatPolicy.Decision.NOT_INITIALIZED,
            CustomWeaponCombatPolicy.decide(true, false, true, true, false));
        expect(CustomWeaponCombatPolicy.Decision.ROUND_NOT_PLAYING,
            CustomWeaponCombatPolicy.decide(true, true, false, true, false));
        expect(CustomWeaponCombatPolicy.Decision.NOT_ALIVE,
            CustomWeaponCombatPolicy.decide(true, true, true, false, false));
        expect(CustomWeaponCombatPolicy.Decision.SAFE_REGION,
            CustomWeaponCombatPolicy.decide(true, true, true, true, true));
        System.out.println("CUSTOM_WEAPON_COMBAT_POLICY_OK");
    }

    private static void expect(Object expected, Object actual) {
        if (!expected.equals(actual)) throw new AssertionError("expected=" + expected + " actual=" + actual);
    }
}

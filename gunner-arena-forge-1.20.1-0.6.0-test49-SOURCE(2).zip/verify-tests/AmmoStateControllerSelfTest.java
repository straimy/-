import arena.weapon.*;

public final class AmmoStateControllerSelfTest {
    public static void main(String[] args) {
        WeaponCatalog catalog = new WeaponCatalog();
        CustomWeaponArsenal arsenal = new CustomWeaponArsenal();
        AmmoStateController ammo = new AmmoStateController();

        WeaponDefinition p9 = catalog.get("gunnerarena:p9");
        WeaponTuning p9t = arsenal.get(p9.id());
        var initial = ammo.state("p", p9);
        check(initial.magazine() == 12 && initial.reserve() == 24, "P9 initial ammo");

        for (int i = 0; i < 4; i++) check(ammo.tryConsumeShot("p", p9, 1000 + i).fired(), "shot should consume");
        check(ammo.state("p", p9).magazine() == 8, "magazine after four shots");

        var reload = ammo.requestReload("p", p9, p9t, 2000);
        check(reload.started() && reload.ammo().reloading(), "reload should start");
        check(ammo.tryConsumeShot("p", p9, 2100).reason() == AmmoStateController.ShotBlockReason.RELOADING, "shot blocked while reloading");
        check(ammo.update("p", p9, 2000 + p9t.reloadMillis() - 1).magazine() == 8, "reload must not finish early");
        var done = ammo.update("p", p9, 2000 + p9t.reloadMillis());
        check(done.magazine() == 12 && done.reserve() == 20 && !done.reloading(), "reload transfers only missing rounds");

        ammo.setAmmo("p", p9, 0, 3);
        check(ammo.tryConsumeShot("p", p9, 5000).reason() == AmmoStateController.ShotBlockReason.EMPTY_MAGAZINE, "empty mag blocks shot");
        check(ammo.requestReload("p", p9, p9t, 5000).started(), "partial reserve reload starts");
        done = ammo.update("p", p9, 5000 + p9t.reloadMillis());
        check(done.magazine() == 3 && done.reserve() == 0, "partial reserve load");
        check(ammo.requestReload("p", p9, p9t, 7000).reason() == AmmoStateController.ReloadBlockReason.NO_RESERVE, "no reserve blocks reload");

        ammo.setAmmo("p", p9, 10, 24);
        check(ammo.requestReload("p", p9, p9t, 8000).started(), "reload start for cancel");
        var cancelled = ammo.cancelReload("p", p9);
        check(cancelled.magazine() == 10 && cancelled.reserve() == 24 && !cancelled.reloading(), "cancel does not spend reserve");

        ammo.setAmmo("p", p9, 12, 20);
        check(ammo.addReserve("p", p9, 50, 36) == 16, "reserve pickup must cap");
        check(ammo.state("p", p9).reserve() == 36, "reserve cap state");

        System.out.println("AMMO_STATE_CONTROLLER_OK");
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}

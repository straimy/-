import arena.forge.player.ArenaPlayerSession;
import arena.forge.player.ArenaPlayerState;

public final class ArenaPlayerSessionSelfTest {
    public static void main(String[] args) {
        ArenaPlayerSession s = new ArenaPlayerSession();
        if (s.state() != ArenaPlayerState.LOBBY) throw new AssertionError("default state");
        if (s.isInRound(1)) throw new AssertionError("fresh session in round");
        s.beginRound(7);
        if (!s.isInRound(7) || s.isInRound(8)) throw new AssertionError("round identity");
        s.state(ArenaPlayerState.ALIVE);
        s.protectionUntilTick(100);
        if (!s.protectedAt(99) || s.protectedAt(100)) throw new AssertionError("protection boundary");
        s.endRound();
        if (s.isInRound(7) || s.activeRoundNumber() != 0) throw new AssertionError("round cleanup");
        System.out.println("ARENA_PLAYER_SESSION_SELF_TEST_OK");
    }
}

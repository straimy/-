# Gunner Arena 0.6.0-test19

Implemented in source:
- `/spawnregion show <id>`: 20-second END_ROD edge preview, no blocks changed.
- `/hazard status` and `/ga debug hazards`: active hazard diagnostics.
- Safe-region preview state expires automatically and is removed with the region.
- KVICloud leave message is emitted only for initialized/authenticated arena sessions.
- Existing join message remains post-auth only.

Not yet claimed runtime-tested: Forge compilation, TAB/nameplate prefix wiring, JEG firing suppression inside safe region.

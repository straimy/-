# Gunner Arena 0.6.0-test3 source

Stage 11.3 adds the first persistent account/session economy layer.

Implemented in source:
- dependency-free atomic ProfileStorage under config/gunnerarena/players/<uuid>.properties
- ProfileService with dirty autosave and shutdown save
- volatile RoundSession retained across death and reset on round start
- starting Credits $500
- PvP kill reward +$300 while round is PLAYING
- lifetime kills/deaths and earned Credits bookkeeping
- /balance
- OP-only /credits get|give|set|take <player> [amount]
- 30 second profile autosave

Not implemented yet in test3:
- assists / +$100
- JEG item granting/loadout restoration
- ammo spawn entities and pickup integration
- Coins/Crystals admin commands
- GUI/NPC/client UI

The Forge layer still needs a real ForgeGradle/MDK compile and dedicated-server smoke test before this source is installable as a server mod.

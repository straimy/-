#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

SERVER_DIR="${1:-}"
LOG_FILE="${2:-}"

echo "[GA STAGE1 PROOF] 1/4 source gate"
./verify-source.sh

echo "[GA STAGE1 PROOF] 2/4 Forge 1.20.1 build on Java 17"
./build-forge17.sh

JAR="$(find build/libs -maxdepth 1 -type f -name '*.jar' ! -name '*sources*' ! -name '*dev*' | sort | tail -n1 || true)"
if [[ -z "$JAR" ]]; then
  echo "[GA STAGE1 PROOF] FAIL: no built runtime JAR in build/libs" >&2
  exit 20
fi

echo "[GA STAGE1 PROOF] 3/4 JAR structure: $JAR"
jar tf "$JAR" | grep -qx 'META-INF/mods.toml' || { echo "FAIL: mods.toml missing" >&2; exit 21; }
jar tf "$JAR" | grep -qx 'arena/GunnerArenaMod.class' || { echo "FAIL: GunnerArenaMod.class missing" >&2; exit 22; }
jar tf "$JAR" | grep -qx 'arena/forge/ArenaRuntime.class' || { echo "FAIL: ArenaRuntime.class missing" >&2; exit 23; }
jar tf "$JAR" | grep -qx 'arena/forge/GunnerCommands.class' || { echo "FAIL: GunnerCommands.class missing" >&2; exit 24; }

echo "[GA STAGE1 PROOF] JAR_BUILD_PROOF_OK"

if [[ -n "$SERVER_DIR" ]]; then
  echo "[GA STAGE1 PROOF] 4/4 dedicated preflight: $SERVER_DIR"
  ./dedicated-preflight.sh "$SERVER_DIR"
else
  echo "[GA STAGE1 PROOF] 4/4 skipped: no server directory supplied"
fi

if [[ -n "$LOG_FILE" ]]; then
  echo "[GA STAGE1 PROOF] runtime smoke: $LOG_FILE"
  ./runtime-smoke.sh "$LOG_FILE"
else
  echo "[GA STAGE1 PROOF] runtime smoke skipped: no latest.log supplied"
fi

echo "[GA STAGE1 PROOF] BUILD_EVIDENCE_READY"
echo "Built JAR: $JAR"
echo "NOTE: Stage 1 is COMPLETE only after this JAR is launched on a Java 17 Forge 47.4.10 dedicated server and the live checklist passes."

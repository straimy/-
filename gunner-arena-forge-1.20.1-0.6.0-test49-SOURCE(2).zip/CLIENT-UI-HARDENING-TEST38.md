# Client UI hardening — test38

- Main PLAY button is disabled when the Core snapshot is stale, player is unauthenticated/uninitialized, arena is regenerating, or arena is in ERROR.
- Main screen visibly distinguishes stale Core connectivity from /login and profile initialization states.
- Shop buy button now requires a fresh server snapshot.
- Catalog freshness is tracked separately; stale/empty catalog is not presented as a valid empty shop.
- While Shop is open, the client refreshes both snapshot and catalog once per second.
- On disconnect, cached snapshot/catalog/result state is cleared so a different server/session cannot inherit stale balances or weapons.
- UiAccessPolicy is pure Java and has a behavioral self-test.

This is source-complete UI hardening only; Forge compile/runtime is still required before declaring the client mod install-ready.

#!/usr/bin/env bash
set -euo pipefail

SERVER_DIR="${1:-.}"
if [[ ! -d "$SERVER_DIR" ]]; then
  echo "[GA PREFLIGHT] Server directory not found: $SERVER_DIR" >&2
  exit 2
fi
SERVER_DIR="$(cd "$SERVER_DIR" && pwd)"
MODS="$SERVER_DIR/mods"

JAVA_VER="$(java -version 2>&1 | head -n1 || true)"
JAVA_MAJOR="$(java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/^[[:space:]]*java.version = /{print $2; exit}' | sed 's/^1\.//' | cut -d. -f1)"
echo "[GA PREFLIGHT] Java: ${JAVA_VER:-missing}"
if [[ "$JAVA_MAJOR" != "17" ]]; then
  echo "[GA PREFLIGHT] FAIL: Forge/Minecraft 1.20.1 should run on Java 17; detected Java ${JAVA_MAJOR:-unknown}." >&2
  exit 3
fi

if [[ ! -d "$MODS" ]]; then
  echo "[GA PREFLIGHT] FAIL: mods/ not found under $SERVER_DIR" >&2
  exit 4
fi

if find "$MODS" -maxdepth 1 -type f -iname '*embeddium*.jar' | grep -q .; then
  echo '[GA PREFLIGHT] WARN: Embeddium is present on the dedicated server. Remove it from server mods; keep it client-side.'
fi
if find "$MODS" -maxdepth 1 -type f -iname '*oculus*.jar' | grep -q .; then
  echo '[GA PREFLIGHT] WARN: Oculus is present on the dedicated server. Remove it from server mods.'
fi

GA_COUNT="$(find "$MODS" -maxdepth 1 -type f -iname 'gunner-arena*.jar' | wc -l | tr -d ' ')"
if [[ "$GA_COUNT" -gt 1 ]]; then
  echo "[GA PREFLIGHT] FAIL: more than one Gunner Arena jar in mods/ ($GA_COUNT)." >&2
  find "$MODS" -maxdepth 1 -type f -iname 'gunner-arena*.jar' -print >&2
  exit 5
fi

if ! find "$MODS" -maxdepth 1 -type f -iname '*JEG*minigame*changes*.jar' | grep -q .; then
  echo '[GA PREFLIGHT] WARN: customized JEG minigame jar was not detected by filename.'
fi

if [[ -f "$SERVER_DIR/server.properties" ]] && grep -q '^online-mode=false' "$SERVER_DIR/server.properties"; then
  echo '[GA PREFLIGHT] INFO: online-mode=false detected; SAuth/auth gate must remain enabled.'
fi

echo '[GA PREFLIGHT] DEDICATED_PREFLIGHT_OK'

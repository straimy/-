# Test18 — safe-zone transitions + hazard command queue

Implemented in source:
- per-player ENTERED/LEFT safe-region tracking;
- actionbar feedback on crossing safe-zone boundary;
- /hazard meteor|tnt|web|shockwave|smoke|cryo|gravity|clear (OP only);
- hazard presets are non-destructive by contract and rejected inside safe regions;
- all active hazards are cleared when arena regeneration begins.

NOT YET CLAIMED RUNTIME-COMPLETE:
- Forge visual/world executor for falling meteor/TNT/web/smoke effects still needs real Forge compilation and dedicated-server testing;
- client camera shake / advanced particles belong to UI/RP stage.

# Gunner Arena 0.6.0-test30 — death/reward idempotency

## Added
- `DeathEventGuard`: one-shot acceptance fence for fatal player events.
- Duplicate fatal callbacks inside a 20-tick window cannot mutate death/kill/assist/Credits twice.
- The guard resets on real player respawn and forgets state on logout.
- Recent damage history is cleared on respawn/logout/server stop to prevent assist carry-over into the next life.

## Why
Modded projectile/gun stacks can produce overlapping callbacks around fatal damage. The arena economy must be explicitly idempotent rather than depending only on Forge event ordering or the current player state.

## Status
Source implemented. Pure-Java/source gate can verify structure. Forge runtime behavior remains pending a real Forge 47.4.10 + Java 17 build/test.

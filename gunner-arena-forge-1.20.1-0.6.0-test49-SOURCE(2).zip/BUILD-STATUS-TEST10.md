# Gunner Arena 0.6.0-test10 build status

This stage adds a reproducible Forge bootstrap instead of compiling against handwritten stubs.

## One-command Linux build

```bash
./build-linux.sh
```

The script:
1. downloads the official Forge 1.20.1-47.4.10 MDK from `maven.minecraftforge.net`;
2. validates MDK SHA-1 `31133abd261aa4d23672d1820db06ccec80326ad`;
3. takes Gradle Wrapper files from that official MDK;
4. runs `verify-source.sh`;
5. runs the real ForgeGradle `clean build`.

No fake Forge API stubs are used.

## Runtime gate after successful compilation

Do not call a jar production-ready until it passes:
- dedicated server reaches `Done`;
- login succeeds without `Invalid player data`;
- `/ga debug round` works;
- `/ga debug generator` reads CG BETA;
- at least 3 full `PLAYING -> REGENERATING -> READY -> PLAYING` cycles;
- `/play`, `/addspawn`, death/respawn and spawn protection work;
- JEG purchases and ammo points work;
- server restart preserves configured arena points and persistent profiles.

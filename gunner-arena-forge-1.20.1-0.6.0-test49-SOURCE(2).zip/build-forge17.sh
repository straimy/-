#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"

# Source the resolver in this shell so JAVA_HOME/PATH survive into Gradle.
source "$ROOT/java17-env.sh"
exec "$ROOT/build-linux.sh"

# Stage 1 blocker evidence — test49

Stage 1 is intentionally not marked complete until a real ForgeGradle build and dedicated-server launch pass.

This source tree now supports an **offline handoff** for the two external inputs the current container cannot obtain itself:

1. a JDK 17 directory or `.tar.gz` archive;
2. the official Forge `1.20.1-47.4.10` MDK zip with SHA1 `31133abd261aa4d23672d1820db06ccec80326ad`.

Run:

```bash
./stage1-build-input.sh /path/to/jdk17-or.tar.gz /path/to/forge-1.20.1-47.4.10-mdk.zip
```

The script refuses wrong Java versions and wrong MDK hashes before invoking `stage1-proof.sh`.

`build-environment-report.sh` records the exact build environment and whether the MDK is cached. It is evidence only; it does not claim a successful Forge build.

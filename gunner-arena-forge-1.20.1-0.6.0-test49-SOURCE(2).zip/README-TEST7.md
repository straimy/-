# Gunner Arena Core 0.6.0-test9 — Forge build gate

Target: Minecraft 1.20.1, Forge 47.4.10, Java 17.

This stage does not claim a runtime-tested Forge JAR unless Gradle/Forge dependencies are actually resolved and `gradlew build` succeeds.

## Gate order
1. `bash verify-source.sh`
2. Run with Forge MDK/Gradle wrapper: `./gradlew clean build`
3. Put only the produced `build/libs/gunner-arena-forge-1.20.1-server-0.6.0-test9.jar` on a TEST server.
4. Verify login + `/ga debug round` before testing map regeneration.

Do not install a JAR produced against hand-written Forge stubs.

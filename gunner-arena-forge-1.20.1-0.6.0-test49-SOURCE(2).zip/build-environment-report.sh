#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$ROOT/STAGE1-ENVIRONMENT-REPORT.txt}"
{
  echo 'Gunner Arena Stage-1 build environment report'
  echo "generated_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "kernel=$(uname -srmo 2>/dev/null || true)"
  echo "arch=$(uname -m 2>/dev/null || true)"
  echo "java=$(java -version 2>&1 | head -n1 || true)"
  echo "javac=$(javac -version 2>&1 || true)"
  echo "java_home=${JAVA_HOME:-}"
  echo "curl=$(command -v curl || true)"
  echo "wget=$(command -v wget || true)"
  echo "forge_mdk_cached=$([[ -s "$ROOT/.forge-bootstrap/forge-1.20.1-47.4.10-mdk.zip" ]] && echo yes || echo no)"
  if [[ -s "$ROOT/.forge-bootstrap/forge-1.20.1-47.4.10-mdk.zip" ]]; then
    echo "forge_mdk_sha1=$(sha1sum "$ROOT/.forge-bootstrap/forge-1.20.1-47.4.10-mdk.zip" | awk '{print $1}')"
  fi
  echo "gradle_wrapper=$([[ -x "$ROOT/gradlew" ]] && echo yes || echo no)"
} > "$OUT"
echo "$OUT"

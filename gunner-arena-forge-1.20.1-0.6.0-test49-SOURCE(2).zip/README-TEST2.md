# Gunner Arena Core 0.6.0-test2 source

Stage 11.2 adds the first Forge-side arena participation layer on top of the previous typed Forge adapter.

Implemented in source:
- persistent lobby/combat spawn coordinates in `config/gunnerarena/arena-spawns.properties`
- `/setspawn`, `/addspawn`, `/clearspawns`, `/listspawns`, `/removespawn nearest`
- `/play` and `/spawn`
- queued player state when the round is not PLAYING
- safe-spawn selection biased toward distance from living players
- death -> DEAD state and respawn -> arena/lobby routing
- 3 second spawn protection
- protected victim cannot be damaged
- protected attacker consumes protection on first offensive damage event and that event is cancelled
- `/ga debug player`
- round start moves QUEUED players into the arena
- regeneration moves combat players back to lobby before CG BETA rebuild

Important:
- This is SOURCE, not a server-installable jar yet.
- Forge linking/build was not performed in this environment because ForgeGradle/MDK dependencies are unavailable locally.
- Pure non-Forge core sources were compiled with `javac --release 17` successfully.
- The first Forge build should test server startup, login, command tree sync, spawn persistence, /play, death/respawn and protection before adding JEG inventory/economy hooks.

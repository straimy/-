# Test28 — safe-zone recovery hardening

## Added
- `LivingKnockBackEvent` cancellation for unauthenticated players and players inside a configured SafeRegion.
- Server-side void/malformed-position recovery for authenticated players.
- Recovery clears fire, velocity and fall distance, heals the player and teleports to the configured `/setspawn` lobby when possible.

## Why
SafeRegion should be a true non-combat lobby: no damage, no weapon projectiles, and no knockback. The recovery fence also prevents map holes/void falls from leaving players stuck or repeatedly dying.

## Status
This is source-level hardening. ForgeGradle compile and dedicated-server runtime proof are still required before Stage 1 is marked complete.

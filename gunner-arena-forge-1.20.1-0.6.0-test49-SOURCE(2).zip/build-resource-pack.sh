#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/dist"
PACK_NAME="KVICloud-GunnerArena-RP-1.20.1-test49.zip"
mkdir -p "$OUT"
rm -f "$OUT/$PACK_NAME" "$OUT/$PACK_NAME.sha1" "$OUT/$PACK_NAME.sha256"
(
  cd "$ROOT/resource-pack"
  find . -type f ! -name '*.DS_Store' -print0 | sort -z | xargs -0 zip -X -q "$OUT/$PACK_NAME"
)
sha1sum "$OUT/$PACK_NAME" | awk '{print $1}' > "$OUT/$PACK_NAME.sha1"
sha256sum "$OUT/$PACK_NAME" | awk '{print $1}' > "$OUT/$PACK_NAME.sha256"
echo "RESOURCE_PACK_OK $OUT/$PACK_NAME"
echo "SHA1=$(cat "$OUT/$PACK_NAME.sha1")"
echo "SHA256=$(cat "$OUT/$PACK_NAME.sha256")"

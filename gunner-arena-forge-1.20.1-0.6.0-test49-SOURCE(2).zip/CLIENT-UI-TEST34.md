# Client UI — test34

Status: **source implementation only**. This is a separate client-side Forge mod module under `client-ui/`; it is not installed on the live server and no Forge client runtime test has been performed yet.

Implemented in this pass:
- independent `gunnerarena_ui` Forge client mod scaffold for Minecraft 1.20.1 / Forge 47.4.10 / Java 17;
- fullscreen `MainArenaScreen` with ИГРАТЬ / МАГАЗИН / ПРОФИЛЬ;
- responsive layout math (`UiLayout`) rather than hardcoded 1920x1080 coordinates;
- non-pausing screens suitable for multiplayer;
- lightweight KVICloud sci-fi backdrop and reusable button/panel styling;
- G key opens the menu for development testing;
- ИГРАТЬ currently delegates to the existing authoritative `/play` server command;
- Shop/Profile shells exist but intentionally do not fake data before the server snapshot protocol is implemented;
- pure Java 17 layout self-test.

Next UI pass should implement the Core<->UI network protocol and a read-only player snapshot (credits, currencies, round state, stats), then make Shop/Profile data-driven. NPC click opening comes after that protocol so the server remains authoritative.

# Gunner Arena test41 — fire-state controller

Status: source implementation only. This is not a claim that Forge/JEG projectile spawning has been compiled or runtime-tested.

Added a side-neutral server-authoritative fire-state controller for Gunner Arena-owned weapons:
- SEMI requires a fresh trigger press and respects RPM cooldown.
- AUTO fires while held, limited by the weapon RPM.
- BURST_3 launches exactly three scheduled shots from one press and can finish after trigger release.
- A new burst requires a release + fresh press.
- VKR-47 mode cycling is SEMI -> BURST_3 -> AUTO -> SEMI.
- Unsupported modes are rejected (for example P9 -> AUTO).
- At most one shot is released per controller update so lag cannot dump a complete burst/magazine in one server tick.
- Per-actor/weapon state can be explicitly discarded on logout/loadout changes.

The controller deliberately does not import Forge, Minecraft client, or JEG projectile classes. The next integration layer must consume FireUpdate and connect it to real registered items, ammo/reload state and the actual projectile/hitscan implementation.

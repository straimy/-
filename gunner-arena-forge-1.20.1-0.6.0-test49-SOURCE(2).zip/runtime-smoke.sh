#!/usr/bin/env bash
set -euo pipefail
LOG="${1:-logs/latest.log}"
if [[ ! -f "$LOG" ]]; then
  echo "[GA SMOKE] log not found: $LOG" >&2
  exit 2
fi
fail=0
check_absent() {
  local label="$1" pattern="$2"
  if grep -Eiq "$pattern" "$LOG"; then
    echo "[GA SMOKE] FAIL: $label"
    grep -Ein "$pattern" "$LOG" | tail -n 5
    fail=1
  else
    echo "[GA SMOKE] OK: $label"
  fi
}
check_present() {
  local label="$1" pattern="$2"
  if grep -Eiq "$pattern" "$LOG"; then
    echo "[GA SMOKE] OK: $label"
  else
    echo "[GA SMOKE] WARN: $label not observed in this log"
  fi
}

echo "[GA SMOKE] analyzing $LOG"
check_absent "no dedicated-side client class crash" 'invalid dist DEDICATED_SERVER|ClientLevel for invalid dist'
check_absent "no ticking-entity fatal crash" 'ReportedException: Ticking entity|Encountered an unexpected exception'
check_absent "no Gunner Arena linkage errors" 'NoSuchMethodError|NoClassDefFoundError|ClassCastException.*gunner|Exception.*gunnerarena'
check_absent "no flare projectile crash" 'FlareProjectileEntity\.onProjectileTick'
check_present "Forge dedicated server reached Done" 'Done \([^)]*s\)! For help, type "help"'
check_present "Gunner Arena mod loaded" 'gunnerarena|Gunner Arena Core'
check_present "player login observed" 'logged in with entity id|joined the game'

if [[ "$fail" -ne 0 ]]; then
  echo '[GA SMOKE] RUNTIME_SMOKE_FAIL' >&2
  exit 1
fi
echo '[GA SMOKE] RUNTIME_SMOKE_PASS (only checks evidence present in this log)'

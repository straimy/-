#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CORE_JAR="${1:-}"
UI_JAR="${2:-}"
[[ -f "$CORE_JAR" ]] || { echo "FULL_RELEASE_BLOCKED: compiled Core jar is required" >&2; exit 20; }
[[ -f "$UI_JAR" ]] || { echo "FULL_RELEASE_BLOCKED: compiled Client UI jar is required" >&2; exit 21; }
"$ROOT/build-resource-pack.sh" >/dev/null
RP="$ROOT/dist/KVICloud-GunnerArena-RP-1.20.1-test49.zip"
OUT="$ROOT/dist/KVICloud-GunnerArena-FULL-test49"
rm -rf "$OUT"
mkdir -p "$OUT/server/mods" "$OUT/client/mods" "$OUT/client/resourcepacks" "$OUT/docs"
cp "$CORE_JAR" "$OUT/server/mods/"
cp "$CORE_JAR" "$OUT/client/mods/"
cp "$UI_JAR" "$OUT/client/mods/"
cp "$RP" "$OUT/client/resourcepacks/"
cp "$ROOT/INTEGRATION-MANIFEST.properties" "$OUT/"
cp "$ROOT/FULL-INTEGRATION-TEST48.md" "$OUT/docs/"
cat > "$OUT/INSTALL.txt" <<'TXT'
KVICloud Gunner Arena FULL test49

SERVER:
1. Java 17.
2. Forge 1.20.1-47.4.10.
3. Put the Gunner Arena Core jar in server/mods.
4. Keep required server dependencies/JEG/SAuth already used by the server.
5. Do not give/use jeg:flare_gun; it remains quarantined.

CLIENT:
1. Forge 1.20.1-47.4.10.
2. Put Gunner Arena Core + Gunner Arena UI in client/mods.
3. Put the included KVICloud resource pack in resourcepacks and enable it.

This package is not proof of live-server compatibility until dedicated runtime smoke passes.
TXT
find "$OUT" -type f -print0 | sort -z | xargs -0 sha256sum > "$OUT/SHA256SUMS.txt"
ARCHIVE="$ROOT/dist/KVICloud-GunnerArena-FULL-test49.zip"
rm -f "$ARCHIVE"
(cd "$ROOT/dist" && zip -X -qr "$ARCHIVE" "$(basename "$OUT")")
echo "FULL_RELEASE_ASSEMBLED $ARCHIVE"

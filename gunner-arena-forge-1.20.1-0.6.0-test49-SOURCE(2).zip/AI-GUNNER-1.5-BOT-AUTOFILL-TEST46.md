# Test46 — AI Gunner 1.5 + bot autofill source

Status: SOURCE IMPLEMENTED / Forge runtime not yet proven.

## Implemented
- Hidden AI profiles: RUSHER, ASSAULT, MARKSMAN, SURVIVOR, GUNSLINGER.
- High-level AI state machine: SEARCH, CHASE, ENGAGE, TAKE_COVER, HEAL, RELOAD, PATHFIND, RETURN_TO_GAME.
- Deterministic decisions from a side-neutral combat snapshot; Baritone is requested only when path recovery is needed.
- Autofill policy: real players <5 => 4 bots; <10 => 2 bots; >=10 => 0 bots.
- Manual target override 0..8 and autofill on/off.
- One bot slot rotates at a time; each slot lives roughly 2–5 minutes.
- Reserved names use the agreed public-looking pool and never expose a BOT prefix.
- Each reserved bot receives a 256-bit random launch token; only SHA-256 is kept in the token service.
- `/botauth <token>` binds an external AI Gunner client to its reserved username and marks it internally as `gunnerarena_bot` while it remains publicly a normal PLAYER.
- Real-player counts explicitly exclude authenticated bot clients.
- Admin diagnostics: `/bots status`, `/bots list`, `/bots rotate`, `/bots autofill on|off`, `/bots target <0..8>`.
- Bot roster/tokens are cleared on server shutdown and rotated slots revoke old tokens.

## Important integration boundary
The Core now owns population, identity, secure bot authentication, rotation and high-level AI decisions. It does NOT launch external Minecraft client processes by itself. The actual AI Gunner/Baritone client process must connect using the reserved name + token. That process/runtime wiring belongs to the final integration stage and must be live-tested before calling bots runtime-ready.

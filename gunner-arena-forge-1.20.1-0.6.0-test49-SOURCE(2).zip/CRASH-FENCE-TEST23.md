# Gunner Arena 0.6.0-test23 — confirmed flare projectile hard fence

Status: source hardening only; not yet ForgeGradle-built or dedicated-runtime-tested here.

## Change
The known JEG 0.13.2 `FlareProjectileEntity` crash is now blocked at `EntityJoinLevelEvent`
before the projectile receives its first world tick. This protects the server even if the flare
was spawned through JEG's custom network path, `/give`, commands, or a legacy inventory.

The guard deliberately compares the runtime class name rather than importing JEG classes,
so Gunner Arena does not gain a hard binary dependency on JEG.

Also removed a duplicate `pendingRoundStartAtTick = -1L` assignment in the WAITING -> PLAYING path.

Known crash signature:
`Attempted to load class net/minecraft/client/multiplayer/ClientLevel for invalid dist DEDICATED_SERVER`
from `ttv.migami.jeg.entity.projectile.FlareProjectileEntity.onProjectileTick`.

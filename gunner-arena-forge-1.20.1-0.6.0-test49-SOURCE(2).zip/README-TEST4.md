# Gunner Arena 0.6.0-test4 source

Stage 11.4 source integration:
- recent damage tracker with 8s assist window
- $100 assist award and persistent assist/damage statistics
- real registry-backed JEG ItemStack bridge (existing registered JEG ids only)
- `/buy <namespace:item>` server-authoritative backend
- tactical knife in slot 1
- secondary slot 2 / primary slot 3
- purchased round loadout restored after respawn
- emergency one-magazine ammo floor after respawn

Important: custom `gunnerarena:*` guns remain catalog definitions only; their Item registration/models/fire modes are a later weapon module. This source tree has not been ForgeGradle-linked in this environment, so it is not yet an installable server JAR.

# Gunner Arena test32 — Live Core hardening

## Combat logout fence
- A disconnect is punished only while the player is ALIVE in a PLAYING round and has recent qualifying PvP damage inside the normal 8-second assist window.
- The most recent qualifying attacker receives the kill. Other qualifying attackers receive assists.
- A normal/network disconnect with no qualifying recent PvP damage is not counted as a death.
- Evidence is consumed exactly once and then normal logout cleanup runs.

## Profile persistence diagnostics
- ProfileService.save now reports success/failure instead of silently swallowing IOException.
- Failed saves remain dirty for the next autosave attempt.
- saveFailures and dirtyCount are exposed for runtime diagnostics.
- ProfileStorage already uses temp-file + atomic replace where supported; test32 preserves that crash-safe write path.

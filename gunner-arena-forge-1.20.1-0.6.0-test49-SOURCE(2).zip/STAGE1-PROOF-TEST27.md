# Stage 1 proof harness — test27

`stage1-proof.sh` is the single evidence command for the final Forge/Core gate.

It deliberately separates four claims:

1. `SOURCE_GATE_OK` — static/source checks only.
2. `JAR_BUILD_PROOF_OK` — a real ForgeGradle build on a real JDK 17 produced a runtime JAR with the expected classes and `mods.toml`.
3. `DEDICATED_PREFLIGHT_OK` — the target server directory passes basic environment/mod checks.
4. `RUNTIME_SMOKE_PASS` — a real dedicated-server log contains no known linkage/dist/ticking-entity/flare crash signatures and reached the expected startup state.

Usage:

```bash
./stage1-proof.sh
```

Build + target server preflight:

```bash
./stage1-proof.sh /home/container
```

Build + preflight + smoke analysis:

```bash
./stage1-proof.sh /home/container /home/container/logs/latest.log
```

This script **does not deploy or replace any live server JAR**. Deployment remains a separate explicit action.

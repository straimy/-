# Gunner Arena test47 — RPG / Skill Tree source-complete pass

Status boundary:
- RPG progression, persistence, server-authoritative unlock validation, specialization selection, skill-tree UI/network source and behavioral self-tests are implemented in source.
- This is NOT a successful ForgeGradle build and NOT a dedicated-server runtime proof.
- Remaining end-to-end balancing/application of every passive modifier is part of FULL integration/runtime verification. Damage and Credits modifiers are already wired server-side; the remaining modifier types are represented by the capped effect engine and are not claimed runtime-tested.

## Progression
- Maximum level: 100.
- Total-lifetime XP curve is owned by `RpgProgression`.
- Each gained level grants 10 skill points.
- Arena kill: +120 XP.
- Arena assist: +45 XP.
- Existing `level`, `xp`, `skillPoints`, `prestige`, `specialization`, and `unlockedSkills` stay in the persistent player profile.
- Profile data version bumped to 2.

## Skill tree
Six branches, four launch nodes each (24 total):
- COMBAT
- MOBILITY
- SURVIVAL
- SUPPLY
- ECONOMY
- HANDLING

Server validates cost, minimum level, prerequisites and build limits. Current build limits:
- max 8 normal passives;
- max 3 major skills;
- max 1 active skill.

The client can request the tree and request an unlock only by skill ID. Costs, prerequisites, availability and the actual mutation are decided by Core.

## Specializations
Selection begins at level 25. Launch IDs:
- ASSAULT
- MARKSMAN
- BREACHER
- SCOUT
- SURVIVOR
- GUNSLINGER

A normal profile may choose once. Admin reset/migration can change persisted state later; client cannot set specialization data directly.

## Effects and caps
`RpgEffects` aggregates unlocked skills and applies hard caps, including a max-health target ceiling of 26 HP and conservative damage/economy caps. `DAMAGE_MULT` is wired into Gunner Arena custom hitscan damage and `CREDIT_GAIN` into kill/assist Credits. Other effect types are represented centrally for final Forge integration rather than scattered magic constants.

## Commands
Player:
- `/skills list`
- `/skills unlock <id>`
- `/specialization choose <id>`

OP/admin:
- `/skills reset`
- `/xp give <player> <amount>`
- `/skillpoints give <player> <amount>`

## Client UI / protocol
Core/UI protocol is v5.
- fourth navigation route: `НАВЫКИ`;
- server sends a bounded skill-tree snapshot;
- the client sends only `skillId` for an unlock request;
- anti-spam bookkeeping exists server-side;
- the screen shows level, remaining points, specialization and paged skill buttons.

## Behavioral evidence
Pure Java 17 self-tests cover:
- XP/level curve and skill-point awards;
- prerequisite/cost enforcement;
- specialization level/one-choice rule;
- reset/refund behavior;
- capped effect aggregation;
- RPG fields persistence round-trip;
- client skill-tree store lifecycle.

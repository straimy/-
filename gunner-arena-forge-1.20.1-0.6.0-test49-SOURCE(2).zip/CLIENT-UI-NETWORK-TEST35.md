# Gunner Arena test35 — Core ↔ UI snapshot protocol

Status: source implementation only; Forge compile/runtime still required.

## Added
- Separate `gunnerarena:ui` SimpleChannel on Core and UI, protocol v1.
- C2S snapshot request; S2C immutable snapshot response.
- Core never accepts money/stats from the client. It only serializes server-owned state.
- Snapshot includes auth/init state, round timer/state, round Credits, Coins, Crystals, level/XP/skill points,
  lifetime combat stats and current-round K/D/A/damage.
- UI requests immediately when opened and then once per second while a Gunner Arena screen is open.
- Main screen, Profile and Shop now render real snapshot fields instead of invented placeholder values.

## Security boundary
The request packet contains no player-controlled IDs, coordinates, prices or balances. The server derives the sender from
Forge network context and builds the snapshot from that `ServerPlayer` only.

## Compatibility
Core and UI use the same channel ID and protocol discriminator ordering. This is intentionally strict protocol v1 in
source; changing field order requires a protocol bump. Forge runtime compatibility still needs the real 47.4.10 build.

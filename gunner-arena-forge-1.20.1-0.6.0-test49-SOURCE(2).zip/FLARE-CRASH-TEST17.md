# Gunner Arena 0.6.0-test17 — confirmed JEG flare crash

Evidence from live server log on 2026-08-14:

- server crashes while ticking `ttv.migami.jeg.entity.projectile.FlareProjectileEntity`;
- `FlareProjectileEntity.onProjectileTick(FlareProjectileEntity.java:112)` attempts to load
  `net.minecraft.client.multiplayer.ClientLevel`;
- Forge RuntimeDistCleaner rejects that class on `DEDICATED_SERVER`;
- this is a JEG 0.13.2 dedicated-server bug in the flare projectile path, not an OOM;
- `jeg:flare_gun` is quarantined from Gunner Arena `/buy`;
- `jeg:flamethrower` and `jeg_cfg:fire_sweeper` are no longer accused without evidence, but still require smoke testing.

Admin diagnostic:

`/ga debug quarantine`

Until JEG is patched, do not give/use `jeg:flare_gun` on the public dedicated server.
A proper permanent fix should patch the JEG flare projectile so all ClientLevel/render-only logic is client-gated and never referenced from dedicated-server tick code.

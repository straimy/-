# Stage 1 runtime evidence — test26

New admin/debug command: `/ga debug stage1`.

It is read-only and prints:
- whether the running JVM is Java 17;
- lobby spawn configured;
- combat spawn count;
- safe-region count;
- JEG registry presence;
- confirmed flare-gun quarantine;
- CG BETA `data` scoreboard objective;
- current round/hazard/player counts.

`STATIC_RUNTIME_READY` is not the same as a passed live test. Stage 1 closes only after the built Forge JAR actually boots and the live flow login -> safe region -> JEG fence -> /play -> regeneration passes.

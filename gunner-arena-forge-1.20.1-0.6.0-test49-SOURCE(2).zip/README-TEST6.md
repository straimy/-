# Gunner Arena 0.6.0-test6 SOURCE

Stage 11.6 server polish source.

Added:
- conservative `/ga cleanup legacy` for old GunnerArena ArmorStand/Display/Interaction entities
- `/ga debug entities`
- GunnerArena-bound NBT on knife and purchased/restored weapons
- Forge `ItemTossEvent` guard so arena-bound combat items cannot be dropped
- version banner updated to test6

Still not claimed as a built/tested Forge server jar. ForgeGradle dedicated-server build remains the next gate.

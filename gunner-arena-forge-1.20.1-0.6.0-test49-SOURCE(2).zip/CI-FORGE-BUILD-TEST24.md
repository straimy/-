# test24 — reproducible Forge build gate

This revision adds a GitHub Actions build gate for the exact server target:

- Minecraft 1.20.1
- Forge 47.4.10
- Temurin JDK 17
- official Forge MDK bootstrap via `build-linux.sh`

The CI job does not fake compilation. It runs `verify-source.sh`, downloads and SHA1-checks the official Forge MDK, runs `gradlew clean build`, checks the resulting JAR contains `META-INF/mods.toml` and `arena/GunnerArenaMod.class`, and uploads the JAR as a workflow artifact.

A green CI build proves Forge compilation. It does **not** by itself prove dedicated runtime behavior; the next gate remains `dedicated-preflight.sh` + actual server launch + `runtime-smoke.sh`.

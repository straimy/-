# Gunner Arena 0.6.0-test20

## Added in source
- Forge PlayerEvent.NameFormat -> KVICloud decorated player name.
- Forge PlayerEvent.TabListNameFormat -> KVICloud decorated TAB name.
- TAB refresh after auth initialization and every 5 seconds so /op and /deop are reflected without restart.
- EntityJoinLevelEvent projectile fence: projectiles owned by unauthenticated players or players standing in SafeRegion are canceled server-side.
- This fence is JEG-agnostic and does not import client/JEG classes.

## Still requires real Forge runtime verification
- Exact nameplate rendering behavior with the current client stack.
- JEG custom projectile subclasses all inheriting vanilla Projectile as expected.
- /op and /deop visual refresh in TAB/nameplate.
- Dedicated server build/run on Java 17.

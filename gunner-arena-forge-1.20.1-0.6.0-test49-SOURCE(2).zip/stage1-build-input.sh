#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
JDK17_INPUT="${1:-}"
MDK_INPUT="${2:-}"
CACHE="$ROOT/.forge-bootstrap"
EXPECTED_MDK_SHA1='31133abd261aa4d23672d1820db06ccec80326ad'
mkdir -p "$CACHE"

if [[ -n "$JDK17_INPUT" ]]; then
  if [[ -d "$JDK17_INPUT" && -x "$JDK17_INPUT/bin/java" ]]; then
    export JAVA_HOME="$(cd "$JDK17_INPUT" && pwd)"
  elif [[ -f "$JDK17_INPUT" ]]; then
    TMP="$CACHE/jdk17-input"
    rm -rf "$TMP" && mkdir -p "$TMP"
    tar -xzf "$JDK17_INPUT" -C "$TMP"
    JAVA_BIN="$(find "$TMP" -mindepth 2 -maxdepth 3 -type f -path '*/bin/java' -print -quit)"
    [[ -n "$JAVA_BIN" ]] || { echo '[GA INPUT] JDK archive does not contain bin/java' >&2; exit 31; }
    export JAVA_HOME="$(dirname "$(dirname "$JAVA_BIN")")"
  else
    echo "[GA INPUT] JDK17 input not found: $JDK17_INPUT" >&2; exit 30
  fi
  export PATH="$JAVA_HOME/bin:$PATH"
fi

JAVA_MAJOR="$(java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/^[[:space:]]*java.version = /{print $2; exit}' | sed 's/^1\.//' | cut -d. -f1)"
[[ "$JAVA_MAJOR" == '17' ]] || { echo "[GA INPUT] Java 17 required, active Java is $JAVA_MAJOR" >&2; exit 32; }
echo "[GA INPUT] Java OK: $(java -version 2>&1 | head -n1)"

if [[ -n "$MDK_INPUT" ]]; then
  [[ -f "$MDK_INPUT" ]] || { echo "[GA INPUT] MDK not found: $MDK_INPUT" >&2; exit 33; }
  ACTUAL="$(sha1sum "$MDK_INPUT" | awk '{print $1}')"
  [[ "$ACTUAL" == "$EXPECTED_MDK_SHA1" ]] || { echo "[GA INPUT] Forge MDK SHA1 mismatch: $ACTUAL" >&2; exit 34; }
  cp -f "$MDK_INPUT" "$CACHE/forge-1.20.1-47.4.10-mdk.zip"
  echo '[GA INPUT] Forge 47.4.10 MDK checksum OK and cached.'
fi

exec "$ROOT/stage1-proof.sh"

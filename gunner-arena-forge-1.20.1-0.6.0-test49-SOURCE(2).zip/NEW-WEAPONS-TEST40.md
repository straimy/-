# Test40 — first Gunner Arena weapon tuning layer

Status: SOURCE ONLY. This does not claim that new firearm Items are registered or usable in Forge/JEG yet.

Added a side-neutral, server-authoritative tuning layer for the first four planned weapons:
- P9
- PX-18
- VKR-47
- Raven M96

The tuning layer defines damage, head multiplier, RPM, burst size, reload timing, hip/ADS spread, recoil, movement multiplier and supported fire modes. It deliberately contains no JEG/client imports so it can be tested with Java 17 before ForgeGradle is available.

`CustomWeaponArsenal.validateAgainst(WeaponCatalog)` prevents the shop catalog and combat tuning from silently drifting on IDs/fire modes.

VKR-47 is explicitly modeled as a real 3-shot burst capable weapon (SEMI/BURST_3/AUTO). Actual projectile/fire-controller integration and Item registration are still pending and must be verified against the custom JEG build before these weapons are marked playable.

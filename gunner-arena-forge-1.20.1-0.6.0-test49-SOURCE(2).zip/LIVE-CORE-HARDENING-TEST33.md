# Live Core hardening — TEST33

This pass closes the planned source-side Live Core hardening block before dedicated runtime validation.

## Round/session boundary fixes
- Only players who actually queued for a new match are initialized when the round starts.
- Authenticated lobby spectators no longer have Credits/loadout reset and no longer increment `roundsPlayed` just because a round started.
- Late `/play` joins initialize volatile round state exactly once for the current `roundNumber`.
- Every ArenaPlayerSession carries an `activeRoundNumber`; round stop clears it so stale round state cannot leak into a later match.

## Profile persistence failure recovery
- `ProfileService.logout` no longer discards a profile after a failed disk save.
- A failed logout keeps the latest profile dirty in memory for autosave/reconnect recovery.
- A reconnect reuses the retained newer profile instead of reloading stale disk data.
- A later successful autosave releases retained offline state.

## Verification
`verify-source.sh` includes behavior tests for ArenaPlayerSession round identity and failed-save reconnect retention.

Status: source hardening only. Forge compilation and dedicated runtime behavior are still separate evidence gates.

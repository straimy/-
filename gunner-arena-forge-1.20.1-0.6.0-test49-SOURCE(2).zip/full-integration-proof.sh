#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
echo '[FULL 1/8] Source gate'
./verify-source.sh >/tmp/ga-source-gate.log
tail -1 /tmp/ga-source-gate.log
echo '[FULL 2/8] Core/UI protocol agreement'
CORE_PROTO="$(grep -E 'PROTOCOL_VERSION = "[0-9]+"' src/main/java/arena/forge/net/ArenaNetwork.java | head -1 | sed -E 's/.*"([0-9]+)".*/\1/')"
UI_PROTO="$(grep -E 'PROTOCOL_VERSION = "[0-9]+"' client-ui/src/main/java/arena/client/net/ArenaClientNetwork.java | head -1 | sed -E 's/.*"([0-9]+)".*/\1/')"
[[ "$CORE_PROTO" == "$UI_PROTO" && "$CORE_PROTO" == "5" ]]
echo '[FULL 3/8] Integration manifest'
grep -q '^network_protocol=5$' INTEGRATION-MANIFEST.properties
grep -q '^minecraft=1.20.1$' INTEGRATION-MANIFEST.properties
grep -q '^forge=47.4.10$' INTEGRATION-MANIFEST.properties
echo '[FULL 4/8] Resource-pack build'
./build-resource-pack.sh >/tmp/ga-rp-build.log
RP='dist/KVICloud-GunnerArena-RP-1.20.1-test49.zip'
test -s "$RP"
echo '[FULL 5/8] Resource-pack contents'
unzip -tq "$RP" >/dev/null
for w in p9 px18 vkr47 raven_m96; do unzip -l "$RP" | grep -q "assets/gunnerarena/models/item/$w.json"; unzip -l "$RP" | grep -q "assets/gunnerarena/textures/item/$w.png"; done
unzip -l "$RP" | grep -q 'pack.png'
echo '[FULL 6/8] Known crash quarantine remains enforced'
grep -q 'jeg:flare_gun' src/main/java/arena/weapon/WeaponSafetyPolicy.java
grep -q '^quarantined_weapon=jeg:flare_gun$' INTEGRATION-MANIFEST.properties
echo '[FULL 7/8] FULL assembler is fail-closed'
set +e
./assemble-full-release.sh /does/not/exist/core.jar /does/not/exist/ui.jar >/tmp/ga-full-fail.log 2>&1
RC=$?
set -e
[[ "$RC" -ne 0 ]]
grep -q 'FULL_RELEASE_BLOCKED' /tmp/ga-full-fail.log
echo '[FULL 8/8] Hash evidence'
test -s "$RP.sha1"; test -s "$RP.sha256"
echo FULL_INTEGRATION_SOURCE_PROOF_OK

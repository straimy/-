# Gunner Arena test25 — Forge build handoff

This revision intentionally adds no gameplay features. It removes the last local-environment ambiguity before the real Forge gate.

## One-command build

```bash
./build-forge17.sh
```

The wrapper:
1. locates a real JDK 17 (`JAVA_HOME_17`, `JAVA_HOME`, or common Linux paths),
2. refuses non-17 runtimes,
3. runs the existing official Forge 47.4.10 MDK bootstrap,
4. runs the source gate,
5. runs `gradlew clean build`.

If the host only has Java 21/25, set `JAVA_HOME_17` or change the container image. The script does not silently build with the wrong JDK.

## Dedicated smoke

After placing the built JAR on a test server and reaching `Done`, run:

```bash
./runtime-smoke.sh /home/container/logs/latest.log
```

A source gate is not a substitute for Forge compilation or a dedicated launch.

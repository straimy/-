# Gunner Arena 0.6.0-test22 — dedicated runtime smoke gate

This pass does not claim a successful Forge build/runtime by itself. It tightens the handoff before the first real dedicated launch.

Changes:
- removed the stale hard-coded `test20` login banner; runtime no longer lies about the source revision;
- removed an unused duplicate `arena.forge.region.SafeRegionService` implementation so only one Forge safe-region adapter remains;
- added `runtime-smoke.sh` for post-launch log validation;
- smoke gate detects the confirmed JEG flare crash signature (`ClientLevel` on `DEDICATED_SERVER` / `FlareProjectileEntity.onProjectileTick`), ticking-entity fatals and common linkage failures;
- smoke gate reports missing observations as WARN rather than pretending an unobserved gameplay path passed.

Recommended live flow:
1. Java 17 + `dedicated-preflight.sh /home/container`
2. build/install exactly one Gunner Arena jar
3. start dedicated server and execute login → safe region → /play → round → regeneration
4. run `./runtime-smoke.sh /home/container/logs/latest.log`
5. inspect any WARN manually; only then close Forge build/runtime.

# Test21 — Dedicated runtime closeout

`Dedicated launch` means starting the real Minecraft Forge server process (the same type of process Pterodactyl runs), not opening a single-player/LAN world and not merely compiling Java source.

## Before launch

Run on the server host with JDK 17 selected:

```bash
./dedicated-preflight.sh /home/container
```

Expected final line:

```text
[GA PREFLIGHT] DEDICATED_PREFLIGHT_OK
```

The preflight intentionally refuses Java versions other than 17 for this 1.20.1 stack, warns about client-only Embeddium/Oculus in `mods/`, and refuses duplicate Gunner Arena jars.

## Runtime closeout checklist

1. Server reaches `Done` without Gunner Arena/FML exceptions.
2. Unauthenticated player is held at lobby and cannot `/play`, attack, shoot, interact, pick up or drop arena items.
3. `/login` or `/register` unlocks the Gunner Arena session.
4. `/spawnregion show <id>` renders temporary border particles.
5. JEG projectile fired from inside SafeRegion is rejected; no projectile survives in the world.
6. `jeg:flare_gun` remains quarantined; do not test its broken projectile on the live server until JEG itself is patched.
7. OP shows KVICloud ADMIN prefix in name/TAB; de-op refreshes to PLAYER.
8. `/play` enters a combat spawn and one full round reaches CG BETA regeneration, READY, pre-round, then PLAYING again.
9. `/hazard status` and `/ga debug hazards` remain clean after round regeneration.
10. Stop server normally and verify profile/config writes complete.

Only after this checklist passes should stage 11.9 be marked complete.

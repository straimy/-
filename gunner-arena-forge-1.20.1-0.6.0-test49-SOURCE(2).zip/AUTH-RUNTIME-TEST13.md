# Gunner Arena 0.6.0-test14 — pre-auth runtime fence

## Verified from current SAuth 2.0.0 bytecode

The currently supplied SAuth 2.0.0 keeps unauthenticated UUIDs in a private `notLoggedPlayers` set.
It removes a UUID only after a successful `/login`. It does **not** currently publish the
`sauth_authenticated` scoreboard tag expected by Gunner Arena test12+.

Therefore SAuth 2.1 (or a small compatibility bridge) is required before final runtime.
The final SAuth 2.1 must preserve `config/serverreg/users.json` so existing accounts are not lost.

## Gunner Arena defense-in-depth in test13

While the auth tag is absent, Gunner Arena additionally cancels:

- all commands except `/login` and `/register`;
- block breaking / left click;
- right-click block / item;
- entity interaction;
- item pickup and item toss;
- incoming/outgoing player combat through the existing attack fence;
- arena profile/session initialization;
- `/play`, `/buy`, ammo, stats and economy access.

Every 5 server ticks the unauthenticated player is returned to the configured Gunner Arena lobby.

## Mandatory live test

1. Join without logging in.
2. Confirm player is at `/setspawn`.
3. Try `/play`, `/buy`, `/spawn`, `/balance`, block break/place/use, item pickup/drop, attack/shoot. All must fail.
4. `/login <password>` must remain available.
5. After successful login, SAuth 2.1 publishes `sauth_authenticated`.
6. Gunner Arena initializes the session once and `/play` becomes available.
7. Reconnect: authentication state must not persist across the new network session before `/login`.

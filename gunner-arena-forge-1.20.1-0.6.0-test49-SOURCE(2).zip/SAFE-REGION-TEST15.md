# test15 — Safe Region Forge source integration

Implemented in source (not claimed live-tested):
- persistent `safe-regions.properties` registry is wired into `ArenaRuntime`;
- `/spawnregion pos1`, `/spawnregion pos2`, `/spawnregion create <id>`, `/spawnregion remove <id>`, `/spawnregion list`;
- attacks into/out of safe regions are canceled;
- block/item/entity interactions in safe regions are fenced by the same server-side handlers used for pre-auth protection;
- item toss is blocked in safe regions.

Still pending real Forge compile/runtime:
- JEG-specific fire/reload cancellation validation;
- no-death fallback / void recovery;
- ragdoll suppression integration;
- region border particles/actionbar;
- temporary weapon hiding/restoration;
- hazard execution/visuals.

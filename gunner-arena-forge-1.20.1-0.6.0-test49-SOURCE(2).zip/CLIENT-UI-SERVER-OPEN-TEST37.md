# Test37 — server-driven UI opening

Status: source implementation only; Forge compile/runtime is still pending.

- UI protocol bumped to v3.
- Core can send an OpenUiPacket for MAIN, SHOP, or PROFILE without importing client classes.
- `/menu`, `/shop`, `/profile`, and `/ga menu` provide a real server-side test path.
- Future NPC interaction should call `ArenaNetwork.openUi(player, UiTarget.MAIN)`; no simulated keypress is required.
- The old client key is retained only as an F8 development fallback, not the primary public flow.
- Client requests fresh snapshot/catalog when a server-opened screen appears.

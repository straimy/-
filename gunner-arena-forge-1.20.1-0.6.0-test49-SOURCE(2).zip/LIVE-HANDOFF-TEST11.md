# Gunner Arena 0.6.0-test11 live handoff

This stage adds `/ga debug doctor` so the first real Forge runtime gives a single health report before starting a round.

## Before touching the round
1. Start the dedicated Forge 1.20.1 server.
2. Join with the normal client stack.
3. Run `/ga debug doctor`.
4. Expected essentials: JEG assault rifle=true, pistol ammo=true, scoreboard:data=true, lobby=true, combatSpawns>0.
5. If lobby/spawns are missing, set them with `/setspawn` and `/addspawn`, then run doctor again.

## Then test in this order
`/ga debug round` -> `/ga debug generator` -> `/play` -> `/balance` -> `/buy jeg:semi_auto_pistol` -> death/respawn -> patron pickup -> `/round restart`.

Do not test UI/NPC/new custom guns until this server-only path survives several full CG BETA cycles.

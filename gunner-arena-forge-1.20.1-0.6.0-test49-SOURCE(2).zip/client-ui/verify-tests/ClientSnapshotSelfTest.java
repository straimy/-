import arena.client.net.ArenaClientSnapshot;
import arena.client.net.ClientSnapshotStore;

public final class ClientSnapshotSelfTest {
    public static void main(String[] args) {
        ArenaClientSnapshot empty = ArenaClientSnapshot.empty();
        if (empty.initialized()) throw new AssertionError("empty initialized");
        ArenaClientSnapshot s = new ArenaClientSnapshot(true, true, "N", "PLAYING", 2, 20, 500,
            4, 1, 3, 20, 1, 9, 3, 2, 100, 8, 4, 5, 10, 2, 180,
            1, 0, 1, 40);
        ClientSnapshotStore.accept(s);
        if (ClientSnapshotStore.get().roundCredits() != 500) throw new AssertionError("store");
        if (Math.abs(s.kd() - 3.0D) > 0.0001D) throw new AssertionError("kd");
        if (Math.abs(s.accuracy() - 0.5D) > 0.0001D) throw new AssertionError("accuracy");
        if (s.remainingSeconds() != 1) throw new AssertionError("remaining seconds");
        ClientSnapshotStore.clear();
        if (ClientSnapshotStore.get().initialized()) throw new AssertionError("clear");
        System.out.println("CLIENT_SNAPSHOT_SELF_TEST_OK");
    }
}

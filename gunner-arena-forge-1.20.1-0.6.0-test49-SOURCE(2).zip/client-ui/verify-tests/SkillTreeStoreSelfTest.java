import arena.client.net.*;
import java.util.List;
public final class SkillTreeStoreSelfTest {
  public static void main(String[] args){
    var e=new ArenaClientSkillEntry("combat_focus","Боевой фокус","COMBAT",20,2,"",false,false,false,true,"OK");
    ClientSkillTreeStore.accept(12,55,"ASSAULT",List.of(e));
    if(ClientSkillTreeStore.level()!=12||ClientSkillTreeStore.points()!=55||ClientSkillTreeStore.entries().size()!=1)throw new AssertionError();
    ClientSkillTreeStore.clear(); if(!ClientSkillTreeStore.entries().isEmpty()||ClientSkillTreeStore.points()!=0)throw new AssertionError();
    System.out.println("SKILL_TREE_STORE_OK");
  }
}

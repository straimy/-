import arena.client.net.ArenaClientShopItem;
import arena.client.net.ClientShopStore;
import java.util.List;

public final class ClientShopStoreSelfTest {
    public static void main(String[] args) {
        ClientShopStore.clear();
        var safe = new ArenaClientShopItem("jeg:assault_rifle","AR","RIFLE","PRIMARY",1500,"jeg:rifle_ammo",30,60,"AUTO","NONE",true,false);
        var quarantined = new ArenaClientShopItem("jeg:flare_gun","Flare","SPECIAL","SECONDARY",1,"",1,0,"SEMI","NONE",true,true);
        if (quarantined.available()) throw new AssertionError("quarantine must force unavailable");
        ClientShopStore.acceptCatalog(List.of(safe, quarantined));
        if (ClientShopStore.items().size()!=2) throw new AssertionError("catalog size");
        ClientShopStore.acceptResult(true,"Оружие куплено.");
        if (!ClientShopStore.resultOk() || ClientShopStore.resultSerial()!=1) throw new AssertionError("result state");
        System.out.println("CLIENT_SHOP_STORE_SELF_TEST_OK");
    }
}

import arena.client.ui.UiLayout;

public final class UiLayoutSelfTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        UiLayout small = UiLayout.of(320, 180);
        UiLayout.Rect b0 = small.primaryButton(0);
        UiLayout.Rect b1 = small.primaryButton(1);
        check(b0.x() >= 0 && b0.x() + b0.width() <= small.width(), "small button overflow");
        check(b1.y() > b0.y(), "button order");
        check(small.contentPanel().height() >= 100, "small panel height");

        UiLayout hd = UiLayout.of(1920, 1080);
        check(hd.panelWidth() <= 520, "panel max width");
        check(hd.primaryButton(0).x() == hd.centerX() - hd.primaryButton(0).width() / 2, "centered button");
        check(hd.primaryButton(0).contains(hd.centerX(), hd.primaryButton(0).y() + 5), "hitbox");
        System.out.println("UI_LAYOUT_SELF_TEST_OK");
    }
}

import arena.client.ui.UiNavigationPolicy;
import arena.client.ui.UiRoute;

public final class UiNavigationSelfTest {
    public static void main(String[] args) {
        require(UiNavigationPolicy.escapeTarget(UiRoute.MAIN) == null, "main escape closes");
        require(UiNavigationPolicy.escapeTarget(UiRoute.SHOP) == UiRoute.MAIN, "shop escape -> main");
        require(UiNavigationPolicy.escapeTarget(UiRoute.PROFILE) == UiRoute.MAIN, "profile escape -> main");
        require(!UiNavigationPolicy.devKeyEnabled(null), "dev key disabled by default");
        require(!UiNavigationPolicy.devKeyEnabled("false"), "false disables");
        require(UiNavigationPolicy.devKeyEnabled("true"), "true enables");
        require(UiNavigationPolicy.devKeyEnabled("1"), "1 enables");
        System.out.println("UI_NAVIGATION_SELF_TEST_OK");
    }
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}

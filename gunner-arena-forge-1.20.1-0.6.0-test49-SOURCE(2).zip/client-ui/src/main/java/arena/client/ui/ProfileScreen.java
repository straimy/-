package arena.client.ui;

import arena.client.net.ArenaClientNetwork;
import arena.client.net.ClientSnapshotStore;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

final class ProfileScreen extends AbstractArenaScreen {
    ProfileScreen() { super(Component.literal("Профиль"), UiRoute.PROFILE); }

    @Override protected void init() {
        installNavigation();
        ArenaClientNetwork.requestSnapshot();
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        drawBackdrop(g);
        UiLayout.Rect panel = UiLayout.of(width, height).contentPanel();
        drawPanel(g, panel);
        g.drawString(font, Component.literal("ПРОФИЛЬ"), panel.x() + 20, panel.y() + 18, UiTheme.ACCENT_2);
        var s = ClientSnapshotStore.get();
        boolean fresh = ClientSnapshotStore.fresh(System.currentTimeMillis());
        int x = panel.x() + 20;
        int y = panel.y() + 44;
        if (!fresh) {
            g.drawString(font, Component.literal("СВЯЗЬ С CORE... обновляем профиль"), x, y, UiTheme.ACCENT_2);
        } else if (!s.authenticated()) {
            g.drawString(font, Component.literal("ТРЕБУЕТСЯ /login"), x, y, UiTheme.MUTED);
        } else if (!s.initialized()) {
            g.drawString(font, Component.literal("ИНИЦИАЛИЗАЦИЯ ПРОФИЛЯ..."), x, y, UiTheme.MUTED);
        } else {
            g.drawString(font, Component.literal(s.playerName() + "  •  УРОВЕНЬ " + s.level()), x, y, UiTheme.TEXT); y += 18;
            g.drawString(font, Component.literal("XP: " + s.xp() + "   Очки навыков: " + s.skillPoints()), x, y, UiTheme.MUTED); y += 22;
            g.drawString(font, Component.literal("Kills: " + s.kills() + "   Deaths: " + s.deaths() + "   Assists: " + s.assists()), x, y, UiTheme.TEXT); y += 16;
            g.drawString(font, Component.literal("K/D: " + UiFormat.kd(s.kd()) + "   Accuracy: " + UiFormat.percent(s.accuracy())), x, y, UiTheme.TEXT); y += 16;
            g.drawString(font, Component.literal("Damage: " + s.damageDealt() + "   Best streak: " + s.bestKillStreak()), x, y, UiTheme.TEXT); y += 16;
            g.drawString(font, Component.literal("Rounds: " + s.roundsPlayed() + "   Wins: " + s.roundsWon() + "   Playtime: " + UiFormat.time(s.playTimeSeconds())), x, y, UiTheme.MUTED); y += 24;
            g.drawString(font, Component.literal("ТЕКУЩИЙ РАУНД"), x, y, UiTheme.ACCENT); y += 16;
            g.drawString(font, Component.literal("$" + s.roundCredits() + "   K/D/A: " + s.roundKills() + "/" + s.roundDeaths() + "/" + s.roundAssists() + "   Damage: " + s.roundDamage()), x, y, UiTheme.TEXT);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
    @Override public boolean isPauseScreen() { return false; }
}

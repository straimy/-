package arena.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

abstract class AbstractArenaScreen extends Screen {
    private final UiRoute route;

    protected AbstractArenaScreen(Component title, UiRoute route) {
        super(title);
        this.route = route == null ? UiRoute.MAIN : route;
    }

    protected final UiRoute route() { return route; }

    @Override
    public void onClose() {
        UiRoute target = UiNavigationPolicy.escapeTarget(route);
        if (target == null) {
            super.onClose();
        } else {
            ArenaNavigation.navigate(target);
        }
    }

    protected final void installNavigation() { ArenaNavigation.install(this, route); }

    protected void drawBackdrop(GuiGraphics g) {
        g.fill(0, 0, width, height, UiTheme.BACKDROP);
        // Lightweight sci-fi grid; texture/resource-pack art can replace this later.
        for (int x = 0; x < width; x += 32) g.fill(x, 0, x + 1, height, 0x183A5D78);
        for (int y = 0; y < height; y += 32) g.fill(0, y, width, y + 1, 0x183A5D78);
    }

    protected void drawPanel(GuiGraphics g, UiLayout.Rect r) {
        g.fill(r.x(), r.y(), r.x() + r.width(), r.y() + r.height(), UiTheme.PANEL);
        g.fill(r.x(), r.y(), r.x() + r.width(), r.y() + 1, UiTheme.PANEL_BORDER);
        g.fill(r.x(), r.y() + r.height() - 1, r.x() + r.width(), r.y() + r.height(), UiTheme.PANEL_BORDER);
        g.fill(r.x(), r.y(), r.x() + 1, r.y() + r.height(), UiTheme.PANEL_BORDER);
        g.fill(r.x() + r.width() - 1, r.y(), r.x() + r.width(), r.y() + r.height(), UiTheme.PANEL_BORDER);
    }
}

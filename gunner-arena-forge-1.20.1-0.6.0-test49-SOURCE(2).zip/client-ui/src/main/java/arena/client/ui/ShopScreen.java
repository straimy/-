package arena.client.ui;

import arena.client.net.ArenaClientNetwork;
import arena.client.net.ArenaClientShopItem;
import arena.client.net.ClientShopStore;
import arena.client.net.ClientSnapshotStore;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class ShopScreen extends AbstractArenaScreen {
    private String category = "ALL";
    private int selectedIndex;
    private int page;
    private long seenResultSerial = -1;
    private final List<ArenaButton> dynamicButtons = new ArrayList<>();

    ShopScreen() { super(Component.literal("Магазин"), UiRoute.SHOP); }

    @Override protected void init() {
        clearWidgets(); dynamicButtons.clear();
        installNavigation();
        ArenaClientNetwork.requestSnapshot();
        ArenaClientNetwork.requestCatalog();
        rebuildDynamicButtons();
    }

    private void rebuildDynamicButtons() {
        for (ArenaButton b : dynamicButtons) removeWidget(b);
        dynamicButtons.clear();
        UiLayout.Rect panel = UiLayout.of(width,height).contentPanel();
        int x = panel.x()+18, y=panel.y()+42;
        Set<String> cats = new LinkedHashSet<>(); cats.add("ALL");
        for (ArenaClientShopItem e : ClientShopStore.items()) cats.add(e.category());
        int catWidth = Math.max(62, Math.min(94, (panel.width()-36) / Math.max(1,cats.size())));
        int cx=x;
        for(String c:cats){
            if(cx+catWidth>panel.x()+panel.width()-18) break;
            final String value=c;
            ArenaButton b=new ArenaButton(new UiLayout.Rect(cx,y,catWidth-4,20),Component.literal(labelCategory(c)),btn->{ category=value;page=0;selectedIndex=0;rebuildDynamicButtons(); });
            dynamicButtons.add(addRenderableWidget(b)); cx+=catWidth;
        }

        List<ArenaClientShopItem> filtered=filtered();
        int rows=Math.max(3,Math.min(7,(panel.height()-128)/25));
        int start=Math.min(page*rows,Math.max(0,filtered.size()-1));
        if(selectedIndex>=filtered.size()) selectedIndex=Math.max(0,filtered.size()-1);
        int listX=x, listY=y+30, listW=Math.max(150,panel.width()/2-28);
        for(int i=0;i<rows && start+i<filtered.size();i++){
            int idx=start+i; ArenaClientShopItem item=filtered.get(idx);
            String state=item.quarantined()?" [ОТКЛ]":(!item.available()?" [СКОРО]":"");
            ArenaButton b=new ArenaButton(new UiLayout.Rect(listX,listY+i*25,listW,21),Component.literal(item.displayName()+"  $"+item.price()+state),btn->{selectedIndex=idx;rebuildDynamicButtons();});
            b.active=true; dynamicButtons.add(addRenderableWidget(b));
        }
        int detailX=panel.x()+panel.width()/2+8;
        int buyY=panel.y()+panel.height()-48;
        if(!filtered.isEmpty()){
            ArenaClientShopItem selected=filtered.get(Math.min(selectedIndex,filtered.size()-1));
            ArenaButton buy=new ArenaButton(new UiLayout.Rect(detailX,buyY,Math.max(120,panel.width()/2-28),24),Component.literal(selected.available()?"КУПИТЬ  $"+selected.price():(selected.quarantined()?"ОТКЛЮЧЕНО":"НЕДОСТУПНО")),btn->ArenaClientNetwork.buy(selected.id()));
            buy.active=selected.available() && UiAccessPolicy.canShop(ClientSnapshotStore.get(), ClientSnapshotStore.fresh(System.currentTimeMillis()));
            dynamicButtons.add(addRenderableWidget(buy));
        }
        if(start>0){ ArenaButton prev=new ArenaButton(new UiLayout.Rect(listX,buyY,64,24),Component.literal("←"),b->{page=Math.max(0,page-1);rebuildDynamicButtons();});dynamicButtons.add(addRenderableWidget(prev)); }
        if(start+rows<filtered.size()){ ArenaButton next=new ArenaButton(new UiLayout.Rect(listX+70,buyY,64,24),Component.literal("→"),b->{page++;rebuildDynamicButtons();});dynamicButtons.add(addRenderableWidget(next)); }
    }

    private List<ArenaClientShopItem> filtered(){
        return ClientShopStore.items().stream().filter(e->"ALL".equals(category)||category.equals(e.category())).toList();
    }
    private static String labelCategory(String c){ return switch(c){case "ALL"->"ВСЕ";case "PISTOL"->"ПИСТ.";case "SMG"->"ПП";case "RIFLE"->"ВИНТ.";case "SHOTGUN"->"ДРОБ.";case "DMR"->"DMR";case "SNIPER"->"СНАЙП.";case "HEAVY"->"ТЯЖ.";default->c;}; }

    @Override public void tick(){
        super.tick();
        long serial=ClientShopStore.resultSerial();
        if(serial!=seenResultSerial){ seenResultSerial=serial; rebuildDynamicButtons(); }
    }

    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partialTick){
        drawBackdrop(g); UiLayout.Rect panel=UiLayout.of(width,height).contentPanel(); drawPanel(g,panel);
        var snap=ClientSnapshotStore.get();
        g.drawString(font,Component.literal("МАГАЗИН"),panel.x()+18,panel.y()+16,UiTheme.ACCENT);
        g.drawString(font,Component.literal("$"+snap.roundCredits()+"   Coins "+snap.coins()+"   ◆ "+snap.crystals()),panel.x()+panel.width()-205,panel.y()+16,UiTheme.TEXT);
        List<ArenaClientShopItem> filtered=filtered();
        boolean snapshotFresh=ClientSnapshotStore.fresh(System.currentTimeMillis());
        boolean catalogFresh=ClientShopStore.catalogFresh(System.currentTimeMillis());
        if(!snapshotFresh){
            g.drawString(font,Component.literal("Нет свежего ответа от Core. Повторяем запрос..."),panel.x()+18,panel.y()+76,UiTheme.ACCENT_2);
        } else if(!snap.authenticated()||!snap.initialized()){
            g.drawString(font,Component.literal("Авторизуйся, чтобы пользоваться магазином."),panel.x()+18,panel.y()+76,UiTheme.MUTED);
        } else if(!catalogFresh){
            g.drawString(font,Component.literal("Обновляем каталог оружия..."),panel.x()+18,panel.y()+76,UiTheme.MUTED);
        } else if(ClientShopStore.items().isEmpty()){
            g.drawString(font,Component.literal("Каталог пуст или пока недоступен."),panel.x()+18,panel.y()+76,UiTheme.MUTED);
        } else if(!filtered.isEmpty()){
            ArenaClientShopItem e=filtered.get(Math.min(selectedIndex,filtered.size()-1));
            int x=panel.x()+panel.width()/2+8,y=panel.y()+78;
            g.drawString(font,Component.literal(e.displayName()),x,y,UiTheme.TEXT); y+=18;
            g.drawString(font,Component.literal(e.category()+" • "+e.slot()),x,y,UiTheme.MUTED); y+=16;
            g.drawString(font,Component.literal("Цена: $"+e.price()),x,y,UiTheme.ACCENT); y+=16;
            g.drawString(font,Component.literal("Магазин: "+e.magazineSize()+"   Резерв: "+e.startingReserve()),x,y,UiTheme.TEXT); y+=16;
            g.drawString(font,Component.literal("Режимы: "+e.fireModes()),x,y,UiTheme.TEXT); y+=16;
            g.drawString(font,Component.literal("Прицел: "+e.scope()),x,y,UiTheme.TEXT); y+=20;
            int status=e.quarantined()?0xFFFF7373:(e.available()?UiTheme.ACCENT:UiTheme.MUTED);
            String txt=e.quarantined()?"CRASH QUARANTINE":(e.available()?"ДОСТУПНО":"ЕЩЁ НЕ ЗАРЕГИСТРИРОВАНО");
            g.drawString(font,Component.literal(txt),x,y,status);
        }
        String result=ClientShopStore.resultMessage();
        if(!result.isBlank()) g.drawString(font,Component.literal(result),panel.x()+18,panel.y()+panel.height()-18,ClientShopStore.resultOk()?UiTheme.ACCENT:0xFFFF7373);
        super.render(g,mouseX,mouseY,partialTick);
    }
    @Override public boolean isPauseScreen(){return false;}
}

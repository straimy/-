package arena.client.ui;

public final class UiTheme {
    private UiTheme() {}
    public static final int BACKDROP = 0xE60A0D18;
    public static final int PANEL = 0xD9141828;
    public static final int PANEL_BORDER = 0xAA67D8FF;
    public static final int TEXT = 0xFFF4F8FF;
    public static final int MUTED = 0xFF98A6BD;
    public static final int ACCENT = 0xFF70E8FF;
    public static final int ACCENT_2 = 0xFFB58CFF;
    public static final int BUTTON = 0xCC18243A;
    public static final int BUTTON_HOVER = 0xDD263B59;
}

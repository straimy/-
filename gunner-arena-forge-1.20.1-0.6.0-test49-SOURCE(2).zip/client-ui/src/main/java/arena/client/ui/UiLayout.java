package arena.client.ui;

/** Pure layout math kept independent from Minecraft so it can be unit-smoke-tested. */
public final class UiLayout {
    public record Rect(int x, int y, int width, int height) {
        public boolean contains(double mouseX, double mouseY) {
            return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
        }
    }

    private final int width;
    private final int height;
    private final int centerX;
    private final int panelWidth;

    private UiLayout(int width, int height) {
        this.width = Math.max(320, width);
        this.height = Math.max(180, height);
        this.centerX = this.width / 2;
        this.panelWidth = Math.min(520, Math.max(300, this.width - 80));
    }

    public static UiLayout of(int width, int height) { return new UiLayout(width, height); }
    public int width() { return width; }
    public int height() { return height; }
    public int centerX() { return centerX; }
    public int panelWidth() { return panelWidth; }
    public int panelLeft() { return centerX - panelWidth / 2; }
    public int titleY() { return Math.max(28, height / 7); }

    public Rect primaryButton(int index) {
        int buttonWidth = Math.min(300, panelWidth - 40);
        int buttonHeight = 34;
        int gap = 10;
        int startY = Math.max(titleY() + 58, height / 2 - 52);
        return new Rect(centerX - buttonWidth / 2, startY + index * (buttonHeight + gap), buttonWidth, buttonHeight);
    }

    public Rect contentPanel() {
        int top = Math.max(56, height / 8);
        int bottomMargin = 44;
        return new Rect(panelLeft(), top, panelWidth, Math.max(100, height - top - bottomMargin));
    }
}

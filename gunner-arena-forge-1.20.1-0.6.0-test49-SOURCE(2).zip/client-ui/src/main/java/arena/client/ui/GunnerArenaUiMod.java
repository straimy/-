package arena.client.ui;

import arena.client.net.ArenaClientNetwork;
import arena.client.net.ClientSnapshotStore;
import arena.client.net.ClientShopStore;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod(GunnerArenaUiMod.MODID)
public final class GunnerArenaUiMod {
    public static final String MODID = "gunnerarena_ui";
    private static final boolean DEV_KEY_ENABLED = UiNavigationPolicy.devKeyEnabled(System.getProperty("gunnerarena.ui.devKey"));
    private static final KeyMapping RELOAD_WEAPON = new KeyMapping(
        "key.gunnerarena_ui.reload_weapon", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.gunnerarena_ui"
    );
    private static final KeyMapping FIREMODE = new KeyMapping(
        "key.gunnerarena_ui.firemode", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.gunnerarena_ui"
    );
    private static final KeyMapping OPEN_MENU = new KeyMapping(
        "key.gunnerarena_ui.open_menu_dev",
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_F8,
        "key.categories.gunnerarena_ui"
    );

    public GunnerArenaUiMod() { ArenaClientNetwork.register(); }

    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModEvents {
        @SubscribeEvent public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(RELOAD_WEAPON);
            event.register(FIREMODE);
            if (DEV_KEY_ENABLED) event.register(OPEN_MENU);
        }
    }

    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static final class ForgeEvents {
        private static int snapshotPollTicks;
        private static boolean hadPlayer;

        @SubscribeEvent
        public static void clientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            while (DEV_KEY_ENABLED && OPEN_MENU.consumeClick()) {
                if (mc.player != null) ClientUiOpener.open(0);
            }
            if (mc.player != null && mc.screen == null) {
                while (RELOAD_WEAPON.consumeClick()) ArenaClientNetwork.requestReload();
                while (FIREMODE.consumeClick()) ArenaClientNetwork.requestCycleFireMode();
            }
            if (mc.player == null) {
                if (hadPlayer) { ClientSnapshotStore.clear(); ClientShopStore.clear(); }
                hadPlayer = false; snapshotPollTicks = 0; return;
            }
            hadPlayer = true;
            if (!(mc.screen instanceof AbstractArenaScreen)) { snapshotPollTicks = 0; return; }
            if (++snapshotPollTicks >= 20) {
                snapshotPollTicks = 0;
                ArenaClientNetwork.requestSnapshot();
                if (mc.screen instanceof ShopScreen) ArenaClientNetwork.requestCatalog();
            }
        }
    }
}

package arena.client.ui;

/** Stable screen routes shared by navigation widgets and pure self-tests. */
public enum UiRoute {
    MAIN,
    SHOP,
    PROFILE,
    SKILLS
}

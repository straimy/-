package arena.client.ui;

import arena.client.net.ArenaClientSnapshot;

public final class UiAccessPolicySelfTest {
    private static ArenaClientSnapshot snap(boolean auth, boolean init, String state) {
        return new ArenaClientSnapshot(auth, init, "Test", state, 1, 100, 500, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
    public static void main(String[] args) {
        require(!UiAccessPolicy.canPlay(snap(true,true,"PLAYING"), false), "stale snapshot must block play");
        require(!UiAccessPolicy.canPlay(snap(false,false,"WAITING"), true), "unauth must block play");
        require(!UiAccessPolicy.canPlay(snap(true,true,"REGENERATING"), true), "regen must block play");
        require(UiAccessPolicy.canPlay(snap(true,true,"PLAYING"), true), "ready player should play");
        require(UiAccessPolicy.canShop(snap(true,true,"WAITING"), true), "ready player should shop");
        require("СВЯЗЬ С CORE...".equals(UiAccessPolicy.status(snap(true,true,"PLAYING"), false)), "stale status");
        System.out.println("UI_ACCESS_POLICY_OK");
    }
    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
}

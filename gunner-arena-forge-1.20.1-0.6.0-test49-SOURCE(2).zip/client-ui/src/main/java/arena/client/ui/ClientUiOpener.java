package arena.client.ui;

import arena.client.net.ArenaClientNetwork;
import net.minecraft.client.Minecraft;

/** Single client entry-point for screens opened by the server/NPC protocol. */
public final class ClientUiOpener {
    private ClientUiOpener() {}

    public static void open(int rawTarget) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        ArenaClientNetwork.requestSnapshot();
        switch (rawTarget) {
            case 1 -> { ArenaClientNetwork.requestCatalog(); mc.setScreen(new ShopScreen()); }
            case 2 -> mc.setScreen(new ProfileScreen());
            case 3 -> { ArenaClientNetwork.requestSkillTree(); mc.setScreen(new SkillsScreen()); }
            default -> mc.setScreen(new MainArenaScreen());
        }
    }
}

package arena.client.ui;

import java.util.Locale;

final class UiFormat {
    private UiFormat() {}
    static String kd(double value) { return String.format(Locale.ROOT, "%.2f", value); }
    static String percent(double value) { return String.format(Locale.ROOT, "%.1f%%", value * 100.0D); }
    static String time(long seconds) {
        long s = Math.max(0L, seconds);
        long h = s / 3600L;
        long m = (s % 3600L) / 60L;
        return h > 0 ? h + "ч " + m + "м" : m + "м";
    }
    static String roundTimer(int seconds) {
        int s = Math.max(0, seconds);
        return String.format(Locale.ROOT, "%02d:%02d", s / 60, s % 60);
    }
}

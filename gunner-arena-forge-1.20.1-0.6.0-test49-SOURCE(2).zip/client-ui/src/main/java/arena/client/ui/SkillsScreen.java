package arena.client.ui;

import arena.client.net.ArenaClientNetwork;
import arena.client.net.ArenaClientSkillEntry;
import arena.client.net.ClientSkillTreeStore;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.List;

final class SkillsScreen extends AbstractArenaScreen {
    private int page;
    SkillsScreen() { super(Component.literal("Навыки"), UiRoute.SKILLS); }

    @Override protected void init() {
        installNavigation();
        ArenaClientNetwork.requestSkillTree();
        rebuildButtons();
    }

    private void rebuildButtons() {
        clearWidgets();
        installNavigation();
        List<ArenaClientSkillEntry> all = ClientSkillTreeStore.entries();
        int from = Math.min(page * 8, all.size());
        int to = Math.min(from + 8, all.size());
        UiLayout.Rect panel = UiLayout.of(width,height).contentPanel();
        int x = panel.x()+20, y=panel.y()+68;
        for (int i=from;i<to;i++) {
            ArenaClientSkillEntry e=all.get(i); final String id=e.id();
            ArenaButton b=new ArenaButton(new UiLayout.Rect(x,y,Math.min(300,panel.width()-40),22), Component.literal(label(e)), ignored->{ArenaClientNetwork.unlockSkill(id);ArenaClientNetwork.requestSkillTree();});
            b.active=e.available() && !e.unlocked(); addRenderableWidget(b); y+=26;
        }
        if (page>0) addRenderableWidget(new ArenaButton(new UiLayout.Rect(panel.x()+20,panel.y()+panel.height()-30,80,20),Component.literal("< НАЗАД"),i->{page--;rebuildButtons();}));
        if (to<all.size()) addRenderableWidget(new ArenaButton(new UiLayout.Rect(panel.x()+110,panel.y()+panel.height()-30,80,20),Component.literal("ДАЛЕЕ >"),i->{page++;rebuildButtons();}));
    }

    private static String label(ArenaClientSkillEntry e) {
        String mark=e.unlocked()?"✓ ":""; return mark+e.name()+"  ["+e.cost()+"]";
    }

    @Override public void tick() {
        super.tick();
        if (minecraft != null && minecraft.level != null && minecraft.level.getGameTime()%20L==0L) ArenaClientNetwork.requestSkillTree();
    }

    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partialTick) {
        drawBackdrop(g); UiLayout.Rect panel=UiLayout.of(width,height).contentPanel(); drawPanel(g,panel);
        g.drawString(font,Component.literal("ДЕРЕВО НАВЫКОВ"),panel.x()+20,panel.y()+18,UiTheme.ACCENT_2);
        if (!ClientSkillTreeStore.fresh(System.currentTimeMillis())) g.drawString(font,Component.literal("СВЯЗЬ С CORE..."),panel.x()+20,panel.y()+44,UiTheme.MUTED);
        else g.drawString(font,Component.literal("Lv."+ClientSkillTreeStore.level()+"  •  Очки: "+ClientSkillTreeStore.points()+"  •  "+ClientSkillTreeStore.specialization()),panel.x()+20,panel.y()+44,UiTheme.TEXT);
        super.render(g,mouseX,mouseY,partialTick);
    }
    @Override public boolean isPauseScreen(){return false;}
}

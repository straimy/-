package arena.client.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Common top navigation. Keeps all Gunner Arena screens reachable without nested parent chains. */
final class ArenaNavigation {
    private ArenaNavigation() {}

    static void install(AbstractArenaScreen screen, UiRoute current) {
        UiLayout layout = UiLayout.of(screen.width, screen.height);
        int totalWidth = Math.min(440, Math.max(280, layout.panelWidth() - 40));
        int gap = 5;
        int w = (totalWidth - gap * 3) / 4;
        int startX = layout.centerX() - totalWidth / 2;
        int y = 17;
        add(screen, current, UiRoute.MAIN, new UiLayout.Rect(startX, y, w, 20), "ГЛАВНАЯ");
        add(screen, current, UiRoute.SHOP, new UiLayout.Rect(startX + w + gap, y, w, 20), "МАГАЗИН");
        add(screen, current, UiRoute.PROFILE, new UiLayout.Rect(startX + (w + gap) * 2, y, w, 20), "ПРОФИЛЬ");
        add(screen, current, UiRoute.SKILLS, new UiLayout.Rect(startX + (w + gap) * 3, y, w, 20), "НАВЫКИ");
    }

    private static void add(AbstractArenaScreen screen, UiRoute current, UiRoute target, UiLayout.Rect rect, String text) {
        ArenaButton button = new ArenaButton(rect, Component.literal(text), ignored -> navigate(target));
        button.active = current != target;
        screen.addRenderableWidget(button);
    }

    static void navigate(UiRoute target) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || target == null) return;
        switch (target) {
            case MAIN -> mc.setScreen(new MainArenaScreen());
            case SHOP -> mc.setScreen(new ShopScreen());
            case PROFILE -> mc.setScreen(new ProfileScreen());
            case SKILLS -> mc.setScreen(new SkillsScreen());
        }
    }
}

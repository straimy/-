package arena.client.ui;

/** Pure navigation rules, separated so escape/back semantics can be smoke-tested without Minecraft. */
public final class UiNavigationPolicy {
    private UiNavigationPolicy() {}

    public static UiRoute escapeTarget(UiRoute current) {
        if (current == null || current == UiRoute.MAIN) return null;
        return UiRoute.MAIN;
    }

    public static boolean devKeyEnabled(String property) {
        return property != null && (property.equalsIgnoreCase("true") || property.equals("1") || property.equalsIgnoreCase("yes"));
    }
}

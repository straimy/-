package arena.client.ui;

import arena.client.net.ArenaClientSnapshot;

/** Side-neutral UI access rules. Keeps buttons honest when auth/session/network state changes. */
public final class UiAccessPolicy {
    private UiAccessPolicy() {}

    public static boolean canPlay(ArenaClientSnapshot s, boolean snapshotFresh) {
        if (!snapshotFresh || s == null || !s.authenticated() || !s.initialized()) return false;
        String state = s.roundState() == null ? "" : s.roundState();
        return !"REGENERATING".equals(state) && !"ERROR".equals(state);
    }

    public static boolean canShop(ArenaClientSnapshot s, boolean snapshotFresh) {
        return snapshotFresh && s != null && s.authenticated() && s.initialized();
    }

    public static String status(ArenaClientSnapshot s, boolean snapshotFresh) {
        if (!snapshotFresh) return "СВЯЗЬ С CORE...";
        if (s == null || !s.authenticated()) return "ТРЕБУЕТСЯ /login";
        if (!s.initialized()) return "ИНИЦИАЛИЗАЦИЯ ПРОФИЛЯ...";
        if ("REGENERATING".equals(s.roundState())) return "АРЕНА ПЕРЕСОЗДАЁТСЯ";
        if ("ERROR".equals(s.roundState())) return "АРЕНА В ОШИБКЕ";
        return "ONLINE";
    }
}

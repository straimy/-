package arena.client.net;

public final class ClientSnapshotStore {
    private static volatile ArenaClientSnapshot snapshot = ArenaClientSnapshot.empty();
    private static volatile long receivedAtMillis;

    private ClientSnapshotStore() {}
    public static ArenaClientSnapshot get() { return snapshot; }
    public static void accept(ArenaClientSnapshot value) {
        snapshot = value == null ? ArenaClientSnapshot.empty() : value;
        receivedAtMillis = System.currentTimeMillis();
    }
    public static void clear() { snapshot = ArenaClientSnapshot.empty(); receivedAtMillis = 0L; }
    public static boolean fresh(long nowMillis) { return receivedAtMillis > 0L && nowMillis - receivedAtMillis <= 5000L; }
}

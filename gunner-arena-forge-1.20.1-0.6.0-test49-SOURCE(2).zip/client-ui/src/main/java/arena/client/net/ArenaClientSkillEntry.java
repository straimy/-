package arena.client.net;

public record ArenaClientSkillEntry(
    String id, String name, String branch, int cost, int minLevel, String prerequisites,
    boolean major, boolean active, boolean unlocked, boolean available, String reason
) {}

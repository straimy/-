package arena.client.net;

/** Immutable client copy of the server snapshot. It is display-only. */
public record ArenaClientSnapshot(
    boolean authenticated,
    boolean initialized,
    String playerName,
    String roundState,
    int roundNumber,
    int roundRemainingTicks,
    int roundCredits,
    long coins,
    long crystals,
    int level,
    long xp,
    int skillPoints,
    long kills,
    long deaths,
    long assists,
    long damageDealt,
    long shotsFired,
    long shotsHit,
    int bestKillStreak,
    long roundsPlayed,
    long roundsWon,
    long playTimeSeconds,
    int roundKills,
    int roundDeaths,
    int roundAssists,
    long roundDamage
) {
    public static ArenaClientSnapshot empty() {
        return new ArenaClientSnapshot(false, false, "", "UNKNOWN", 0, 0, 0,
            0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0);
    }
    public double kd() { return deaths == 0 ? (double) kills : (double) kills / (double) deaths; }
    public double accuracy() { return shotsFired == 0 ? 0.0D : (double) shotsHit / (double) shotsFired; }
    public int remainingSeconds() { return Math.max(0, (roundRemainingTicks + 19) / 20); }
}

package arena.client.net;

public record ArenaClientShopItem(
    String id, String displayName, String category, String slot, int price,
    String ammoItem, int magazineSize, int startingReserve, String fireModes,
    String scope, boolean available, boolean quarantined
) {
    public ArenaClientShopItem {
        id = clean(id); displayName = clean(displayName); category = clean(category); slot = clean(slot);
        ammoItem = clean(ammoItem); fireModes = clean(fireModes); scope = clean(scope);
        price = Math.max(0, price); magazineSize = Math.max(0, magazineSize); startingReserve = Math.max(0, startingReserve);
        if (quarantined) available = false;
    }
    private static String clean(String s) { return s == null ? "" : s.trim(); }
}

package arena.client.net;

import java.util.List;

public final class ClientShopStore {
    private static volatile List<ArenaClientShopItem> items = List.of();
    private static volatile String resultMessage = "";
    private static volatile boolean resultOk;
    private static volatile long resultSerial;
    private static volatile long catalogReceivedAtMillis;

    private ClientShopStore() {}
    public static List<ArenaClientShopItem> items() { return items; }
    public static void acceptCatalog(List<ArenaClientShopItem> next) { items = next == null ? List.of() : List.copyOf(next); catalogReceivedAtMillis = System.currentTimeMillis(); }
    public static void acceptResult(boolean ok, String message) {
        resultOk = ok; resultMessage = message == null ? "" : message; resultSerial++;
    }
    public static boolean resultOk() { return resultOk; }
    public static String resultMessage() { return resultMessage; }
    public static long resultSerial() { return resultSerial; }
    public static boolean catalogFresh(long nowMillis) { return catalogReceivedAtMillis > 0L && nowMillis - catalogReceivedAtMillis <= 10000L; }
    public static void clear() { items = List.of(); resultMessage = ""; resultOk = false; resultSerial = 0; catalogReceivedAtMillis = 0L; }
}

package arena.client.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Client half of gunnerarena:ui. Packet IDs and field order must match Core. */
public final class ArenaClientNetwork {
    public static final String PROTOCOL_VERSION = "5";
    private static final ResourceLocation CHANNEL_ID = new ResourceLocation("gunnerarena", "ui");
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        CHANNEL_ID, () -> PROTOCOL_VERSION, PROTOCOL_VERSION::equals, PROTOCOL_VERSION::equals
    );
    private static boolean registered;
    private ArenaClientNetwork() {}

    public static synchronized void register() {
        if (registered) return;
        int id = 0;
        CHANNEL.registerMessage(id++, SnapshotRequest.class, SnapshotRequest::encode, SnapshotRequest::decode, SnapshotRequest::handleClientNoop);
        CHANNEL.registerMessage(id++, SnapshotPacket.class, SnapshotPacket::encode, SnapshotPacket::decode, SnapshotPacket::handle);
        CHANNEL.registerMessage(id++, CatalogRequest.class, CatalogRequest::encode, CatalogRequest::decode, CatalogRequest::handleClientNoop);
        CHANNEL.registerMessage(id++, CatalogPacket.class, CatalogPacket::encode, CatalogPacket::decode, CatalogPacket::handle);
        CHANNEL.registerMessage(id++, BuyRequest.class, BuyRequest::encode, BuyRequest::decode, BuyRequest::handleClientNoop);
        CHANNEL.registerMessage(id++, BuyResultPacket.class, BuyResultPacket::encode, BuyResultPacket::decode, BuyResultPacket::handle);
        CHANNEL.registerMessage(id++, OpenUiPacket.class, OpenUiPacket::encode, OpenUiPacket::decode, OpenUiPacket::handle);
        CHANNEL.registerMessage(id++, WeaponActionRequest.class, WeaponActionRequest::encode, WeaponActionRequest::decode, WeaponActionRequest::handleClientNoop);
        CHANNEL.registerMessage(id++, SkillTreeRequest.class, SkillTreeRequest::encode, SkillTreeRequest::decode, SkillTreeRequest::handleClientNoop);
        CHANNEL.registerMessage(id++, SkillTreePacket.class, SkillTreePacket::encode, SkillTreePacket::decode, SkillTreePacket::handle);
        CHANNEL.registerMessage(id, SkillUnlockRequest.class, SkillUnlockRequest::encode, SkillUnlockRequest::decode, SkillUnlockRequest::handleClientNoop);
        registered = true;
    }

    public static void requestSnapshot() { CHANNEL.sendToServer(new SnapshotRequest()); }
    public static void requestCatalog() { CHANNEL.sendToServer(new CatalogRequest()); }
    public static void requestReload() { CHANNEL.sendToServer(new WeaponActionRequest(0)); }
    public static void requestCycleFireMode() { CHANNEL.sendToServer(new WeaponActionRequest(1)); }
    public static void requestSkillTree() { CHANNEL.sendToServer(new SkillTreeRequest()); }
    public static void unlockSkill(String id) { if (id != null && !id.isBlank() && id.length() <= 64) CHANNEL.sendToServer(new SkillUnlockRequest(id.trim())); }
    public static void buy(String weaponId) {
        if (weaponId == null || weaponId.isBlank() || weaponId.length() > 128) return;
        CHANNEL.sendToServer(new BuyRequest(weaponId.trim()));
    }

    public record OpenUiPacket(int target) {
        static void encode(OpenUiPacket p, FriendlyByteBuf b) { b.writeByte(Math.max(0, Math.min(3, p.target))); }
        static OpenUiPacket decode(FriendlyByteBuf b) { return new OpenUiPacket(Math.max(0, Math.min(3, b.readUnsignedByte()))); }
        static void handle(OpenUiPacket p, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get();
            ctx.enqueueWork(() -> arena.client.ui.ClientUiOpener.open(p.target));
            ctx.setPacketHandled(true);
        }
    }


    /** C2S input hook. 0=reload, 1=cycle fire mode. Server validates player/weapon/state. */
    public record WeaponActionRequest(int action) {
        public WeaponActionRequest { action = Math.max(0, Math.min(1, action)); }
        static void encode(WeaponActionRequest p, FriendlyByteBuf b) { b.writeByte(p.action); }
        static WeaponActionRequest decode(FriendlyByteBuf b) { return new WeaponActionRequest(b.readUnsignedByte()); }
        static void handleClientNoop(WeaponActionRequest ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }


    public record SkillTreeRequest() {
        static void encode(SkillTreeRequest ignored, FriendlyByteBuf b) {}
        static SkillTreeRequest decode(FriendlyByteBuf b) { return new SkillTreeRequest(); }
        static void handleClientNoop(SkillTreeRequest ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }
    public record SkillEntry(String id,String name,String branch,int cost,int minLevel,String prerequisites,boolean major,boolean active,boolean unlocked,boolean available,String reason) {
        static void write(FriendlyByteBuf b,SkillEntry e){b.writeUtf(e.id,64);b.writeUtf(e.name,96);b.writeUtf(e.branch,24);b.writeVarInt(Math.max(0,e.cost));b.writeVarInt(Math.max(1,e.minLevel));b.writeUtf(e.prerequisites,192);b.writeBoolean(e.major);b.writeBoolean(e.active);b.writeBoolean(e.unlocked);b.writeBoolean(e.available);b.writeUtf(e.reason,48);}
        static SkillEntry read(FriendlyByteBuf b){return new SkillEntry(b.readUtf(64),b.readUtf(96),b.readUtf(24),b.readVarInt(),b.readVarInt(),b.readUtf(192),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.readBoolean(),b.readUtf(48));}
        ArenaClientSkillEntry client(){return new ArenaClientSkillEntry(id,name,branch,cost,minLevel,prerequisites,major,active,unlocked,available,reason);}
    }
    public record SkillTreePacket(int level,int points,String specialization,List<SkillEntry> entries) {
        static void encode(SkillTreePacket p,FriendlyByteBuf b){b.writeVarInt(Math.max(1,p.level));b.writeVarInt(Math.max(0,p.points));b.writeUtf(p.specialization==null?"NONE":p.specialization,32);int n=Math.min(64,p.entries.size());b.writeVarInt(n);for(int i=0;i<n;i++)SkillEntry.write(b,p.entries.get(i));}
        static SkillTreePacket decode(FriendlyByteBuf b){int l=b.readVarInt(),p=b.readVarInt();String s=b.readUtf(32);int n=Math.max(0,Math.min(64,b.readVarInt()));List<SkillEntry> e=new ArrayList<>(n);for(int i=0;i<n;i++)e.add(SkillEntry.read(b));return new SkillTreePacket(l,p,s,e);}
        static void handle(SkillTreePacket p,Supplier<NetworkEvent.Context> supplier){NetworkEvent.Context ctx=supplier.get();ctx.enqueueWork(()->ClientSkillTreeStore.accept(p.level,p.points,p.specialization,p.entries.stream().map(SkillEntry::client).toList()));ctx.setPacketHandled(true);}
    }
    public record SkillUnlockRequest(String id) {
        static void encode(SkillUnlockRequest p,FriendlyByteBuf b){b.writeUtf(p.id==null?"":p.id,64);}
        static SkillUnlockRequest decode(FriendlyByteBuf b){return new SkillUnlockRequest(b.readUtf(64));}
        static void handleClientNoop(SkillUnlockRequest ignored,Supplier<NetworkEvent.Context> supplier){supplier.get().setPacketHandled(true);}
    }

    public record SnapshotRequest() {
        static void encode(SnapshotRequest ignored, FriendlyByteBuf buf) {}
        static SnapshotRequest decode(FriendlyByteBuf buf) { return new SnapshotRequest(); }
        static void handleClientNoop(SnapshotRequest ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }
    public record SnapshotPacket(ArenaClientSnapshot snapshot) {
        static void encode(SnapshotPacket p, FriendlyByteBuf b) { SnapshotWire.write(b, p.snapshot); }
        static SnapshotPacket decode(FriendlyByteBuf b) { return new SnapshotPacket(SnapshotWire.read(b)); }
        static void handle(SnapshotPacket p, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get(); ctx.enqueueWork(() -> ClientSnapshotStore.accept(p.snapshot)); ctx.setPacketHandled(true);
        }
    }
    public record CatalogRequest() {
        static void encode(CatalogRequest ignored, FriendlyByteBuf buf) {}
        static CatalogRequest decode(FriendlyByteBuf buf) { return new CatalogRequest(); }
        static void handleClientNoop(CatalogRequest ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }
    public record CatalogPacket(List<ArenaClientShopItem> entries) {
        public CatalogPacket { entries = entries == null ? List.of() : List.copyOf(entries); }
        static void encode(CatalogPacket p, FriendlyByteBuf b) {
            int size = Math.min(p.entries.size(), 128); b.writeVarInt(size);
            for (int i=0;i<size;i++) writeEntry(b,p.entries.get(i));
        }
        static CatalogPacket decode(FriendlyByteBuf b) {
            int size=Math.max(0,Math.min(b.readVarInt(),128)); List<ArenaClientShopItem> out=new ArrayList<>(size);
            for(int i=0;i<size;i++) out.add(readEntry(b)); return new CatalogPacket(out);
        }
        static void handle(CatalogPacket p, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get(); ctx.enqueueWork(() -> ClientShopStore.acceptCatalog(p.entries)); ctx.setPacketHandled(true);
        }
    }
    public record BuyRequest(String weaponId) {
        static void encode(BuyRequest p,FriendlyByteBuf b){ b.writeUtf(p.weaponId == null ? "" : p.weaponId,128); }
        static BuyRequest decode(FriendlyByteBuf b){ return new BuyRequest(b.readUtf(128)); }
        static void handleClientNoop(BuyRequest ignored,Supplier<NetworkEvent.Context> supplier){ supplier.get().setPacketHandled(true); }
    }
    public record BuyResultPacket(boolean ok,String code,String message,int credits) {
        static void encode(BuyResultPacket p,FriendlyByteBuf b){ b.writeBoolean(p.ok);b.writeUtf(p.code==null?"":p.code,48);b.writeUtf(p.message==null?"":p.message,160);b.writeVarInt(Math.max(0,p.credits)); }
        static BuyResultPacket decode(FriendlyByteBuf b){ return new BuyResultPacket(b.readBoolean(),b.readUtf(48),b.readUtf(160),b.readVarInt()); }
        static void handle(BuyResultPacket p,Supplier<NetworkEvent.Context> supplier){
            NetworkEvent.Context ctx=supplier.get(); ctx.enqueueWork(() -> { ClientShopStore.acceptResult(p.ok,p.message); requestSnapshot(); requestCatalog(); }); ctx.setPacketHandled(true);
        }
    }

    private static void writeEntry(FriendlyByteBuf b,ArenaClientShopItem e){
        b.writeUtf(e.id(),128);b.writeUtf(e.displayName(),96);b.writeUtf(e.category(),24);b.writeUtf(e.slot(),24);b.writeVarInt(e.price());
        b.writeUtf(e.ammoItem(),128);b.writeVarInt(e.magazineSize());b.writeVarInt(e.startingReserve());b.writeUtf(e.fireModes(),96);b.writeUtf(e.scope(),24);
        b.writeBoolean(e.available());b.writeBoolean(e.quarantined());
    }
    private static ArenaClientShopItem readEntry(FriendlyByteBuf b){
        return new ArenaClientShopItem(b.readUtf(128),b.readUtf(96),b.readUtf(24),b.readUtf(24),b.readVarInt(),b.readUtf(128),b.readVarInt(),b.readVarInt(),b.readUtf(96),b.readUtf(24),b.readBoolean(),b.readBoolean());
    }

    static final class SnapshotWire {
        private SnapshotWire() {}
        static void write(FriendlyByteBuf b, ArenaClientSnapshot s) {
            b.writeBoolean(s.authenticated()); b.writeBoolean(s.initialized()); b.writeUtf(s.playerName(),64); b.writeUtf(s.roundState(),32);
            b.writeVarInt(s.roundNumber());b.writeVarInt(s.roundRemainingTicks());b.writeVarInt(s.roundCredits());b.writeVarLong(s.coins());b.writeVarLong(s.crystals());
            b.writeVarInt(s.level());b.writeVarLong(s.xp());b.writeVarInt(s.skillPoints());b.writeVarLong(s.kills());b.writeVarLong(s.deaths());b.writeVarLong(s.assists());
            b.writeVarLong(s.damageDealt());b.writeVarLong(s.shotsFired());b.writeVarLong(s.shotsHit());b.writeVarInt(s.bestKillStreak());b.writeVarLong(s.roundsPlayed());
            b.writeVarLong(s.roundsWon());b.writeVarLong(s.playTimeSeconds());b.writeVarInt(s.roundKills());b.writeVarInt(s.roundDeaths());b.writeVarInt(s.roundAssists());b.writeVarLong(s.roundDamage());
        }
        static ArenaClientSnapshot read(FriendlyByteBuf b) {
            return new ArenaClientSnapshot(b.readBoolean(),b.readBoolean(),b.readUtf(64),b.readUtf(32),b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarLong(),b.readVarLong(),b.readVarInt(),b.readVarLong(),b.readVarInt(),b.readVarLong(),b.readVarLong(),b.readVarLong(),b.readVarLong(),b.readVarLong(),b.readVarLong(),b.readVarInt(),b.readVarLong(),b.readVarLong(),b.readVarLong(),b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarLong());
        }
    }
}

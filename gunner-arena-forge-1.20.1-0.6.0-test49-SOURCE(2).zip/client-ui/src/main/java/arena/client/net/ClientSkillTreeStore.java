package arena.client.net;

import java.util.List;

public final class ClientSkillTreeStore {
    private static volatile int level = 1;
    private static volatile int points;
    private static volatile String specialization = "NONE";
    private static volatile List<ArenaClientSkillEntry> entries = List.of();
    private static volatile long updatedAt;
    private ClientSkillTreeStore() {}

    public static void accept(int l, int p, String spec, List<ArenaClientSkillEntry> e) {
        level = Math.max(1, l); points = Math.max(0, p); specialization = spec == null ? "NONE" : spec;
        entries = e == null ? List.of() : List.copyOf(e); updatedAt = System.currentTimeMillis();
    }
    public static int level() { return level; }
    public static int points() { return points; }
    public static String specialization() { return specialization; }
    public static List<ArenaClientSkillEntry> entries() { return entries; }
    public static boolean fresh(long now) { return updatedAt > 0 && now - updatedAt <= 5000L; }
    public static void clear() { level=1; points=0; specialization="NONE"; entries=List.of(); updatedAt=0; }
}

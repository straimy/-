# Gunner Arena test31 — Live Core combat hardening

Implemented in source:
- caps recorded damage to victim remaining health to prevent overkill stat inflation;
- removes a disconnecting attacker from every pending assist history;
- prunes assist contributions older than the 8 second assist window every 30 seconds;
- clears all pending damage/death evidence at round boundaries;
- assist payout now requires the assistant to still be fully authenticated/initialized and ALIVE.

These changes prevent stale assists, cross-round assists, offline contribution buildup and inflated damage totals.
Forge compile/runtime is still a separate proof gate.

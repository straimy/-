# Test43 — real Forge item registration

- Registers P9, PX-18, VKR-47 and Raven M96 with Forge DeferredRegister.
- Adds temporary vanilla-texture item models so missing final RP assets do not block registration.
- Custom items remain unavailable in the public shop until the combat adapter is marked ready.
- This deliberately separates "registered item exists" from "weapon is safe/playable".

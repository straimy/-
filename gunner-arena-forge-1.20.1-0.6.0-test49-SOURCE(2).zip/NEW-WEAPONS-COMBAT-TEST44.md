# Test44 — Forge custom weapon combat adapter

Status: source integration only. A real ForgeGradle 47.4.10 compile and dedicated runtime test are still required.

Implemented:
- Four registered Gunner Arena items are now marked combat-ready.
- ArenaWeaponItem starts a held-use action, allowing server-tick SEMI/AUTO/BURST input processing.
- ForgeCustomWeaponCombatService bridges the pure fire/ammo controller to server-side hitscan damage.
- Block ray clipping prevents the custom hitscan from intentionally passing through terrain.
- Entity ray selection targets other ServerPlayers only.
- Headshots use the upper 28% of the hit target bounding box and WeaponTuning.headDamage().
- P9/PX-18/VKR-47/Raven M96 use server-side range caps of 42/38/72/128 blocks.
- /reload provides manual reload; empty magazines also request an automatic reload when reserve exists.
- /firemode changes supported fire modes; crouch + right-click does the same on a custom weapon.
- Lifetime shot/accuracy stats are recorded from server-authoritative shot outcomes.
- Weapon runtime state is forgotten on logout.

Not claimed here:
- no successful ForgeGradle compile,
- no dedicated server launch,
- no client recoil/ADS animation/model polish,
- no live latency/PvP balance test.

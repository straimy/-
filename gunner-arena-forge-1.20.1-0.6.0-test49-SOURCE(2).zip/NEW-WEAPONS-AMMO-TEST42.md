# Test42 — magazine, reserve and reload controller

Status: SOURCE IMPLEMENTED / PURE JAVA BEHAVIOR TESTED. Not yet Forge/JEG runtime tested.

- Added server-authoritative per-player/per-weapon magazine and reserve state.
- Reloads spend reserve only when the reload timer completes; canceling a reload spends nothing.
- Shots are rejected while reloading or when the magazine is empty.
- Reserve pickups are capped and cannot overfill the configured maximum.
- Added WeaponRuntimeController to combine trigger cadence with ammo consumption without Forge/JEG imports.
- A VKR burst can be cut short by an empty magazine and ammo never goes negative.
- Actual Item registration, JEG projectile/hitscan adapter, client animation/sound and real reload input remain pending.

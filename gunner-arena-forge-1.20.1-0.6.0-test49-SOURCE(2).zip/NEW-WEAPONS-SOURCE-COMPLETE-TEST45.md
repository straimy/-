# Gunner Arena test45 — custom weapons SOURCE COMPLETE

Status boundary: this closes the planned custom-weapon implementation **in source only**. It is not evidence of a successful ForgeGradle build or dedicated-server runtime test.

## Added in test45

- Per-life weapon state is cleared on death/respawn/logout.
- All trigger/ammo/reload/mode state is cleared on round regeneration, round start, and server stop.
- Added a side-neutral `CustomWeaponCombatPolicy` with behavioral coverage for auth/session/round/alive/safe-region gates.
- Core/UI protocol is v4 and includes a C2S weapon-action packet. The client sends only `RELOAD` or `CYCLE_FIREMODE`; the server resolves the held weapon and validates gameplay state.
- Client production keybinds: `R` reload, `V` cycle fire mode. They do nothing while a GUI is open. Server commands remain available as admin/debug fallback.
- Weapon-action packet spam is throttled server-side.

## Still requires real Forge runtime evidence

The four items, input packets, hitscan, Forge event hooks, reload, fire modes, and dedicated-server behavior must still be compiled against Forge 47.4.10 on Java 17 and exercised on a test server before they can be marked tested/installation-ready.

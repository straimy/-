# TEST17 — Forge SafeRegion adapter

Status: implemented in source, pure Java core gate passes; full Forge compile/runtime still pending.

Admin flow:
1. Stand on first corner: `/spawnregion pos1`
2. Stand on opposite corner: `/spawnregion pos2`
3. Save: `/spawnregion create spawn`
4. Inspect: `/spawnregion list`
5. Remove: `/spawnregion remove spawn`

Runtime rules wired in ArenaRuntime:
- damage to a player inside a safe region is cancelled;
- attacks originating from a player inside a safe region are cancelled;
- arena-bound weapon use is cancelled inside a safe region;
- regions persist in `config/gunnerarena/safe-regions.properties` and survive CG BETA regeneration.

Still pending live Forge validation:
- confirm JEG fires through Forge RightClickItem/LivingAttack paths as expected;
- suppress/clean any projectile visual spawned before cancelled damage;
- hide/restore held combat weapon on region enter/exit;
- ragdoll mod behavior must be checked on the actual server.

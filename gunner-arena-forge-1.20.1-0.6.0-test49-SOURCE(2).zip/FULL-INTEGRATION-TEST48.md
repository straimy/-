# Test48 — FULL integration / resource-pack packaging

Status: SOURCE/PACKAGING COMPLETE, not Forge-runtime proven.

## Included
- Core source and client UI source stay separate.
- Shared protocol version remains 5 on both sides.
- Integrated 1.20.1 resource pack with stable model IDs for P9, PX-18, VKR-47 and Raven M96.
- Generated placeholder pixel-art weapon textures and KVICloud pack icon/panel so the four registered items no longer depend on vanilla fallback models once the pack is enabled.
- Integration manifest pins Minecraft 1.20.1, Forge 47.4.10, Java 17, protocol 5 and the known flare quarantine.
- `build-resource-pack.sh` creates a deterministic resource-pack zip and SHA-1/SHA-256 hashes.
- `assemble-full-release.sh` refuses to fake a release: it requires real compiled Core/UI jars before creating the install bundle.
- `full-integration-proof.sh` checks protocol/version agreement, RP contents, flare quarantine, jar presence when release assembly is requested, and produces a release manifest.

## Resource-pack scope
The included gun textures are integration placeholders with final/stable registry paths. They can later be replaced by the user's final Blockbench/texture art without changing item IDs or server code.

## Live boundary
This does not prove ForgeGradle compilation or dedicated runtime. A FULL install is only considered runtime-ready after the actual Core and UI jars are built on Java 17 and the dedicated smoke test passes.

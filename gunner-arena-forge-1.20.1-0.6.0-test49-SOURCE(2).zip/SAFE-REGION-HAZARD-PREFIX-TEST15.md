# Gunner Arena 0.6.0-test15

Implemented in pure/server core:
- temporary HazardManager lifecycle with TTL and global active limit;
- hard refusal to spawn hazards inside configured SafeRegionRegistry regions;
- hazard damage eligibility helper for safe-zone immunity;
- PrefixRole/PrefixResolver with PLAYER and ADMIN gradient style data;
- OP-equivalent permission level >=2 resolves to ADMIN.

Not yet claimed as live Forge functionality:
- /spawnregion command bindings and wand interaction;
- /hazard command bindings and particle/damage executors;
- TAB/chat/nameplate Component injection;
- dedicated-server runtime verification.

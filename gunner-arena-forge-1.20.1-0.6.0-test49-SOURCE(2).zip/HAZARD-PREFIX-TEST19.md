# Gunner Arena 0.6.0-test19 — hazard executor + KVICloud prefixes

Status legend:
- SOURCE: implemented in source.
- PURE-GATE: pure Java core gate passes.
- FORGE-RUNTIME: not claimed until a real ForgeGradle 47.4.10 build and dedicated-server test succeeds.

## SOURCE additions
- Hazards now retain their dimension.
- ForgeHazardExecutor executes temporary, non-destructive visuals/effects for METEOR, TNT_DROP, WEB_BOMB, SHOCKWAVE, SMOKE, CRYO and GRAVITY_PULSE.
- No hazard executor writes/breaks world blocks.
- Safe-region players, unauthenticated players and non-ALIVE arena players are excluded from hazard effects.
- Hazard runtime state is cleared when CG BETA regeneration begins.
- ForgePrefixService renders gradient-like KVICloud prefixes:
  - ✦ ИГРОК · name
  - ✦ АДМИН · name
- ADMIN is derived from the server OP list.
- NameFormat and TabListNameFormat are wired so the same decorated name can feed nameplate/chat display name and TAB.
- A KVICloud welcome broadcast is sent only after Gunner Arena considers the connection authenticated/initialized; leave broadcast only for initialized sessions.

## Important runtime caveat
The vanilla join/leave line may still also appear. test19 does not claim to suppress/replace Minecraft's own connection message; doing that cleanly may require a targeted mixin or a compatible server event/hook after real Forge runtime verification.

# Gunner Arena 0.6.0-test5 source

Stage 11.5 source integration:
- persistent `ammo-points.properties` with atomic writes
- `/setspawnpatron1` and `/setspawnpatron2`
- `/clearspawnpatron1` and `/clearspawnpatron2`
- `/listspawnpatron1` and `/listspawnpatron2`
- `/removespawnpatron1 nearest` and `/removespawnpatron2 nearest`
- `/showspawnpatrons` debug visualization for 30 seconds
- `/ga debug ammo`
- patron1 dynamically resolves the current PRIMARY weapon ammo via the server WeaponCatalog
- patron2 dynamically resolves the current SECONDARY weapon ammo
- real JEG registry item lookup; client never selects the ammo item itself
- shared global point cooldown: primary 20s, secondary 15s
- reserve cap enforcement; full ammo does not consume the point
- no-weapon / unknown-ammo / full-inventory cases do not consume the point
- pickup scan throttled to 4 Hz
- active points use lightweight particles; no persistent marker entity is required, so CG BETA marker cleanup cannot erase placement data
- cooldowns reset at round transition

Pure Java core + point persistence smoke test passes under Java 17.

Important: this source tree is still not claimed as an installable Forge server JAR until it has been ForgeGradle-linked and launched against a real Forge 1.20.1 dedicated server with the current custom JEG jar.

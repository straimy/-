#!/usr/bin/env bash
set -euo pipefail
MC='1.20.1'
FORGE='47.4.10'
EXPECTED_SHA1='31133abd261aa4d23672d1820db06ccec80326ad'
ROOT="$(cd "$(dirname "$0")" && pwd)"
CACHE="$ROOT/.forge-bootstrap"
MDK="$CACHE/forge-${MC}-${FORGE}-mdk.zip"
MDK_DIR="$CACHE/mdk"
URL="https://maven.minecraftforge.net/net/minecraftforge/forge/${MC}-${FORGE}/forge-${MC}-${FORGE}-mdk.zip"
mkdir -p "$CACHE"

if ! command -v java >/dev/null 2>&1; then
  echo '[GA BUILD] Java not found. Install JDK 17.' >&2; exit 2
fi
JAVA_VER="$(java -version 2>&1 | head -n1)"
echo "[GA BUILD] $JAVA_VER"
JAVA_MAJOR="$(java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/^[[:space:]]*java.version = /{print $2; exit}' | sed 's/^1\.//' | cut -d. -f1)"
if [[ "$JAVA_MAJOR" != "17" ]]; then
  echo "[GA BUILD] Refusing to build Forge 1.20.1 with Java $JAVA_MAJOR. Use JDK 17 (set JAVA_HOME/PATH to Java 17)." >&2
  exit 5
fi

if [[ ! -f "$MDK" ]]; then
  echo "[GA BUILD] Downloading official Forge MDK ${MC}-${FORGE}..."
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --connect-timeout 20 "$URL" -o "$MDK"
  elif command -v wget >/dev/null 2>&1; then
    wget -O "$MDK" "$URL"
  else
    echo '[GA BUILD] Need curl or wget.' >&2; exit 3
  fi
fi
ACTUAL_SHA1="$(sha1sum "$MDK" | awk '{print $1}')"
if [[ "$ACTUAL_SHA1" != "$EXPECTED_SHA1" ]]; then
  echo "[GA BUILD] Forge MDK SHA1 mismatch: $ACTUAL_SHA1" >&2; exit 4
fi

echo '[GA BUILD] Forge MDK checksum OK.'
rm -rf "$MDK_DIR"
mkdir -p "$MDK_DIR"
unzip -q "$MDK" -d "$MDK_DIR"

# Use the official wrapper/Gradle bootstrap from the MDK while keeping our project files.
cp -f "$MDK_DIR/gradlew" "$ROOT/gradlew"
cp -f "$MDK_DIR/gradlew.bat" "$ROOT/gradlew.bat"
rm -rf "$ROOT/gradle"
cp -a "$MDK_DIR/gradle" "$ROOT/gradle"
chmod +x "$ROOT/gradlew"

cd "$ROOT"
./verify-source.sh
./gradlew --no-daemon clean build

echo '[GA BUILD] Build finished.'
find build/libs -maxdepth 1 -type f -name '*.jar' -print

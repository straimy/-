# Gunner Arena Core 0.6.0-test9 — build/runtime gate

Target: Minecraft 1.20.1, Forge 47.4.10, Java 17.

## Build
Use the official Forge 1.20.1-47.4.10 MDK / ForgeGradle environment.

1. Ensure Java 17 is selected (`java -version`).
2. From the project directory run `./gradlew clean build` (or `gradlew.bat clean build` on Windows).
3. Expected artifact: `build/libs/gunnerarena-0.6.0-test9.jar`.

## Dedicated-server acceptance test
Do NOT replace the production 0.5.1 until these pass on a copy/test server.

1. Server reaches `Done` without Gunner Arena exceptions.
2. A client without Gunner Arena Core can join (server-only display test).
3. `/ga debug round` returns state/round/timer.
4. `/ga debug generator` returns CG BETA counters.
5. `/addspawn`, `/listspawns`, `/play` work.
6. `/balance` begins at $500 in a fresh round.
7. `/buy jeg:semi_auto_pistol` gives the real registered JEG item when affordable.
8. Death/respawn restores arena-bound loadout and does not reset current-round Credits.
9. `/setspawnpatron1` and `/setspawnpatron2` persist through server restart and CG BETA regeneration.
10. Complete at least 3 full PLAYING -> REGENERATING -> PLAYING cycles.
11. No `Invalid player data`, Brigadier merge, proxy, or command-tree sync exceptions.

If any step fails, save `latest.log` before changing anything else.

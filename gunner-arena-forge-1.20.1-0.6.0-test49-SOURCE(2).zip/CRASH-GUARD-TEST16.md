# Gunner Arena 0.6.0-test16 — fire-weapon crash guard

## Evidence from 2026-08-14 incident
The supplied server logs are from the restart beginning around 02:27:51 and show a clean startup to Done.
They do not contain the crash moment itself. The screenshot shows a client crash report created at about 02:27:50.
The dedicated server is currently launching Forge 1.20.1 / 47.4.10 on Java 25.0.3 even though the mod stack targets Java 17.

## Temporary quarantine
Until the client crash report and pre-restart server log are inspected, Gunner Arena blocks purchases of:
- jeg:flamethrower
- jeg:flare_gun
- jeg_cfg:fire_sweeper

This does not claim those three are proven guilty. It only prevents them entering normal Arena loadouts while the incident is investigated.
Creative/admin spawning can still bypass the buy path and therefore must not be used for public testing yet.

## Required runtime action
1. Move the server runtime to JDK 17 before further Forge 1.20.1 stress tests.
2. Remove Embeddium from the dedicated server mods folder; keep it client-side only.
3. Obtain the exact client crash report shown by the launcher and the server latest.log from before the restart.
4. Reproduce each quarantined weapon one by one on a staging server, not the public arena.

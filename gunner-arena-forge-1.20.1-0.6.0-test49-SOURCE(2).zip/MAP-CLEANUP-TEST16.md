# Gunner Arena 0.6.0-test16 — regeneration cleanup

## Implemented in source
CG BETA regeneration now has two cleanup passes:

1. immediately when `beginRegeneration()` starts;
2. once again when CG BETA reports `READY`, before the 5-second pre-round delay.

`ArenaVisualCleanupService` removes:
- server-backed ragdoll/corpse/body-part entities detected by registry/class/name hints;
- server-backed blood/gore pool/splatter entities detected the same way;
- Gunner Arena temporary/hazard entities by tag;
- dropped item entities;
- projectiles;
- lingering area-effect clouds;
- primed TNT;
- falling-block combat debris;
- XP orbs.

It intentionally does NOT globally delete players, living mobs, CG BETA marker entities,
TextDisplay/Interaction infrastructure, NPCs, or arbitrary ArmorStands.

The assist/damage tracker is also cleared at regeneration start and at READY so stale damage
cannot leak into the next arena.

## Important runtime note
Pure client particles (for example a blood particle rendered only by a client mod) cannot be
explicitly removed by a dedicated server. They expire naturally; moving players to the lobby
while REGENERATING prevents new combat blood from being created. If BloodyBits/Ragdollified
use persistent custom entities on this exact build, the registry-id heuristics remove those.
The exact entity ids should still be confirmed in the real Forge runtime log before claiming
mod-specific compatibility.

package arena.rpg;

/** Side-neutral RPG modifier. Values are deliberately small and capped by RpgEffects. */
public record SkillEffect(Type type, double value) {
    public enum Type {
        DAMAGE_MULT,
        HEADSHOT_MULT,
        RELOAD_SPEED,
        MOVE_SPEED,
        MAX_HEALTH,
        DAMAGE_REDUCTION,
        AMMO_RESERVE,
        CREDIT_GAIN,
        HIP_ACCURACY,
        ADS_ACCURACY,
        RECOIL_CONTROL,
        HEALING_POWER
    }
}

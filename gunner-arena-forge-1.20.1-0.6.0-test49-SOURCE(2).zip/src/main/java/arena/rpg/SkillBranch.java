package arena.rpg;

public enum SkillBranch {
    COMBAT,
    MOBILITY,
    SURVIVAL,
    SUPPLY,
    ECONOMY,
    HANDLING
}

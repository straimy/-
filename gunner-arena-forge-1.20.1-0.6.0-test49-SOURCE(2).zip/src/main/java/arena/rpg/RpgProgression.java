package arena.rpg;

/** Long-term progression curve. XP is total lifetime XP, not XP inside the current level. */
public final class RpgProgression {
    public static final int MAX_LEVEL = 100;
    public static final int SKILL_POINTS_PER_LEVEL = 10;

    private RpgProgression() {}

    public static long xpForLevel(int level) {
        int target = Math.max(1, Math.min(MAX_LEVEL, level));
        long total = 0;
        for (int l = 1; l < target; l++) total += xpToNext(l);
        return total;
    }

    public static long xpToNext(int currentLevel) {
        int l = Math.max(1, Math.min(MAX_LEVEL - 1, currentLevel));
        return 400L + 90L * l + 6L * l * l;
    }

    public static int levelForXp(long xp) {
        long safe = Math.max(0L, xp);
        int level = 1;
        while (level < MAX_LEVEL && safe >= xpForLevel(level + 1)) level++;
        return level;
    }

    public static long xpIntoLevel(long xp, int level) {
        return Math.max(0L, Math.max(0L, xp) - xpForLevel(level));
    }
}

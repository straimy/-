package arena.rpg;

public enum Specialization {
    NONE,
    ASSAULT,
    MARKSMAN,
    BREACHER,
    SCOUT,
    SURVIVOR,
    GUNSLINGER;

    public static Specialization parse(String value) {
        if (value == null) return NONE;
        try { return valueOf(value.trim().toUpperCase(java.util.Locale.ROOT)); }
        catch (IllegalArgumentException ex) { return NONE; }
    }
}

package arena.rpg;

import arena.profile.PlayerProfile;
import java.util.EnumMap;
import java.util.Map;

/** Aggregates unlocked passive modifiers and applies hard balance caps. */
public final class RpgEffects {
    private final SkillCatalog catalog;
    public RpgEffects(SkillCatalog catalog) { this.catalog = catalog; }

    public Map<SkillEffect.Type, Double> aggregate(PlayerProfile profile) {
        EnumMap<SkillEffect.Type, Double> out = new EnumMap<>(SkillEffect.Type.class);
        if (profile != null) for (String id : profile.unlockedSkills) {
            SkillDefinition skill = catalog.get(id);
            if (skill == null) continue;
            for (SkillEffect effect : skill.effects()) out.merge(effect.type(), effect.value(), Double::sum);
        }
        // Hard caps keep RPG meaningful without letting progression erase gunplay.
        cap(out, SkillEffect.Type.DAMAGE_MULT, .10);
        cap(out, SkillEffect.Type.HEADSHOT_MULT, .10);
        cap(out, SkillEffect.Type.RELOAD_SPEED, .15);
        cap(out, SkillEffect.Type.MOVE_SPEED, .10);
        cap(out, SkillEffect.Type.MAX_HEALTH, 6.0);
        cap(out, SkillEffect.Type.DAMAGE_REDUCTION, .10);
        cap(out, SkillEffect.Type.AMMO_RESERVE, .40);
        cap(out, SkillEffect.Type.CREDIT_GAIN, .10);
        cap(out, SkillEffect.Type.HIP_ACCURACY, .15);
        cap(out, SkillEffect.Type.ADS_ACCURACY, .15);
        cap(out, SkillEffect.Type.RECOIL_CONTROL, .15);
        cap(out, SkillEffect.Type.HEALING_POWER, .20);
        return Map.copyOf(out);
    }

    public double value(PlayerProfile profile, SkillEffect.Type type) { return aggregate(profile).getOrDefault(type, 0.0); }
    public double maxHealth(PlayerProfile profile) { return Math.min(26.0, 20.0 + value(profile, SkillEffect.Type.MAX_HEALTH)); }
    private static void cap(Map<SkillEffect.Type, Double> map, SkillEffect.Type type, double max) {
        if (map.containsKey(type)) map.put(type, Math.max(0.0, Math.min(max, map.get(type))));
    }
}

package arena.rpg;

import java.util.*;
import static arena.rpg.SkillEffect.Type.*;

/** Launch skill tree. No client authority: IDs/costs/prerequisites live only in Core. */
public final class SkillCatalog {
    private final Map<String, SkillDefinition> skills = new LinkedHashMap<>();

    public SkillCatalog() {
        // COMBAT
        add(s("combat_focus", "Боевой фокус", SkillBranch.COMBAT, 20, 2, Set.of(), false, false, e(DAMAGE_MULT, .02)));
        add(s("combat_precision", "Точный удар", SkillBranch.COMBAT, 35, 8, Set.of("combat_focus"), false, false, e(HEADSHOT_MULT, .05)));
        add(s("combat_pressure", "Давление", SkillBranch.COMBAT, 50, 18, Set.of("combat_precision"), false, false, e(DAMAGE_MULT, .03)));
        add(s("combat_overdrive", "Овердрайв", SkillBranch.COMBAT, 140, 35, Set.of("combat_pressure"), true, true, e(DAMAGE_MULT, .03)));

        // MOBILITY
        add(s("mobility_stride", "Быстрый шаг", SkillBranch.MOBILITY, 20, 2, Set.of(), false, false, e(MOVE_SPEED, .02)));
        add(s("mobility_dash", "Тактический рывок", SkillBranch.MOBILITY, 35, 9, Set.of("mobility_stride"), false, false, e(MOVE_SPEED, .025)));
        add(s("mobility_flow", "Поток", SkillBranch.MOBILITY, 55, 20, Set.of("mobility_dash"), false, false, e(MOVE_SPEED, .025)));
        add(s("mobility_phase", "Фазовый манёвр", SkillBranch.MOBILITY, 150, 38, Set.of("mobility_flow"), true, true, e(MOVE_SPEED, .03)));

        // SURVIVAL — health bonuses are capped so the final target stays around 26 HP.
        add(s("survival_plating", "Лёгкая бронепластина", SkillBranch.SURVIVAL, 25, 3, Set.of(), false, false, e(MAX_HEALTH, 2.0)));
        add(s("survival_resolve", "Стойкость", SkillBranch.SURVIVAL, 40, 10, Set.of("survival_plating"), false, false, e(DAMAGE_REDUCTION, .025)));
        add(s("survival_fieldmed", "Полевая медицина", SkillBranch.SURVIVAL, 55, 20, Set.of("survival_resolve"), false, false, e(HEALING_POWER, .10)));
        add(s("survival_laststand", "Последний рубеж", SkillBranch.SURVIVAL, 150, 40, Set.of("survival_fieldmed"), true, true, e(MAX_HEALTH, 4.0)));

        // SUPPLY
        add(s("supply_pockets", "Подсумки", SkillBranch.SUPPLY, 20, 2, Set.of(), false, false, e(AMMO_RESERVE, .10)));
        add(s("supply_pack", "Боевой комплект", SkillBranch.SUPPLY, 35, 10, Set.of("supply_pockets"), false, false, e(AMMO_RESERVE, .10)));
        add(s("supply_efficiency", "Экономия боезапаса", SkillBranch.SUPPLY, 55, 20, Set.of("supply_pack"), false, false, e(AMMO_RESERVE, .10)));
        add(s("supply_cache", "Полевой тайник", SkillBranch.SUPPLY, 130, 34, Set.of("supply_efficiency"), true, true, e(AMMO_RESERVE, .10)));

        // ECONOMY — modest, capped reward advantage to avoid pay-to-snowball gameplay.
        add(s("economy_contract", "Контракт", SkillBranch.ECONOMY, 20, 4, Set.of(), false, false, e(CREDIT_GAIN, .02)));
        add(s("economy_bounty", "Премия", SkillBranch.ECONOMY, 40, 12, Set.of("economy_contract"), false, false, e(CREDIT_GAIN, .025)));
        add(s("economy_network", "Сеть снабжения", SkillBranch.ECONOMY, 60, 24, Set.of("economy_bounty"), false, false, e(CREDIT_GAIN, .025)));
        add(s("economy_broker", "Полевой брокер", SkillBranch.ECONOMY, 150, 42, Set.of("economy_network"), true, true, e(CREDIT_GAIN, .03)));

        // HANDLING
        add(s("handling_grip", "Улучшенный хват", SkillBranch.HANDLING, 20, 2, Set.of(), false, false, e(RECOIL_CONTROL, .04)));
        add(s("handling_reload", "Быстрая перезарядка", SkillBranch.HANDLING, 35, 9, Set.of("handling_grip"), false, false, e(RELOAD_SPEED, .05)));
        add(s("handling_ads", "Стабильный прицел", SkillBranch.HANDLING, 50, 18, Set.of("handling_reload"), false, false, e(ADS_ACCURACY, .05)));
        add(s("handling_master", "Оружейный мастер", SkillBranch.HANDLING, 145, 36, Set.of("handling_ads"), true, true, e(RELOAD_SPEED, .05), e(RECOIL_CONTROL, .04)));
    }

    public SkillDefinition get(String id) { return id == null ? null : skills.get(id.toLowerCase(Locale.ROOT)); }
    public Collection<SkillDefinition> all() { return Collections.unmodifiableCollection(skills.values()); }
    public List<SkillDefinition> branch(SkillBranch branch) { return skills.values().stream().filter(s -> s.branch() == branch).toList(); }

    private void add(SkillDefinition skill) {
        if (skills.putIfAbsent(skill.id(), skill) != null) throw new IllegalStateException("Duplicate skill " + skill.id());
    }
    private static SkillDefinition s(String id, String name, SkillBranch b, int cost, int lvl, Set<String> req, boolean major, boolean active, SkillEffect... effects) {
        return new SkillDefinition(id, name, b, cost, lvl, req, major, active, List.of(effects));
    }
    private static SkillEffect e(SkillEffect.Type t, double v) { return new SkillEffect(t, v); }
}

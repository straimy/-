package arena.rpg;

import arena.profile.PlayerProfile;
import java.util.*;

/** Server-authoritative level/skill/specialization mutation service. */
public final class RpgService {
    public static final int MAX_PASSIVES = 8;
    public static final int MAX_MAJORS = 3;
    public static final int MAX_ACTIVES = 1;
    public static final int SPECIALIZATION_LEVEL = 25;

    private final SkillCatalog catalog;
    private final RpgEffects effects;

    public RpgService(SkillCatalog catalog) {
        this.catalog = Objects.requireNonNull(catalog);
        this.effects = new RpgEffects(catalog);
    }

    public record LevelResult(long addedXp, int oldLevel, int newLevel, int awardedSkillPoints) {}
    public enum UnlockCode { OK, UNKNOWN, ALREADY_UNLOCKED, LEVEL_TOO_LOW, MISSING_PREREQUISITE, NOT_ENOUGH_POINTS, PASSIVE_CAP, MAJOR_CAP, ACTIVE_CAP }
    public record UnlockResult(UnlockCode code, SkillDefinition skill) { public boolean ok() { return code == UnlockCode.OK; } }
    public enum SpecCode { OK, UNKNOWN, LEVEL_TOO_LOW, ALREADY_CHOSEN }

    public LevelResult grantXp(PlayerProfile p, long amount) {
        if (p == null || amount <= 0) return new LevelResult(0, p == null ? 1 : p.level, p == null ? 1 : p.level, 0);
        int old = Math.max(1, p.level);
        p.xp = safeAdd(p.xp, amount);
        int next = RpgProgression.levelForXp(p.xp);
        int gained = Math.max(0, next - old);
        p.level = next;
        int points = gained * RpgProgression.SKILL_POINTS_PER_LEVEL;
        p.skillPoints = safeIntAdd(p.skillPoints, points);
        return new LevelResult(amount, old, next, points);
    }

    public UnlockResult checkUnlock(PlayerProfile p, String id) {
        if (p == null) return new UnlockResult(UnlockCode.UNKNOWN, null);
        SkillDefinition skill = catalog.get(id);
        if (skill == null) return new UnlockResult(UnlockCode.UNKNOWN, null);
        if (p.unlockedSkills.contains(skill.id())) return new UnlockResult(UnlockCode.ALREADY_UNLOCKED, skill);
        if (p.level < skill.minLevel()) return new UnlockResult(UnlockCode.LEVEL_TOO_LOW, skill);
        if (!p.unlockedSkills.containsAll(skill.prerequisites())) return new UnlockResult(UnlockCode.MISSING_PREREQUISITE, skill);
        if (p.skillPoints < skill.cost()) return new UnlockResult(UnlockCode.NOT_ENOUGH_POINTS, skill);
        long passives = count(p, false, false), majors = countMajor(p), actives = countActive(p);
        if (!skill.major() && !skill.active() && passives >= MAX_PASSIVES) return new UnlockResult(UnlockCode.PASSIVE_CAP, skill);
        if (skill.major() && majors >= MAX_MAJORS) return new UnlockResult(UnlockCode.MAJOR_CAP, skill);
        if (skill.active() && actives >= MAX_ACTIVES) return new UnlockResult(UnlockCode.ACTIVE_CAP, skill);
        return new UnlockResult(UnlockCode.OK, skill);
    }

    public UnlockResult unlock(PlayerProfile p, String id) {
        UnlockResult result = checkUnlock(p, id);
        if (!result.ok()) return result;
        SkillDefinition skill = result.skill();
        p.skillPoints -= skill.cost();
        p.unlockedSkills.add(skill.id());
        return result;
    }

    public int resetSkills(PlayerProfile p) {
        if (p == null) return 0;
        int refund = 0;
        for (String id : p.unlockedSkills) {
            SkillDefinition skill = catalog.get(id);
            if (skill != null) refund = safeIntAdd(refund, skill.cost());
        }
        p.unlockedSkills.clear();
        p.skillPoints = safeIntAdd(p.skillPoints, refund);
        return refund;
    }

    public SpecCode chooseSpecialization(PlayerProfile p, String requested) {
        if (p == null) return SpecCode.UNKNOWN;
        Specialization spec = Specialization.parse(requested);
        if (spec == Specialization.NONE) return SpecCode.UNKNOWN;
        if (p.level < SPECIALIZATION_LEVEL) return SpecCode.LEVEL_TOO_LOW;
        if (Specialization.parse(p.specialization) != Specialization.NONE) return SpecCode.ALREADY_CHOSEN;
        p.specialization = spec.name();
        return SpecCode.OK;
    }

    public SkillCatalog catalog() { return catalog; }
    public RpgEffects effects() { return effects; }

    private long count(PlayerProfile p, boolean major, boolean active) {
        return p.unlockedSkills.stream().map(catalog::get).filter(Objects::nonNull).filter(s -> s.major() == major && s.active() == active).count();
    }
    private long countMajor(PlayerProfile p) { return p.unlockedSkills.stream().map(catalog::get).filter(Objects::nonNull).filter(SkillDefinition::major).count(); }
    private long countActive(PlayerProfile p) { return p.unlockedSkills.stream().map(catalog::get).filter(Objects::nonNull).filter(SkillDefinition::active).count(); }
    private static long safeAdd(long a, long b) { return a > Long.MAX_VALUE - b ? Long.MAX_VALUE : a + b; }
    private static int safeIntAdd(int a, int b) { return b > 0 && a > Integer.MAX_VALUE - b ? Integer.MAX_VALUE : a + b; }
}

package arena.rpg;

import java.util.List;
import java.util.Set;

public record SkillDefinition(
    String id,
    String name,
    SkillBranch branch,
    int cost,
    int minLevel,
    Set<String> prerequisites,
    boolean major,
    boolean active,
    List<SkillEffect> effects
) {
    public SkillDefinition {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("id");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("name");
        if (branch == null) throw new IllegalArgumentException("branch");
        cost = Math.max(1, cost);
        minLevel = Math.max(1, minLevel);
        prerequisites = prerequisites == null ? Set.of() : Set.copyOf(prerequisites);
        effects = effects == null ? List.of() : List.copyOf(effects);
    }
}

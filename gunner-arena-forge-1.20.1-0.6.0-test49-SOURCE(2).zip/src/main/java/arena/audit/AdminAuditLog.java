package arena.audit;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;

public final class AdminAuditLog {
    private final Path file;
    public AdminAuditLog(Path file) { this.file = file; }
    public synchronized void append(String actor, String action, String details) throws IOException {
        Files.createDirectories(file.getParent());
        String line = Instant.now() + " actor=" + sanitize(actor) + " action=" + sanitize(action) + " " + sanitize(details) + System.lineSeparator();
        Files.writeString(file, line, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }
    private static String sanitize(String s) { return s == null ? "" : s.replace('\n',' ').replace('\r',' '); }
}

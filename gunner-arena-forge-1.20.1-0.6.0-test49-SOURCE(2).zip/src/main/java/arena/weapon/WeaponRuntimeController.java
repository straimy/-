package arena.weapon;

import java.util.Objects;

/**
 * Connects trigger scheduling and ammunition accounting without touching Forge/JEG classes.
 * Every released shot must pass both the fire cadence controller and the ammo controller.
 */
public final class WeaponRuntimeController {
    private final FireStateController fire = new FireStateController();
    private final AmmoStateController ammo = new AmmoStateController();

    public RuntimeUpdate update(String actorId, WeaponDefinition definition, WeaponTuning tuning,
                                boolean triggerHeld, long nowMillis) {
        validate(definition, tuning);
        AmmoStateController.AmmoSnapshot before = ammo.update(actorId, definition, nowMillis);
        FireStateController.FireUpdate fireUpdate = fire.update(actorId, tuning, triggerHeld, nowMillis);
        if (!fireUpdate.fired()) return new RuntimeUpdate(false, fireUpdate, before, null);

        AmmoStateController.ShotResult shot = ammo.tryConsumeShot(actorId, definition, nowMillis);
        return new RuntimeUpdate(shot.fired(), fireUpdate, shot.ammo(), shot.reason());
    }

    public AmmoStateController.ReloadResult reload(String actorId, WeaponDefinition definition,
                                                    WeaponTuning tuning, long nowMillis) {
        validate(definition, tuning);
        return ammo.requestReload(actorId, definition, tuning, nowMillis);
    }

    public WeaponDefinition.FireMode cycleMode(String actorId, WeaponTuning tuning) {
        return fire.cycleMode(actorId, tuning);
    }

    public void setMode(String actorId, WeaponTuning tuning, WeaponDefinition.FireMode mode) {
        fire.setMode(actorId, tuning, mode);
    }

    public AmmoStateController.AmmoSnapshot ammo(String actorId, WeaponDefinition definition, long nowMillis) {
        return ammo.update(actorId, definition, nowMillis);
    }

    public AmmoStateController ammoController() { return ammo; }
    public FireStateController fireController() { return fire; }

    public void forgetActor(String actorId) {
        fire.forgetActor(actorId);
        ammo.forgetActor(actorId);
    }

    /** Hard round/server boundary: no trigger, reload, fire-mode or ammo state survives it. */
    public void clearAll() {
        fire.clearAll();
        ammo.clearAll();
    }

    private static void validate(WeaponDefinition definition, WeaponTuning tuning) {
        Objects.requireNonNull(definition, "definition");
        Objects.requireNonNull(tuning, "tuning");
        if (!definition.id().equals(tuning.weaponId())) throw new IllegalArgumentException("definition/tuning mismatch");
    }

    public record RuntimeUpdate(
            boolean fired,
            FireStateController.FireUpdate fire,
            AmmoStateController.AmmoSnapshot ammo,
            AmmoStateController.ShotBlockReason shotBlockReason
    ) {
        public RuntimeUpdate {
            Objects.requireNonNull(fire, "fire");
            Objects.requireNonNull(ammo, "ammo");
            if (fired && shotBlockReason != AmmoStateController.ShotBlockReason.NONE) throw new IllegalArgumentException("fired blocked shot");
        }
    }
}

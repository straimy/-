package arena.weapon;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Pure server-authoritative magazine/reserve/reload state for Gunner Arena-owned weapons.
 * Forge/JEG adapters may mirror the resulting state to real ItemStacks, but the decision to
 * spend ammo or finish a reload is owned here.
 */
public final class AmmoStateController {
    private final Map<Key, State> states = new HashMap<>();

    public AmmoSnapshot initialize(String actorId, WeaponDefinition definition) {
        Objects.requireNonNull(definition, "definition");
        Key key = key(actorId, definition.id());
        State state = new State(definition.magazineSize(), definition.startingReserve());
        states.put(key, state);
        return snapshot(state);
    }

    public AmmoSnapshot state(String actorId, WeaponDefinition definition) {
        Objects.requireNonNull(definition, "definition");
        State state = states.computeIfAbsent(key(actorId, definition.id()), ignored ->
                new State(definition.magazineSize(), definition.startingReserve()));
        return snapshot(state);
    }

    /** Attempts to consume exactly one cartridge for a server-approved shot. */
    public ShotResult tryConsumeShot(String actorId, WeaponDefinition definition, long nowMillis) {
        if (nowMillis < 0) throw new IllegalArgumentException("nowMillis");
        State state = stateInternal(actorId, definition);
        finishReloadIfDue(state, definition, nowMillis);
        if (state.reloading) return new ShotResult(false, ShotBlockReason.RELOADING, snapshot(state));
        if (state.magazine <= 0) return new ShotResult(false, ShotBlockReason.EMPTY_MAGAZINE, snapshot(state));
        state.magazine--;
        return new ShotResult(true, ShotBlockReason.NONE, snapshot(state));
    }

    /** Starts a magazine reload. Reserve ammo is not spent until the reload completes. */
    public ReloadResult requestReload(String actorId, WeaponDefinition definition, WeaponTuning tuning, long nowMillis) {
        if (nowMillis < 0) throw new IllegalArgumentException("nowMillis");
        validatePair(definition, tuning);
        State state = stateInternal(actorId, definition);
        finishReloadIfDue(state, definition, nowMillis);
        if (state.reloading) return new ReloadResult(false, ReloadBlockReason.ALREADY_RELOADING, snapshot(state));
        if (state.magazine >= definition.magazineSize()) return new ReloadResult(false, ReloadBlockReason.MAGAZINE_FULL, snapshot(state));
        if (state.reserve <= 0) return new ReloadResult(false, ReloadBlockReason.NO_RESERVE, snapshot(state));
        state.reloading = true;
        state.reloadCompleteAtMillis = nowMillis + tuning.reloadMillis();
        return new ReloadResult(true, ReloadBlockReason.NONE, snapshot(state));
    }

    /** Advances reload completion and returns the authoritative current state. */
    public AmmoSnapshot update(String actorId, WeaponDefinition definition, long nowMillis) {
        if (nowMillis < 0) throw new IllegalArgumentException("nowMillis");
        State state = stateInternal(actorId, definition);
        finishReloadIfDue(state, definition, nowMillis);
        return snapshot(state);
    }

    /** Cancels an unfinished reload without consuming reserve ammo. */
    public AmmoSnapshot cancelReload(String actorId, WeaponDefinition definition) {
        State state = stateInternal(actorId, definition);
        state.reloading = false;
        state.reloadCompleteAtMillis = 0;
        return snapshot(state);
    }

    /** Adds reserve ammo, capped at maxReserve. Returns how many rounds were actually accepted. */
    public int addReserve(String actorId, WeaponDefinition definition, int amount, int maxReserve) {
        if (amount < 0 || maxReserve < 0) throw new IllegalArgumentException("reserve values");
        State state = stateInternal(actorId, definition);
        int before = state.reserve;
        state.reserve = Math.min(maxReserve, Math.addExact(state.reserve, amount));
        return state.reserve - before;
    }

    /** Used on respawn/round setup to set an explicit authoritative load. */
    public AmmoSnapshot setAmmo(String actorId, WeaponDefinition definition, int magazine, int reserve) {
        if (magazine < 0 || magazine > definition.magazineSize() || reserve < 0) throw new IllegalArgumentException("ammo values");
        State state = stateInternal(actorId, definition);
        state.magazine = magazine;
        state.reserve = reserve;
        state.reloading = false;
        state.reloadCompleteAtMillis = 0;
        return snapshot(state);
    }

    public void forgetActor(String actorId) {
        states.keySet().removeIf(key -> key.actorId.equals(actorId));
    }

    public void forgetWeapon(String actorId, String weaponId) {
        states.remove(key(actorId, weaponId));
    }

    public void clearAll() { states.clear(); }

    public int trackedSessions() { return states.size(); }

    private State stateInternal(String actorId, WeaponDefinition definition) {
        Objects.requireNonNull(definition, "definition");
        return states.computeIfAbsent(key(actorId, definition.id()), ignored ->
                new State(definition.magazineSize(), definition.startingReserve()));
    }

    private static void finishReloadIfDue(State state, WeaponDefinition definition, long nowMillis) {
        if (!state.reloading || nowMillis < state.reloadCompleteAtMillis) return;
        int missing = Math.max(0, definition.magazineSize() - state.magazine);
        int moved = Math.min(missing, state.reserve);
        state.magazine += moved;
        state.reserve -= moved;
        state.reloading = false;
        state.reloadCompleteAtMillis = 0;
    }

    private static void validatePair(WeaponDefinition definition, WeaponTuning tuning) {
        Objects.requireNonNull(definition, "definition");
        Objects.requireNonNull(tuning, "tuning");
        if (!definition.id().equals(tuning.weaponId())) throw new IllegalArgumentException("weapon definition/tuning mismatch");
    }

    private static Key key(String actorId, String weaponId) {
        Objects.requireNonNull(actorId, "actorId");
        Objects.requireNonNull(weaponId, "weaponId");
        if (actorId.isBlank() || weaponId.isBlank()) throw new IllegalArgumentException("blank key");
        return new Key(actorId, weaponId);
    }

    private static AmmoSnapshot snapshot(State state) {
        return new AmmoSnapshot(state.magazine, state.reserve, state.reloading, state.reloadCompleteAtMillis);
    }

    public enum ShotBlockReason { NONE, RELOADING, EMPTY_MAGAZINE }
    public enum ReloadBlockReason { NONE, ALREADY_RELOADING, MAGAZINE_FULL, NO_RESERVE }

    public record AmmoSnapshot(int magazine, int reserve, boolean reloading, long reloadCompleteAtMillis) {
        public AmmoSnapshot {
            if (magazine < 0 || reserve < 0 || reloadCompleteAtMillis < 0) throw new IllegalArgumentException("ammo snapshot");
            if (!reloading && reloadCompleteAtMillis != 0) throw new IllegalArgumentException("idle reload timestamp");
        }
        public int totalRounds() { return magazine + reserve; }
    }

    public record ShotResult(boolean fired, ShotBlockReason reason, AmmoSnapshot ammo) {
        public ShotResult {
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(ammo, "ammo");
            if (fired && reason != ShotBlockReason.NONE) throw new IllegalArgumentException("fired with block reason");
            if (!fired && reason == ShotBlockReason.NONE) throw new IllegalArgumentException("blocked without reason");
        }
    }

    public record ReloadResult(boolean started, ReloadBlockReason reason, AmmoSnapshot ammo) {
        public ReloadResult {
            Objects.requireNonNull(reason, "reason");
            Objects.requireNonNull(ammo, "ammo");
            if (started && reason != ReloadBlockReason.NONE) throw new IllegalArgumentException("reload started with block reason");
            if (!started && reason == ReloadBlockReason.NONE) throw new IllegalArgumentException("reload blocked without reason");
        }
    }

    private record Key(String actorId, String weaponId) {}
    private static final class State {
        private int magazine;
        private int reserve;
        private boolean reloading;
        private long reloadCompleteAtMillis;
        private State(int magazine, int reserve) {
            this.magazine = magazine;
            this.reserve = reserve;
        }
    }
}

package arena.weapon;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Server-side quarantine for weapons with confirmed or suspected dedicated-server crash signatures.
 * Confirmed on 2026-08-14: jeg:flare_gun creates FlareProjectileEntity and JEG 0.13.2
 * attempts to load net.minecraft.client.multiplayer.ClientLevel from the dedicated server tick.
 * A quarantined id cannot be bought through Gunner Arena until its implementation is patched
 * and verified on a dedicated Forge 1.20.1 runtime.
 */
public final class WeaponSafetyPolicy {
    private static final Map<String, String> QUARANTINED;

    static {
        Map<String, String> q = new LinkedHashMap<>();
        q.put("jeg:flare_gun", "CONFIRMED: FlareProjectileEntity loads client-only ClientLevel on dedicated server");
        // Keep the other fire weapons available unless separate evidence implicates them.
        // They still need a dedicated-server smoke test before being added to public shop rotations.
        QUARANTINED = Collections.unmodifiableMap(q);
    }

    private WeaponSafetyPolicy() {}

    public static boolean isQuarantined(String id) {
        return id != null && QUARANTINED.containsKey(id.trim().toLowerCase(java.util.Locale.ROOT));
    }

    public static String reason(String id) {
        if (id == null) return "";
        return QUARANTINED.getOrDefault(id.trim().toLowerCase(java.util.Locale.ROOT), "");
    }

    public static Map<String, String> all() {
        return QUARANTINED;
    }
}

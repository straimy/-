package arena.weapon;

import java.util.List;
import java.util.Objects;

/** Pure combat tuning for Gunner Arena-owned weapons. No client/JEG classes are referenced here. */
public record WeaponTuning(
        String weaponId,
        double bodyDamage,
        double headMultiplier,
        int roundsPerMinute,
        int burstSize,
        int reloadMillis,
        double hipSpread,
        double adsSpread,
        double recoilVertical,
        double recoilHorizontal,
        double moveSpeedMultiplier,
        List<WeaponDefinition.FireMode> fireModes
) {
    public WeaponTuning {
        Objects.requireNonNull(weaponId, "weaponId");
        Objects.requireNonNull(fireModes, "fireModes");
        fireModes = List.copyOf(fireModes);
        if (weaponId.isBlank()) throw new IllegalArgumentException("weaponId");
        if (bodyDamage <= 0 || headMultiplier < 1.0) throw new IllegalArgumentException("damage");
        if (roundsPerMinute <= 0 || reloadMillis <= 0) throw new IllegalArgumentException("timing");
        if (burstSize < 1) throw new IllegalArgumentException("burstSize");
        if (hipSpread < 0 || adsSpread < 0 || recoilVertical < 0 || recoilHorizontal < 0) throw new IllegalArgumentException("negative handling");
        if (adsSpread > hipSpread) throw new IllegalArgumentException("ads spread must not exceed hip spread");
        if (moveSpeedMultiplier <= 0 || moveSpeedMultiplier > 1.25) throw new IllegalArgumentException("moveSpeedMultiplier");
        if (fireModes.isEmpty()) throw new IllegalArgumentException("fireModes");
        if (fireModes.contains(WeaponDefinition.FireMode.BURST_3) && burstSize != 3) throw new IllegalArgumentException("BURST_3 requires burstSize=3");
    }

    public double headDamage() { return bodyDamage * headMultiplier; }
    public long shotIntervalMillis() { return Math.max(1L, Math.round(60_000.0 / roundsPerMinute)); }
    public boolean supports(WeaponDefinition.FireMode mode) { return fireModes.contains(mode); }
}

package arena.weapon;

/**
 * Side-neutral policy for deciding whether Gunner Arena custom weapon input may mutate combat state.
 * Keeping this separate from Forge lets the safety rules be behavior-tested without Minecraft classes.
 */
public final class CustomWeaponCombatPolicy {
    private CustomWeaponCombatPolicy() {}

    public static Decision decide(boolean authenticated, boolean initialized, boolean roundPlaying,
                                  boolean alive, boolean safeRegion) {
        if (!authenticated) return Decision.NOT_AUTHENTICATED;
        if (!initialized) return Decision.NOT_INITIALIZED;
        if (!roundPlaying) return Decision.ROUND_NOT_PLAYING;
        if (!alive) return Decision.NOT_ALIVE;
        if (safeRegion) return Decision.SAFE_REGION;
        return Decision.ALLOW;
    }

    public enum Decision {
        ALLOW,
        NOT_AUTHENTICATED,
        NOT_INITIALIZED,
        ROUND_NOT_PLAYING,
        NOT_ALIVE,
        SAFE_REGION;

        public boolean allowed() { return this == ALLOW; }
    }
}

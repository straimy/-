package arena.weapon;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Canonical tuning for the first four Gunner Arena weapons. */
public final class CustomWeaponArsenal {
    private final Map<String, WeaponTuning> tuning = new LinkedHashMap<>();

    public CustomWeaponArsenal() {
        put(new WeaponTuning("gunnerarena:p9", 5.0, 1.75, 420, 1, 1350, 2.20, 0.65, 0.75, 0.22, 1.00,
                List.of(WeaponDefinition.FireMode.SEMI)));
        put(new WeaponTuning("gunnerarena:px18", 4.0, 1.60, 850, 1, 1550, 2.80, 0.85, 0.95, 0.38, 0.98,
                List.of(WeaponDefinition.FireMode.SEMI, WeaponDefinition.FireMode.AUTO)));
        put(new WeaponTuning("gunnerarena:vkr47", 6.0, 1.70, 650, 3, 2200, 3.10, 0.55, 1.25, 0.55, 0.93,
                List.of(WeaponDefinition.FireMode.SEMI, WeaponDefinition.FireMode.BURST_3, WeaponDefinition.FireMode.AUTO)));
        put(new WeaponTuning("gunnerarena:raven_m96", 18.0, 2.00, 52, 1, 2850, 5.50, 0.08, 2.80, 0.45, 0.86,
                List.of(WeaponDefinition.FireMode.SEMI)));
    }

    private void put(WeaponTuning value) {
        if (tuning.put(value.weaponId(), value) != null) throw new IllegalStateException("duplicate tuning: " + value.weaponId());
    }

    public WeaponTuning get(String weaponId) { return tuning.get(weaponId); }
    public Collection<WeaponTuning> all() { return java.util.Collections.unmodifiableCollection(tuning.values()); }

    /** Makes sure gameplay tuning and the shop/catalog cannot silently drift apart. */
    public void validateAgainst(WeaponCatalog catalog) {
        for (WeaponTuning t : tuning.values()) {
            WeaponDefinition def = catalog.get(t.weaponId());
            if (def == null) throw new IllegalStateException("missing catalog weapon: " + t.weaponId());
            if (!def.fireModes().equals(t.fireModes())) throw new IllegalStateException("fire-mode drift for " + t.weaponId());
            if (def.magazineSize() <= 0) throw new IllegalStateException("invalid magazine for " + t.weaponId());
        }
    }
}

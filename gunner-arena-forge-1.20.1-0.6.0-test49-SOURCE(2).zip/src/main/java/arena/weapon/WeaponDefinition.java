package arena.weapon;

import java.util.List;

public record WeaponDefinition(
        String id,
        String displayName,
        Category category,
        Slot slot,
        int price,
        String ammoItem,
        int magazineSize,
        int startingReserve,
        Weight weight,
        List<FireMode> fireModes,
        Scope scope
) {
    public enum Category { PISTOL, SMG, RIFLE, SHOTGUN, DMR, SNIPER, HEAVY, SPECIAL }
    public enum Slot { SECONDARY, PRIMARY }
    public enum Weight { LIGHT, MEDIUM, HEAVY }
    public enum FireMode { SEMI, BURST_3, AUTO }
    public enum Scope { NONE, RED_DOT, X2, X4, SNIPER }
}

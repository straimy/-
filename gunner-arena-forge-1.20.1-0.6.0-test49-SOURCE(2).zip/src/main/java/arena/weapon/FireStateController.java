package arena.weapon;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Pure server-authoritative trigger/fire-mode state machine for Gunner Arena-owned weapons.
 *
 * This class deliberately does not spawn projectiles or touch Forge/JEG classes. A Forge-side
 * weapon adapter can consume {@link FireUpdate#shotsToFire()} and perform the actual shot.
 */
public final class FireStateController {
    private static final int MAX_SHOTS_PER_UPDATE = 1;

    private final Map<Key, State> states = new HashMap<>();

    public WeaponDefinition.FireMode mode(String actorId, WeaponTuning tuning) {
        return state(actorId, tuning).mode;
    }

    public WeaponDefinition.FireMode cycleMode(String actorId, WeaponTuning tuning) {
        State state = state(actorId, tuning);
        int current = tuning.fireModes().indexOf(state.mode);
        int next = (current + 1) % tuning.fireModes().size();
        state.mode = tuning.fireModes().get(next);
        // Switching mode cancels an unfinished burst and requires a fresh trigger press.
        state.burstRemaining = 0;
        state.triggerHeld = false;
        state.burstNeedsRelease = false;
        return state.mode;
    }

    public void setMode(String actorId, WeaponTuning tuning, WeaponDefinition.FireMode mode) {
        Objects.requireNonNull(mode, "mode");
        if (!tuning.supports(mode)) throw new IllegalArgumentException("unsupported fire mode: " + mode);
        State state = state(actorId, tuning);
        state.mode = mode;
        state.burstRemaining = 0;
        state.triggerHeld = false;
        state.burstNeedsRelease = false;
    }

    /**
     * Advances one server-side input/tick update. At most one shot is released per call so a lag
     * spike cannot dump an entire magazine in one server tick. BURST_3 continues after release,
     * but a new burst cannot begin until the trigger has been released and pressed again.
     */
    public FireUpdate update(String actorId, WeaponTuning tuning, boolean triggerHeld, long nowMillis) {
        if (nowMillis < 0) throw new IllegalArgumentException("nowMillis");
        State state = state(actorId, tuning);
        boolean risingEdge = triggerHeld && !state.triggerHeld;
        boolean fallingEdge = !triggerHeld && state.triggerHeld;
        state.triggerHeld = triggerHeld;

        if (fallingEdge) state.burstNeedsRelease = false;

        int shots = 0;
        long interval = tuning.shotIntervalMillis();

        switch (state.mode) {
            case SEMI -> {
                if (risingEdge && nowMillis >= state.nextShotAtMillis) {
                    shots = 1;
                    state.nextShotAtMillis = nowMillis + interval;
                }
            }
            case AUTO -> {
                if (triggerHeld && nowMillis >= state.nextShotAtMillis) {
                    shots = 1;
                    state.nextShotAtMillis = nowMillis + interval;
                }
            }
            case BURST_3 -> {
                if (risingEdge && state.burstRemaining == 0 && !state.burstNeedsRelease && nowMillis >= state.nextShotAtMillis) {
                    state.burstRemaining = tuning.burstSize();
                    state.burstNeedsRelease = true;
                }
                if (state.burstRemaining > 0 && nowMillis >= state.nextShotAtMillis) {
                    shots = Math.min(MAX_SHOTS_PER_UPDATE, state.burstRemaining);
                    state.burstRemaining -= shots;
                    state.nextShotAtMillis = nowMillis + interval;
                }
            }
        }

        return new FireUpdate(shots, state.mode, state.burstRemaining, state.nextShotAtMillis);
    }

    public void forgetActor(String actorId) {
        states.keySet().removeIf(key -> key.actorId.equals(actorId));
    }

    public void forgetWeapon(String actorId, String weaponId) {
        states.remove(new Key(actorId, weaponId));
    }

    public void clearAll() { states.clear(); }

    public int trackedSessions() { return states.size(); }

    private State state(String actorId, WeaponTuning tuning) {
        Objects.requireNonNull(actorId, "actorId");
        Objects.requireNonNull(tuning, "tuning");
        if (actorId.isBlank()) throw new IllegalArgumentException("actorId");
        Key key = new Key(actorId, tuning.weaponId());
        return states.computeIfAbsent(key, ignored -> new State(tuning.fireModes().get(0)));
    }

    public record FireUpdate(
            int shotsToFire,
            WeaponDefinition.FireMode mode,
            int burstRemaining,
            long nextShotAtMillis
    ) {
        public FireUpdate {
            if (shotsToFire < 0 || shotsToFire > MAX_SHOTS_PER_UPDATE) throw new IllegalArgumentException("shotsToFire");
            if (burstRemaining < 0) throw new IllegalArgumentException("burstRemaining");
            Objects.requireNonNull(mode, "mode");
        }
        public boolean fired() { return shotsToFire > 0; }
    }

    private record Key(String actorId, String weaponId) {}

    private static final class State {
        private WeaponDefinition.FireMode mode;
        private boolean triggerHeld;
        private boolean burstNeedsRelease;
        private int burstRemaining;
        private long nextShotAtMillis;

        private State(WeaponDefinition.FireMode mode) { this.mode = mode; }
    }
}

package arena.ammo;

import arena.profile.RoundSession;
import arena.weapon.WeaponCatalog;
import arena.weapon.WeaponDefinition;

public final class AmmoManager {
    public enum PointType { PRIMARY, SECONDARY }
    public record PickupResult(boolean consumed, String ammoId, int amount, String message) {}

    private final WeaponCatalog catalog;
    public AmmoManager(WeaponCatalog catalog) { this.catalog = catalog; }

    public PickupResult pickup(RoundSession s, PointType type, double reserveMultiplier) {
        String weaponId = type == PointType.PRIMARY ? s.primaryWeapon() : s.secondaryWeapon();
        if (weaponId == null) return new PickupResult(false, null, 0, type == PointType.PRIMARY ? "Нет основного оружия" : "Нет дополнительного оружия");
        WeaponDefinition w = catalog.get(weaponId);
        if (w == null || w.ammoItem() == null || w.ammoItem().isBlank()) return new PickupResult(false, null, 0, "Для оружия не настроены патроны");

        int baseCap = baseReserveCap(w);
        int cap = Math.max(w.magazineSize(), (int)Math.round(baseCap * Math.max(1.0, reserveMultiplier)));
        int have = s.reserveAmmo(w.ammoItem());
        if (have >= cap) return new PickupResult(false, w.ammoItem(), 0, "Боезапас полный");

        int mags = type == PointType.PRIMARY ? 2 : 2;
        int grant = Math.max(1, w.magazineSize() * mags);
        if (w.category() == WeaponDefinition.Category.SNIPER || w.category() == WeaponDefinition.Category.HEAVY) grant = Math.max(1, w.magazineSize());
        int actual = Math.min(grant, cap - have);
        s.setReserveAmmo(w.ammoItem(), have + actual);
        return new PickupResult(true, w.ammoItem(), actual, "+" + actual + " патронов");
    }

    private static int baseReserveCap(WeaponDefinition w) {
        return switch (w.category()) {
            case PISTOL -> w.magazineSize() * 4;
            case SMG, RIFLE -> w.magazineSize() * 4;
            case SHOTGUN -> Math.max(w.magazineSize() * 5, 32);
            case DMR -> w.magazineSize() * 4;
            case SNIPER -> w.magazineSize() * 5;
            case HEAVY -> w.magazineSize() * 2;
            case SPECIAL -> w.magazineSize() * 2;
        };
    }
}

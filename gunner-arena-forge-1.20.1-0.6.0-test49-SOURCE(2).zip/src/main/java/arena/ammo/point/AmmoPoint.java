package arena.ammo.point;

import arena.ammo.AmmoManager;

/** Persistent arena ammo pickup location. Kept free of Minecraft/Forge classes for easy testing. */
public record AmmoPoint(
        String id,
        AmmoManager.PointType type,
        String dimension,
        double x,
        double y,
        double z
) {
    public AmmoPoint {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("id");
        if (type == null) throw new IllegalArgumentException("type");
        if (dimension == null || dimension.isBlank()) throw new IllegalArgumentException("dimension");
    }

    public double distanceSquared(double px, double py, double pz) {
        double dx = x - px;
        double dy = y - py;
        double dz = z - pz;
        return dx * dx + dy * dy + dz * dz;
    }
}

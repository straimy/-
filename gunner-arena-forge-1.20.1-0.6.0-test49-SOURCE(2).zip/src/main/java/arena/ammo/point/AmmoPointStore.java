package arena.ammo.point;

import arena.ammo.AmmoManager;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/** Atomic properties-backed persistence for admin-placed ammo points. */
public final class AmmoPointStore {
    private final Path file;
    private final List<AmmoPoint> points = new ArrayList<>();

    public AmmoPointStore(Path file) {
        this.file = file;
        load();
    }

    public synchronized List<AmmoPoint> all() {
        return List.copyOf(points);
    }

    public synchronized List<AmmoPoint> byType(AmmoManager.PointType type) {
        return points.stream().filter(p -> p.type() == type).toList();
    }

    public synchronized AmmoPoint add(AmmoManager.PointType type, String dimension, double x, double y, double z) {
        AmmoPoint point = new AmmoPoint(UUID.randomUUID().toString(), type, dimension, x, y, z);
        points.add(point);
        save();
        return point;
    }

    public synchronized int clear(AmmoManager.PointType type) {
        int before = points.size();
        points.removeIf(p -> p.type() == type);
        int removed = before - points.size();
        if (removed > 0) save();
        return removed;
    }

    public synchronized AmmoPoint removeNearest(AmmoManager.PointType type, String dimension,
                                                double x, double y, double z, double maxDistance) {
        AmmoPoint nearest = points.stream()
            .filter(p -> p.type() == type && p.dimension().equals(dimension))
            .filter(p -> p.distanceSquared(x, y, z) <= maxDistance * maxDistance)
            .min(Comparator.comparingDouble(p -> p.distanceSquared(x, y, z)))
            .orElse(null);
        if (nearest != null) {
            points.remove(nearest);
            save();
        }
        return nearest;
    }

    public synchronized void reload() {
        load();
    }

    private void load() {
        points.clear();
        if (!Files.isRegularFile(file)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
            int count = Integer.parseInt(p.getProperty("count", "0"));
            for (int i = 0; i < count; i++) {
                String raw = p.getProperty("point." + i);
                if (raw == null || raw.isBlank()) continue;
                String[] s = raw.split("\\|", -1);
                if (s.length != 7) continue;
                try {
                    points.add(new AmmoPoint(
                        s[0], AmmoManager.PointType.valueOf(s[1]), s[2],
                        Double.parseDouble(s[3]), Double.parseDouble(s[4]), Double.parseDouble(s[5])));
                } catch (RuntimeException ignored) {
                    // Bad legacy/manual line is skipped rather than preventing the server from starting.
                }
            }
        } catch (IOException | NumberFormatException ignored) {
            points.clear();
        }
    }

    private void save() {
        try {
            Files.createDirectories(file.getParent());
            Properties p = new Properties();
            List<AmmoPoint> sorted = new ArrayList<>(points);
            sorted.sort(Comparator.comparing((AmmoPoint a) -> a.type().name()).thenComparing(AmmoPoint::id));
            p.setProperty("count", Integer.toString(sorted.size()));
            for (int i = 0; i < sorted.size(); i++) {
                AmmoPoint a = sorted.get(i);
                p.setProperty("point." + i, String.join("|",
                    a.id(), a.type().name(), a.dimension(),
                    Double.toString(a.x()), Double.toString(a.y()), Double.toString(a.z()), "v1"));
            }
            Path tmp = file.resolveSibling(file.getFileName().toString() + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                p.store(out, "Gunner Arena ammo points v1");
            }
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Could not save Gunner Arena ammo points to " + file, ex);
        }
    }
}

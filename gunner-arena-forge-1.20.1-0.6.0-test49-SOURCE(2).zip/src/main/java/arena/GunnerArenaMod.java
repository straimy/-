package arena;

import arena.forge.net.ArenaNetwork;
import arena.forge.item.GunnerArenaItems;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

import arena.forge.ArenaRuntime;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(GunnerArenaMod.MODID)
public final class GunnerArenaMod {
    public static final String MODID = "gunnerarena";
    public static final ArenaRuntime RUNTIME = new ArenaRuntime();

    public GunnerArenaMod() {
        GunnerArenaItems.register(FMLJavaModLoadingContext.get().getModEventBus());
        ArenaNetwork.register();
        MinecraftForge.EVENT_BUS.register(RUNTIME);
    }
}

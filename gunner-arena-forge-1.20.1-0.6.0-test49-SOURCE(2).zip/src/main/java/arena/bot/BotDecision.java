package arena.bot;

public record BotDecision(BotBrainState state, boolean fire, boolean reload, boolean useBaritone, String reason) {}

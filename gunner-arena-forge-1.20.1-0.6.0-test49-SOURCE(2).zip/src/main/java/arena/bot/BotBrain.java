package arena.bot;

/** Deterministic high-level AI Gunner 1.5 decision core. Movement/aim adapters stay platform-specific. */
public final class BotBrain {
    public BotDecision decide(BotProfile profile, BotCombatSnapshot s) {
        if (!s.inGame()) return new BotDecision(BotBrainState.RETURN_TO_GAME, false, false, true, "not-in-arena");
        if (s.magazineAmmo() == 0 && s.reserveAmmo() > 0) return new BotDecision(BotBrainState.RELOAD, false, true, false, "empty-mag");

        double healAt = switch (profile) {
            case RUSHER -> 0.22;
            case ASSAULT, GUNSLINGER -> 0.30;
            case MARKSMAN -> 0.34;
            case SURVIVOR -> 0.45;
        };
        if (s.healthRatio() <= healAt) {
            if (s.coverAvailable()) return new BotDecision(BotBrainState.HEAL, false, false, false, "low-health-cover");
            return new BotDecision(BotBrainState.TAKE_COVER, false, false, false, "low-health");
        }

        if (s.enemyVisible()) {
            double preferred = switch (profile) {
                case RUSHER -> 14.0;
                case ASSAULT -> 28.0;
                case MARKSMAN -> 58.0;
                case SURVIVOR -> 34.0;
                case GUNSLINGER -> 20.0;
            };
            if (s.enemyDistance() <= preferred || profile == BotProfile.MARKSMAN)
                return new BotDecision(BotBrainState.ENGAGE, s.magazineAmmo() > 0, false, false, "visible-target");
            return new BotDecision(BotBrainState.CHASE, false, false, false, "close-distance");
        }

        if (s.underFire() && s.coverAvailable()) return new BotDecision(BotBrainState.TAKE_COVER, false, false, false, "incoming-fire");
        if (!s.hasPath()) return new BotDecision(BotBrainState.PATHFIND, false, false, true, "lost-path");
        return new BotDecision(BotBrainState.SEARCH, false, false, false, "search");
    }
}

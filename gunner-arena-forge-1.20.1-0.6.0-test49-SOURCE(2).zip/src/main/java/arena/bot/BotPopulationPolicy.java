package arena.bot;

public final class BotPopulationPolicy {
    private BotPopulationPolicy() {}
    public static int desiredBots(int realPlayers) {
        realPlayers = Math.max(0, realPlayers);
        if (realPlayers < 5) return 4;
        if (realPlayers < 10) return 2;
        return 0;
    }
}

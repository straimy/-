package arena.bot;

public record BotSlot(String name, BotProfile profile, long createdTick, long rotateAtTick, String launchToken, boolean connected) {
    public BotSlot withConnected(boolean value) { return new BotSlot(name, profile, createdTick, rotateAtTick, launchToken, value); }
}

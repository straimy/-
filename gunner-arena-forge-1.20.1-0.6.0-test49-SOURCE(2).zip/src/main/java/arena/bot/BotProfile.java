package arena.bot;

/** Publicly bots still look like normal PLAYERs; this is only the hidden AI personality. */
public enum BotProfile {
    RUSHER,
    ASSAULT,
    MARKSMAN,
    SURVIVOR,
    GUNSLINGER
}

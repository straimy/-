package arena.bot;

public enum BotBrainState {
    SEARCH,
    CHASE,
    ENGAGE,
    TAKE_COVER,
    HEAL,
    RELOAD,
    PATHFIND,
    RETURN_TO_GAME
}

package arena.bot;

import java.util.*;

/**
 * Server-side autofill director. It reserves bot identities/tokens; external AI Gunner clients
 * connect with those names and authenticate using /botauth. No fake public BOT tag is required.
 */
public final class BotDirector {
    private static final List<String> NAMES = List.of(
        "KairoX","NovaByte","Vexori","Rinex","AsterQ","Nyro","Velix","SorenX","Kyzen","Ravik",
        "Nexora","ZephyrK","Mirox","Axeno","Kivaro","Zerith","Lunex","Tairo","Vennix","Krossy");
    private static final long MIN_ROTATE = 20L * 60L * 2L;
    private static final long MAX_ROTATE = 20L * 60L * 5L;

    private final LinkedHashMap<String, BotSlot> slots = new LinkedHashMap<>();
    private final BotTokenService tokens = new BotTokenService();
    private final Random random;
    private boolean autofill = true;
    private Integer targetOverride;

    public BotDirector() { this(new Random()); }
    BotDirector(Random random) { this.random = Objects.requireNonNull(random); }

    public synchronized void tick(int realPlayers, long tick) {
        int desired = desired(realPlayers);
        while (slots.size() > desired) removeOldest();
        while (slots.size() < desired) addOne(tick);
        if (!slots.isEmpty()) {
            BotSlot due = slots.values().stream().filter(s -> tick >= s.rotateAtTick()).findFirst().orElse(null);
            if (due != null) rotate(due.name(), tick);
        }
    }

    public synchronized int desired(int realPlayers) {
        if (!autofill) return 0;
        return targetOverride != null ? Math.max(0, Math.min(8, targetOverride)) : BotPopulationPolicy.desiredBots(realPlayers);
    }

    public synchronized List<BotSlot> slots() { return List.copyOf(slots.values()); }
    public synchronized boolean autofill() { return autofill; }
    public synchronized void autofill(boolean value) { autofill = value; if (!value) clear(); }
    public synchronized Integer targetOverride() { return targetOverride; }
    public synchronized void targetOverride(Integer target) { targetOverride = target == null ? null : Math.max(0, Math.min(8, target)); }

    public synchronized boolean authenticate(String playerName, String token) {
        BotSlot slot = slots.get(playerName);
        if (slot == null || !tokens.validate(playerName, token)) return false;
        slots.put(playerName, slot.withConnected(true));
        return true;
    }

    public synchronized void disconnected(String playerName) {
        BotSlot slot = slots.get(playerName);
        if (slot != null) slots.put(playerName, slot.withConnected(false));
    }

    public synchronized boolean isReservedName(String name) { return slots.containsKey(name); }
    public synchronized String tokenFor(String name) { BotSlot s = slots.get(name); return s == null ? null : s.launchToken(); }
    public synchronized boolean rotateOne(long tick) {
        if (slots.isEmpty()) return false;
        rotate(slots.values().iterator().next().name(), tick);
        return true;
    }
    public synchronized void clear() {
        for (String n : new ArrayList<>(slots.keySet())) tokens.revoke(n);
        slots.clear();
    }

    private void rotate(String oldName, long tick) {
        BotSlot old = slots.remove(oldName);
        if (old != null) tokens.revoke(oldName);
        addOne(tick);
    }
    private void removeOldest() {
        if (slots.isEmpty()) return;
        String name = slots.keySet().iterator().next();
        slots.remove(name); tokens.revoke(name);
    }
    private void addOne(long tick) {
        List<String> free = NAMES.stream().filter(n -> !slots.containsKey(n)).toList();
        if (free.isEmpty()) return;
        String name = free.get(random.nextInt(free.size()));
        BotProfile profile = BotProfile.values()[random.nextInt(BotProfile.values().length)];
        long rotateAt = tick + MIN_ROTATE + Math.floorMod(random.nextLong(), (MAX_ROTATE - MIN_ROTATE + 1L));
        String token = tokens.issue(name);
        slots.put(name, new BotSlot(name, profile, tick, rotateAt, token, false));
    }
}

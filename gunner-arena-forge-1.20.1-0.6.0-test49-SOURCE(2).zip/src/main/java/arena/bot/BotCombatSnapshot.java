package arena.bot;

/** Side-neutral facts supplied by the actual AI client/Forge adapter. */
public record BotCombatSnapshot(
    boolean inGame,
    boolean enemyVisible,
    double enemyDistance,
    boolean hasPath,
    boolean underFire,
    double healthRatio,
    int magazineAmmo,
    int reserveAmmo,
    boolean coverAvailable
) {
    public BotCombatSnapshot {
        healthRatio = Math.max(0.0, Math.min(1.0, healthRatio));
        enemyDistance = Math.max(0.0, enemyDistance);
        magazineAmmo = Math.max(0, magazineAmmo);
        reserveAmmo = Math.max(0, reserveAmmo);
    }
}

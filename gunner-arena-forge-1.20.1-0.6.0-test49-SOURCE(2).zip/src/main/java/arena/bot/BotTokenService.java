package arena.bot;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/** One active strong token per reserved bot name. Tokens rotate with the bot slot. */
public final class BotTokenService {
    private final SecureRandom random = new SecureRandom();
    private final Map<String, byte[]> hashes = new HashMap<>();

    public synchronized String issue(String name) {
        byte[] raw = new byte[32];
        random.nextBytes(raw);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
        hashes.put(key(name), sha256(token));
        return token;
    }

    public synchronized boolean validate(String name, String token) {
        if (token == null || token.length() < 32) return false;
        byte[] expected = hashes.get(key(name));
        return expected != null && MessageDigest.isEqual(expected, sha256(token));
    }

    public synchronized void revoke(String name) { hashes.remove(key(name)); }
    public synchronized boolean reserved(String name) { return hashes.containsKey(key(name)); }

    private static String key(String name) { return name == null ? "" : name.toLowerCase(java.util.Locale.ROOT); }
    private static byte[] sha256(String value) {
        try { return MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }
}

package arena.economy;

import arena.profile.PlayerProfile;
import arena.profile.RoundSession;

public final class CurrencyService {
    public static final int DEFAULT_START_CREDITS = 500;
    public static final int DEFAULT_KILL_CREDITS = 300;
    public static final int DEFAULT_ASSIST_CREDITS = 100;

    public void resetRound(RoundSession s) { s.resetForNewRound(DEFAULT_START_CREDITS); }
    public void rewardKill(RoundSession s, double multiplier) {
        s.addCredits((int)Math.round(DEFAULT_KILL_CREDITS * clamp(multiplier, 0.0, 2.0)));
    }
    public void rewardAssist(RoundSession s, double multiplier) {
        s.addCredits((int)Math.round(DEFAULT_ASSIST_CREDITS * clamp(multiplier, 0.0, 2.0)));
    }
    public boolean spendCredits(RoundSession s, int amount) { return s.spendCredits(amount); }

    public void giveCoins(PlayerProfile p, long amount) { p.coins = safeAdd(p.coins, amount); }
    public void takeCoins(PlayerProfile p, long amount) { p.coins = Math.max(0, p.coins - Math.max(0, amount)); }
    public void giveCrystals(PlayerProfile p, long amount) { p.crystals = safeAdd(p.crystals, amount); }
    public void takeCrystals(PlayerProfile p, long amount) { p.crystals = Math.max(0, p.crystals - Math.max(0, amount)); }

    private static long safeAdd(long a, long b) {
        if (b <= 0) return a;
        if (Long.MAX_VALUE - a < b) return Long.MAX_VALUE;
        return a + b;
    }
    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
}

package arena.combat;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-independent recent-damage tracker used for assists.
 * Time is expressed in server ticks so it can be unit-tested without Forge.
 */
public final class DamageTracker {
    public static final long ASSIST_WINDOW_TICKS = 20L * 8L;
    public static final double MIN_DAMAGE_FLOOR = 2.0;
    public static final double MIN_HEALTH_FRACTION = 0.15;

    private static final class Contribution {
        double damage;
        long lastHitTick;
    }

    private final Map<UUID, Map<UUID, Contribution>> byVictim = new ConcurrentHashMap<>();

    /** Result used when a player disconnects during recent PvP combat. */
    public record CombatLogoutResult(UUID killer, List<UUID> assistants) {
        public static CombatLogoutResult none() { return new CombatLogoutResult(null, List.of()); }
        public boolean inCombat() { return killer != null || !assistants.isEmpty(); }
    }

    public void record(UUID victim, UUID attacker, double damage, long tick) {
        if (victim == null || attacker == null || victim.equals(attacker) || damage <= 0.0) return;
        Map<UUID, Contribution> contributors = byVictim.computeIfAbsent(victim, ignored -> new ConcurrentHashMap<>());
        Contribution c = contributors.computeIfAbsent(attacker, ignored -> new Contribution());
        c.damage += damage;
        c.lastHitTick = tick;
    }

    /** Returns qualifying assistants and consumes the victim's current damage history. */
    public List<UUID> consumeAssists(UUID victim, UUID killer, long nowTick, double victimMaxHealth) {
        Map<UUID, Contribution> contributors = byVictim.remove(victim);
        if (contributors == null || contributors.isEmpty()) return List.of();

        double threshold = Math.max(MIN_DAMAGE_FLOOR, Math.max(0.0, victimMaxHealth) * MIN_HEALTH_FRACTION);
        List<Map.Entry<UUID, Contribution>> ordered = new ArrayList<>(contributors.entrySet());
        ordered.removeIf(e -> e.getKey().equals(victim)
            || (killer != null && e.getKey().equals(killer))
            || nowTick - e.getValue().lastHitTick > ASSIST_WINDOW_TICKS
            || e.getValue().damage < threshold);
        ordered.sort((a, b) -> Double.compare(b.getValue().damage, a.getValue().damage));
        return ordered.stream().map(Map.Entry::getKey).toList();
    }


    /**
     * Consumes recent PvP evidence for a combat logout. The most recent qualifying
     * contributor is credited as killer; other qualifying contributors become assists.
     * No evidence older than the normal assist window can punish a disconnect.
     */
    public CombatLogoutResult consumeCombatLogout(UUID victim, long nowTick, double victimMaxHealth) {
        Map<UUID, Contribution> contributors = byVictim.remove(victim);
        if (contributors == null || contributors.isEmpty()) return CombatLogoutResult.none();

        double threshold = Math.max(MIN_DAMAGE_FLOOR, Math.max(0.0, victimMaxHealth) * MIN_HEALTH_FRACTION);
        List<Map.Entry<UUID, Contribution>> active = new ArrayList<>(contributors.entrySet());
        active.removeIf(e -> e.getKey().equals(victim)
            || nowTick - e.getValue().lastHitTick > ASSIST_WINDOW_TICKS
            || e.getValue().damage < threshold);
        if (active.isEmpty()) return CombatLogoutResult.none();

        // Recent hit wins the kill credit. Damage is the deterministic tie breaker.
        active.sort((a, b) -> {
            int recent = Long.compare(b.getValue().lastHitTick, a.getValue().lastHitTick);
            if (recent != 0) return recent;
            return Double.compare(b.getValue().damage, a.getValue().damage);
        });
        UUID killer = active.get(0).getKey();

        List<Map.Entry<UUID, Contribution>> assistEntries = new ArrayList<>(active.subList(1, active.size()));
        assistEntries.sort((a, b) -> Double.compare(b.getValue().damage, a.getValue().damage));
        List<UUID> assistants = assistEntries.stream().map(Map.Entry::getKey).toList();
        return new CombatLogoutResult(killer, assistants);
    }

    public void clear(UUID victim) { if (victim != null) byVictim.remove(victim); }

    /** Removes one attacker from every victim history (logout / session invalidation). */
    public void forgetAttacker(UUID attacker) {
        if (attacker == null) return;
        byVictim.entrySet().removeIf(victimEntry -> {
            Map<UUID, Contribution> contributors = victimEntry.getValue();
            contributors.remove(attacker);
            return contributors.isEmpty();
        });
    }

    /**
     * Periodic memory/logic cleanup. Old hits must not survive forever when a victim
     * leaves combat without dying, and they must never become a future-life assist.
     */
    public int pruneExpired(long nowTick) {
        int before = trackedContributions();
        byVictim.entrySet().removeIf(victimEntry -> {
            Map<UUID, Contribution> contributors = victimEntry.getValue();
            contributors.entrySet().removeIf(e -> nowTick - e.getValue().lastHitTick > ASSIST_WINDOW_TICKS);
            return contributors.isEmpty();
        });
        return Math.max(0, before - trackedContributions());
    }

    public int trackedContributions() {
        int total = 0;
        for (Map<UUID, Contribution> contributors : byVictim.values()) total += contributors.size();
        return total;
    }

    public void clearAll() { byVictim.clear(); }
    public int trackedVictims() { return byVictim.size(); }
}

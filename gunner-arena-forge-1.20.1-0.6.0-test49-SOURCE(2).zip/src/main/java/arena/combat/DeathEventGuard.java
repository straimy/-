package arena.combat;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Idempotency guard for player death processing.
 *
 * Forge normally emits one LivingDeathEvent, but gun/projectile mods can cause
 * overlapping fatal callbacks around the same tick. Economy/stat mutations
 * must therefore be explicitly one-shot instead of relying only on event order.
 */
public final class DeathEventGuard {
    public static final long DUPLICATE_WINDOW_TICKS = 20L;

    private final Map<UUID, Long> acceptedDeathTick = new ConcurrentHashMap<>();

    /** Returns true only for the first accepted death in the duplicate window. */
    public boolean tryAccept(UUID playerId, long tick) {
        if (playerId == null) return false;
        Long previous = acceptedDeathTick.putIfAbsent(playerId, tick);
        if (previous == null) return true;
        if (tick - previous > DUPLICATE_WINDOW_TICKS) {
            acceptedDeathTick.put(playerId, tick);
            return true;
        }
        return false;
    }

    /** Call after a real respawn so the next life can produce a death immediately. */
    public void onRespawn(UUID playerId) {
        if (playerId != null) acceptedDeathTick.remove(playerId);
    }

    public void forget(UUID playerId) {
        if (playerId != null) acceptedDeathTick.remove(playerId);
    }

    public void clear() { acceptedDeathTick.clear(); }
    public int trackedPlayers() { return acceptedDeathTick.size(); }
}

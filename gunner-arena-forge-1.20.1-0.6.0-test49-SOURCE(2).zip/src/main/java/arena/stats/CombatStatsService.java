package arena.stats;

import arena.profile.PlayerProfile;
import arena.profile.RoundSession;

public final class CombatStatsService {
    public void kill(PlayerProfile p, RoundSession s) {
        p.kills++; s.addKill();
        p.bestKillStreak = Math.max(p.bestKillStreak, s.roundKills());
    }
    public void death(PlayerProfile p, RoundSession s) { p.deaths++; s.addDeath(); }
    public void assist(PlayerProfile p, RoundSession s) { p.assists++; s.addAssist(); }
    public void damage(PlayerProfile p, RoundSession s, long amount) { long v = Math.max(0, amount); p.damageDealt += v; s.addDamage(v); }
    public void shot(PlayerProfile p, boolean hit) { p.shotsFired++; if (hit) p.shotsHit++; }
    public double kd(PlayerProfile p) { return p.deaths == 0 ? p.kills : (double)p.kills / (double)p.deaths; }
    public double accuracy(PlayerProfile p) { return p.shotsFired == 0 ? 0.0 : (double)p.shotsHit / (double)p.shotsFired; }
}

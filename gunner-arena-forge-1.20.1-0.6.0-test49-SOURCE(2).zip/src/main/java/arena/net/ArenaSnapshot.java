package arena.net;

/**
 * Side-neutral immutable view of the state the UI is allowed to know.
 * The server remains authoritative: clients never send these values back.
 */
public record ArenaSnapshot(
    boolean authenticated,
    boolean initialized,
    String playerName,
    String roundState,
    int roundNumber,
    int roundRemainingTicks,
    int roundCredits,
    long coins,
    long crystals,
    int level,
    long xp,
    int skillPoints,
    long kills,
    long deaths,
    long assists,
    long damageDealt,
    long shotsFired,
    long shotsHit,
    int bestKillStreak,
    long roundsPlayed,
    long roundsWon,
    long playTimeSeconds,
    int roundKills,
    int roundDeaths,
    int roundAssists,
    long roundDamage
) {
    public ArenaSnapshot {
        playerName = clean(playerName, 64, "");
        roundState = clean(roundState, 32, "UNKNOWN");
        roundNumber = Math.max(0, roundNumber);
        roundRemainingTicks = Math.max(0, roundRemainingTicks);
        roundCredits = Math.max(0, roundCredits);
        coins = Math.max(0L, coins);
        crystals = Math.max(0L, crystals);
        level = Math.max(1, level);
        xp = Math.max(0L, xp);
        skillPoints = Math.max(0, skillPoints);
        kills = Math.max(0L, kills);
        deaths = Math.max(0L, deaths);
        assists = Math.max(0L, assists);
        damageDealt = Math.max(0L, damageDealt);
        shotsFired = Math.max(0L, shotsFired);
        shotsHit = Math.min(Math.max(0L, shotsHit), shotsFired);
        bestKillStreak = Math.max(0, bestKillStreak);
        roundsPlayed = Math.max(0L, roundsPlayed);
        roundsWon = Math.min(Math.max(0L, roundsWon), roundsPlayed);
        playTimeSeconds = Math.max(0L, playTimeSeconds);
        roundKills = Math.max(0, roundKills);
        roundDeaths = Math.max(0, roundDeaths);
        roundAssists = Math.max(0, roundAssists);
        roundDamage = Math.max(0L, roundDamage);
    }

    public static ArenaSnapshot unauthenticated(String name, String roundState, int roundNumber, int remainingTicks) {
        return new ArenaSnapshot(false, false, name, roundState, roundNumber, remainingTicks,
            0, 0, 0, 1, 0, 0,
            0, 0, 0, 0, 0, 0, 0,
            0, 0, 0,
            0, 0, 0, 0);
    }

    public double kd() { return deaths == 0L ? (double) kills : (double) kills / (double) deaths; }
    public double accuracy() { return shotsFired == 0L ? 0.0D : (double) shotsHit / (double) shotsFired; }
    public int remainingSeconds() { return (roundRemainingTicks + 19) / 20; }

    private static String clean(String value, int max, String fallback) {
        if (value == null || value.isBlank()) return fallback;
        String normalized = value.replace('\n', ' ').replace('\r', ' ').trim();
        return normalized.length() <= max ? normalized : normalized.substring(0, max);
    }
}

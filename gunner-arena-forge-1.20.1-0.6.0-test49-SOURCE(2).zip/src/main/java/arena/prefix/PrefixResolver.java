package arena.prefix;

/** OP/permission-backed role resolver kept free from Forge classes for testing. */
public final class PrefixResolver {
    public PrefixRole roleForPermissionLevel(int permissionLevel) {
        return permissionLevel >= 2 ? PrefixRole.ADMIN : PrefixRole.PLAYER;
    }

    public PrefixStyle style(PrefixRole role) {
        return switch (role) {
            case ADMIN -> new PrefixStyle(role, "АДМИН", new int[]{0xFFD34E, 0xFF8A3D, 0xC05CFF}, "✦");
            case PLAYER -> new PrefixStyle(role, "ИГРОК", new int[]{0x61D8FF, 0xA7ECFF, 0xFFFFFF}, "✦");
        };
    }
}

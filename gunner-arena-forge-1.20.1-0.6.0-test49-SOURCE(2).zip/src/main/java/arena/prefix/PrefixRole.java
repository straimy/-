package arena.prefix;

public enum PrefixRole {
    PLAYER,
    ADMIN
}

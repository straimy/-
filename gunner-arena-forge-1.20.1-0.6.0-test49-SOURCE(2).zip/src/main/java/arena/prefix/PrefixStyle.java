package arena.prefix;

/** Pure-data presentation contract. Forge/client adapters convert RGB stops into Components. */
public record PrefixStyle(PrefixRole role, String label, int[] rgbStops, String symbol) {
    public PrefixStyle {
        if (role == null || label == null || label.isBlank() || symbol == null) throw new IllegalArgumentException();
        if (rgbStops == null || rgbStops.length < 2) throw new IllegalArgumentException("rgbStops");
        rgbStops = rgbStops.clone();
    }
    @Override public int[] rgbStops() { return rgbStops.clone(); }
}

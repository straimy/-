package arena.forge.net;

import arena.GunnerArenaMod;
import arena.forge.player.ArenaPlayerState;
import arena.loadout.LoadoutManager;
import arena.net.ArenaSnapshot;
import arena.profile.RoundSession;
import arena.round.RoundState;
import arena.weapon.WeaponDefinition;
import arena.weapon.WeaponSafetyPolicy;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/** Server half of the Gunner Arena UI protocol. No client-only classes are referenced here. */
public final class ArenaNetwork {
    public static final String PROTOCOL_VERSION = "5";
    private static final ResourceLocation CHANNEL_ID = new ResourceLocation("gunnerarena", "ui");
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        CHANNEL_ID,
        () -> PROTOCOL_VERSION,
        PROTOCOL_VERSION::equals,
        PROTOCOL_VERSION::equals
    );
    private static final Map<UUID, Long> LAST_BUY_TICK = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_WEAPON_ACTION_TICK = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_SKILL_ACTION_TICK = new ConcurrentHashMap<>();
    private static boolean registered;

    private ArenaNetwork() {}

    public static synchronized void register() {
        if (registered) return;
        int id = 0;
        CHANNEL.registerMessage(id++, SnapshotRequest.class, SnapshotRequest::encode, SnapshotRequest::decode, SnapshotRequest::handle);
        CHANNEL.registerMessage(id++, SnapshotPacket.class, SnapshotPacket::encode, SnapshotPacket::decode, SnapshotPacket::handleServerNoop);
        CHANNEL.registerMessage(id++, CatalogRequest.class, CatalogRequest::encode, CatalogRequest::decode, CatalogRequest::handle);
        CHANNEL.registerMessage(id++, CatalogPacket.class, CatalogPacket::encode, CatalogPacket::decode, CatalogPacket::handleServerNoop);
        CHANNEL.registerMessage(id++, BuyRequest.class, BuyRequest::encode, BuyRequest::decode, BuyRequest::handle);
        CHANNEL.registerMessage(id++, BuyResultPacket.class, BuyResultPacket::encode, BuyResultPacket::decode, BuyResultPacket::handleServerNoop);
        CHANNEL.registerMessage(id++, OpenUiPacket.class, OpenUiPacket::encode, OpenUiPacket::decode, OpenUiPacket::handleServerNoop);
        CHANNEL.registerMessage(id++, WeaponActionRequest.class, WeaponActionRequest::encode, WeaponActionRequest::decode, WeaponActionRequest::handle);
        CHANNEL.registerMessage(id++, SkillTreeRequest.class, SkillTreeRequest::encode, SkillTreeRequest::decode, SkillTreeRequest::handle);
        CHANNEL.registerMessage(id++, SkillTreePacket.class, SkillTreePacket::encode, SkillTreePacket::decode, SkillTreePacket::handleServerNoop);
        CHANNEL.registerMessage(id, SkillUnlockRequest.class, SkillUnlockRequest::encode, SkillUnlockRequest::decode, SkillUnlockRequest::handle);
        registered = true;
    }

    public static void sendSnapshot(ServerPlayer player) {
        if (player == null) return;
        ArenaSnapshot snapshot = GunnerArenaMod.RUNTIME.createSnapshot(player);
        CHANNEL.send(PacketDistributor.PLAYER.with(player), new SnapshotPacket(snapshot));
    }

    public static void sendCatalog(ServerPlayer player) {
        if (player == null) return;
        List<CatalogEntry> entries = new ArrayList<>();
        for (WeaponDefinition def : GunnerArenaMod.RUNTIME.weapons().all()) {
            boolean quarantined = WeaponSafetyPolicy.isQuarantined(def.id());
            boolean available = !quarantined && GunnerArenaMod.RUNTIME.forgeLoadouts().isAvailable(def.id());
            entries.add(CatalogEntry.from(def, available, quarantined));
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(player), new CatalogPacket(List.copyOf(entries)));
    }


    /** Server-authoritative UI opener. Future NPC interaction should call this instead of simulating a key press. */
    public static void openUi(ServerPlayer player, UiTarget target) {
        if (player == null || target == null) return;
        CHANNEL.send(PacketDistributor.PLAYER.with(player), new OpenUiPacket(target));
    }

    public static void openMainUi(ServerPlayer player) { openUi(player, UiTarget.MAIN); }

    public enum UiTarget { MAIN, SHOP, PROFILE, SKILLS }

    /** Clears per-connection anti-spam bookkeeping. */
    public static void forget(ServerPlayer player) {
        if (player != null) {
            LAST_BUY_TICK.remove(player.getUUID());
            LAST_WEAPON_ACTION_TICK.remove(player.getUUID());
            LAST_SKILL_ACTION_TICK.remove(player.getUUID());
        }
    }

    public record OpenUiPacket(UiTarget target) {
        public OpenUiPacket { target = target == null ? UiTarget.MAIN : target; }
        static void encode(OpenUiPacket packet, FriendlyByteBuf buf) { buf.writeByte(packet.target.ordinal()); }
        static OpenUiPacket decode(FriendlyByteBuf buf) {
            int raw = buf.readUnsignedByte();
            UiTarget[] values = UiTarget.values();
            return new OpenUiPacket(raw >= 0 && raw < values.length ? values[raw] : UiTarget.MAIN);
        }
        static void handleServerNoop(OpenUiPacket ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }


    public enum WeaponAction { RELOAD, CYCLE_FIREMODE }

    /** Client sends only an action enum; weapon/ammo/mode authority remains entirely server-side. */
    public record WeaponActionRequest(WeaponAction action) {
        public WeaponActionRequest { action = action == null ? WeaponAction.RELOAD : action; }
        static void encode(WeaponActionRequest p, FriendlyByteBuf b) { b.writeByte(p.action.ordinal()); }
        static WeaponActionRequest decode(FriendlyByteBuf b) {
            int raw = b.readUnsignedByte();
            WeaponAction[] values = WeaponAction.values();
            return new WeaponActionRequest(raw >= 0 && raw < values.length ? values[raw] : WeaponAction.RELOAD);
        }
        static void handle(WeaponActionRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player == null) return;
                var runtime = GunnerArenaMod.RUNTIME;
                if (!runtime.isCustomCombatAllowed(player)) return;
                long tick = runtime.serverTick();
                Long previous = LAST_WEAPON_ACTION_TICK.get(player.getUUID());
                if (previous != null && tick - previous < 2L) return;
                LAST_WEAPON_ACTION_TICK.put(player.getUUID(), tick);

                var result = switch (packet.action) {
                    case RELOAD -> runtime.customWeaponCombat().requestReload(player, tick * 50L);
                    case CYCLE_FIREMODE -> runtime.customWeaponCombat().cycleMode(player);
                };
                player.displayClientMessage(Component.literal(result.message()), true);
            });
            ctx.setPacketHandled(true);
        }
    }


    public static void sendSkillTree(ServerPlayer player) {
        if (player == null) return;
        var runtime = GunnerArenaMod.RUNTIME;
        var profile = runtime.players().profile(player);
        if (profile == null) return;
        List<SkillEntry> entries = new ArrayList<>();
        for (var skill : runtime.rpg().catalog().all()) {
            var check = runtime.rpg().checkUnlock(profile, skill.id());
            entries.add(new SkillEntry(skill.id(), skill.name(), skill.branch().name(), skill.cost(), skill.minLevel(),
                String.join(",", skill.prerequisites()), skill.major(), skill.active(), profile.unlockedSkills.contains(skill.id()),
                check.ok(), check.code().name()));
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(player), new SkillTreePacket(profile.level, profile.skillPoints, profile.specialization, entries));
    }

    public record SkillTreeRequest() {
        static void encode(SkillTreeRequest ignored, FriendlyByteBuf b) {}
        static SkillTreeRequest decode(FriendlyByteBuf b) { return new SkillTreeRequest(); }
        static void handle(SkillTreeRequest ignored, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get();
            ctx.enqueueWork(() -> { ServerPlayer p = ctx.getSender(); if (p != null) sendSkillTree(p); });
            ctx.setPacketHandled(true);
        }
    }

    public record SkillEntry(String id, String name, String branch, int cost, int minLevel, String prerequisites,
                             boolean major, boolean active, boolean unlocked, boolean available, String reason) {
        public SkillEntry {
            id = id == null ? "" : id;
            name = name == null ? "" : name;
            branch = branch == null ? "" : branch;
            prerequisites = prerequisites == null ? "" : prerequisites;
            reason = reason == null ? "" : reason;
            cost = Math.max(0, cost); minLevel = Math.max(1, minLevel);
        }
        static void write(FriendlyByteBuf b, SkillEntry e) {
            b.writeUtf(e.id, 64); b.writeUtf(e.name, 96); b.writeUtf(e.branch, 24); b.writeVarInt(e.cost); b.writeVarInt(e.minLevel);
            b.writeUtf(e.prerequisites, 192); b.writeBoolean(e.major); b.writeBoolean(e.active); b.writeBoolean(e.unlocked); b.writeBoolean(e.available); b.writeUtf(e.reason, 48);
        }
        static SkillEntry read(FriendlyByteBuf b) {
            return new SkillEntry(b.readUtf(64), b.readUtf(96), b.readUtf(24), b.readVarInt(), b.readVarInt(), b.readUtf(192),
                b.readBoolean(), b.readBoolean(), b.readBoolean(), b.readBoolean(), b.readUtf(48));
        }
    }

    public record SkillTreePacket(int level, int skillPoints, String specialization, List<SkillEntry> entries) {
        public SkillTreePacket {
            level = Math.max(1, level); skillPoints = Math.max(0, skillPoints); specialization = specialization == null ? "NONE" : specialization;
            entries = entries == null ? List.of() : List.copyOf(entries);
        }
        static void encode(SkillTreePacket p, FriendlyByteBuf b) {
            b.writeVarInt(p.level); b.writeVarInt(p.skillPoints); b.writeUtf(p.specialization, 32);
            int size = Math.min(64, p.entries.size()); b.writeVarInt(size); for (int i=0;i<size;i++) SkillEntry.write(b, p.entries.get(i));
        }
        static SkillTreePacket decode(FriendlyByteBuf b) {
            int level=b.readVarInt(), points=b.readVarInt(); String spec=b.readUtf(32); int size=Math.max(0,Math.min(64,b.readVarInt()));
            List<SkillEntry> out=new ArrayList<>(size); for(int i=0;i<size;i++) out.add(SkillEntry.read(b)); return new SkillTreePacket(level,points,spec,out);
        }
        static void handleServerNoop(SkillTreePacket ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }

    public record SkillUnlockRequest(String id) {
        public SkillUnlockRequest { id = id == null ? "" : id.trim(); }
        static void encode(SkillUnlockRequest p, FriendlyByteBuf b) { b.writeUtf(p.id, 64); }
        static SkillUnlockRequest decode(FriendlyByteBuf b) { return new SkillUnlockRequest(b.readUtf(64)); }
        static void handle(SkillUnlockRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player=ctx.getSender(); if(player==null || packet.id.isBlank()) return;
                var runtime=GunnerArenaMod.RUNTIME; var profile=runtime.players().profile(player); if(profile==null) return;
                long tick=runtime.serverTick(); long last=LAST_SKILL_ACTION_TICK.getOrDefault(player.getUUID(),Long.MIN_VALUE/4); if(tick-last<4L) return;
                LAST_SKILL_ACTION_TICK.put(player.getUUID(),tick);
                var result=runtime.rpg().unlock(profile,packet.id);
                if(result.ok()) { runtime.profiles().markDirty(player.getUUID()); player.sendSystemMessage(Component.literal("[GA] Навык открыт: "+result.skill().name())); }
                else player.sendSystemMessage(Component.literal("[GA] Навык недоступен: "+result.code()));
                sendSkillTree(player); sendSnapshot(player);
            });
            ctx.setPacketHandled(true);
        }
    }

    public record SnapshotRequest() {
        static void encode(SnapshotRequest ignored, FriendlyByteBuf buf) {}
        static SnapshotRequest decode(FriendlyByteBuf buf) { return new SnapshotRequest(); }
        static void handle(SnapshotRequest ignored, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer sender = ctx.getSender();
                if (sender != null) sendSnapshot(sender);
            });
            ctx.setPacketHandled(true);
        }
    }

    public record SnapshotPacket(ArenaSnapshot snapshot) {
        static void encode(SnapshotPacket packet, FriendlyByteBuf buf) { SnapshotWire.write(buf, packet.snapshot); }
        static SnapshotPacket decode(FriendlyByteBuf buf) { return new SnapshotPacket(SnapshotWire.read(buf)); }
        static void handleServerNoop(SnapshotPacket ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }

    public record CatalogRequest() {
        static void encode(CatalogRequest ignored, FriendlyByteBuf buf) {}
        static CatalogRequest decode(FriendlyByteBuf buf) { return new CatalogRequest(); }
        static void handle(CatalogRequest ignored, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer sender = ctx.getSender();
                if (sender != null) sendCatalog(sender);
            });
            ctx.setPacketHandled(true);
        }
    }

    public record CatalogPacket(List<CatalogEntry> entries) {
        public CatalogPacket { entries = entries == null ? List.of() : List.copyOf(entries); }
        static void encode(CatalogPacket packet, FriendlyByteBuf buf) {
            int size = Math.min(packet.entries.size(), 128);
            buf.writeVarInt(size);
            for (int i = 0; i < size; i++) packet.entries.get(i).write(buf);
        }
        static CatalogPacket decode(FriendlyByteBuf buf) {
            int size = Math.max(0, Math.min(buf.readVarInt(), 128));
            List<CatalogEntry> out = new ArrayList<>(size);
            for (int i = 0; i < size; i++) out.add(CatalogEntry.read(buf));
            return new CatalogPacket(out);
        }
        static void handleServerNoop(CatalogPacket ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }

    public record CatalogEntry(
        String id, String displayName, String category, String slot, int price,
        String ammoItem, int magazineSize, int startingReserve, String fireModes,
        String scope, boolean available, boolean quarantined
    ) {
        static CatalogEntry from(WeaponDefinition d, boolean available, boolean quarantined) {
            String modes = d.fireModes().stream().map(Enum::name).reduce((a,b) -> a + "," + b).orElse("");
            return new CatalogEntry(d.id(), d.displayName(), d.category().name(), d.slot().name(), d.price(),
                d.ammoItem() == null ? "" : d.ammoItem(), d.magazineSize(), d.startingReserve(), modes,
                d.scope().name(), available, quarantined);
        }
        void write(FriendlyByteBuf b) {
            b.writeUtf(id, 128); b.writeUtf(displayName, 96); b.writeUtf(category, 24); b.writeUtf(slot, 24);
            b.writeVarInt(Math.max(0, price)); b.writeUtf(ammoItem, 128); b.writeVarInt(Math.max(0, magazineSize));
            b.writeVarInt(Math.max(0, startingReserve)); b.writeUtf(fireModes, 96); b.writeUtf(scope, 24);
            b.writeBoolean(available); b.writeBoolean(quarantined);
        }
        static CatalogEntry read(FriendlyByteBuf b) {
            return new CatalogEntry(b.readUtf(128), b.readUtf(96), b.readUtf(24), b.readUtf(24), b.readVarInt(),
                b.readUtf(128), b.readVarInt(), b.readVarInt(), b.readUtf(96), b.readUtf(24), b.readBoolean(), b.readBoolean());
        }
    }

    /** Client sends only a bounded weapon id. Price/slot/item/ammo always come from the server catalog. */
    public record BuyRequest(String weaponId) {
        public BuyRequest { weaponId = weaponId == null ? "" : weaponId.trim(); }
        static void encode(BuyRequest packet, FriendlyByteBuf buf) { buf.writeUtf(packet.weaponId, 128); }
        static BuyRequest decode(FriendlyByteBuf buf) { return new BuyRequest(buf.readUtf(128)); }
        static void handle(BuyRequest packet, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx = supplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player != null) handleBuy(player, packet.weaponId);
            });
            ctx.setPacketHandled(true);
        }
    }

    private static void handleBuy(ServerPlayer player, String weaponId) {
        var runtime = GunnerArenaMod.RUNTIME;
        if (!runtime.auth().isAuthenticated(player) || !runtime.auth().isInitialized(player)) {
            sendBuyResult(player, false, "NOT_READY", "Сначала авторизуйся.", 0); return;
        }
        if (runtime.rounds().state() != RoundState.PLAYING) {
            sendBuyResult(player, false, "ROUND_NOT_PLAYING", "Магазин оружия доступен во время раунда.", runtime.players().roundSession(player).credits()); return;
        }
        if (runtime.players().session(player).state() != ArenaPlayerState.ALIVE) {
            sendBuyResult(player, false, "NOT_ALIVE", "Покупка доступна только живому игроку.", runtime.players().roundSession(player).credits()); return;
        }
        if (weaponId == null || weaponId.isBlank() || weaponId.length() > 128) {
            sendBuyResult(player, false, "BAD_ID", "Некорректный ID оружия.", runtime.players().roundSession(player).credits()); return;
        }
        long now = runtime.serverTick();
        long last = LAST_BUY_TICK.getOrDefault(player.getUUID(), Long.MIN_VALUE / 4);
        if (now - last < 4L) {
            sendBuyResult(player, false, "TOO_FAST", "Слишком быстро. Повтори через мгновение.", runtime.players().roundSession(player).credits()); return;
        }
        LAST_BUY_TICK.put(player.getUUID(), now);
        if (WeaponSafetyPolicy.isQuarantined(weaponId)) {
            sendBuyResult(player, false, "QUARANTINED", "Оружие временно отключено из-за crash quarantine.", runtime.players().roundSession(player).credits()); return;
        }
        if (!runtime.forgeLoadouts().isAvailable(weaponId)) {
            sendBuyResult(player, false, "UNAVAILABLE", "Это оружие пока недоступно на сервере.", runtime.players().roundSession(player).credits()); return;
        }

        RoundSession round = runtime.players().roundSession(player);
        LoadoutManager.BuyResult result = runtime.forgeLoadouts().buyAndGive(player, round, weaponId);
        switch (result) {
            case OK -> sendBuyResult(player, true, "OK", "Оружие куплено.", round.credits());
            case NOT_ENOUGH_CREDITS -> sendBuyResult(player, false, "NOT_ENOUGH_CREDITS", "Недостаточно Credits.", round.credits());
            case UNAVAILABLE_ITEM -> sendBuyResult(player, false, "UNAVAILABLE", "Предмет не зарегистрирован на сервере.", round.credits());
            default -> sendBuyResult(player, false, "UNKNOWN_WEAPON", "Неизвестное оружие.", round.credits());
        }
        sendSnapshot(player);
    }

    private static void sendBuyResult(ServerPlayer player, boolean ok, String code, String message, int credits) {
        CHANNEL.send(PacketDistributor.PLAYER.with(player), new BuyResultPacket(ok, code, message, Math.max(0, credits)));
    }

    public record BuyResultPacket(boolean ok, String code, String message, int credits) {
        public BuyResultPacket {
            code = code == null ? "" : code;
            message = message == null ? "" : message;
            credits = Math.max(0, credits);
        }
        static void encode(BuyResultPacket p, FriendlyByteBuf b) {
            b.writeBoolean(p.ok); b.writeUtf(p.code, 48); b.writeUtf(p.message, 160); b.writeVarInt(p.credits);
        }
        static BuyResultPacket decode(FriendlyByteBuf b) {
            return new BuyResultPacket(b.readBoolean(), b.readUtf(48), b.readUtf(160), b.readVarInt());
        }
        static void handleServerNoop(BuyResultPacket ignored, Supplier<NetworkEvent.Context> supplier) { supplier.get().setPacketHandled(true); }
    }

    static final class SnapshotWire {
        private SnapshotWire() {}
        static void write(FriendlyByteBuf b, ArenaSnapshot s) {
            b.writeBoolean(s.authenticated()); b.writeBoolean(s.initialized()); b.writeUtf(s.playerName(), 64); b.writeUtf(s.roundState(), 32);
            b.writeVarInt(s.roundNumber()); b.writeVarInt(s.roundRemainingTicks()); b.writeVarInt(s.roundCredits());
            b.writeVarLong(s.coins()); b.writeVarLong(s.crystals()); b.writeVarInt(s.level()); b.writeVarLong(s.xp()); b.writeVarInt(s.skillPoints());
            b.writeVarLong(s.kills()); b.writeVarLong(s.deaths()); b.writeVarLong(s.assists()); b.writeVarLong(s.damageDealt());
            b.writeVarLong(s.shotsFired()); b.writeVarLong(s.shotsHit()); b.writeVarInt(s.bestKillStreak());
            b.writeVarLong(s.roundsPlayed()); b.writeVarLong(s.roundsWon()); b.writeVarLong(s.playTimeSeconds());
            b.writeVarInt(s.roundKills()); b.writeVarInt(s.roundDeaths()); b.writeVarInt(s.roundAssists()); b.writeVarLong(s.roundDamage());
        }
        static ArenaSnapshot read(FriendlyByteBuf b) {
            return new ArenaSnapshot(
                b.readBoolean(), b.readBoolean(), b.readUtf(64), b.readUtf(32), b.readVarInt(), b.readVarInt(), b.readVarInt(),
                b.readVarLong(), b.readVarLong(), b.readVarInt(), b.readVarLong(), b.readVarInt(), b.readVarLong(), b.readVarLong(),
                b.readVarLong(), b.readVarLong(), b.readVarLong(), b.readVarLong(), b.readVarInt(), b.readVarLong(), b.readVarLong(),
                b.readVarLong(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarLong()
            );
        }
    }
}

package arena.forge.hazard;

import arena.hazard.ActiveHazard;
import arena.hazard.HazardManager;
import arena.hazard.HazardSpec;
import arena.hazard.HazardType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * Forge/world executor for temporary admin hazards.
 * Contract: never breaks or permanently places blocks. Everything is particles,
 * sounds, temporary potion effects, damage and knockback.
 */
public final class ForgeHazardExecutor {
    private static final long DROP_IMPACT_TICK = 40L;
    private static final long GRAVITY_IMPACT_TICK = 30L;

    private static final class RuntimeState {
        boolean impactApplied;
    }

    private final Map<UUID, RuntimeState> states = new HashMap<>();

    public void tick(MinecraftServer server, HazardManager manager, long nowTick,
                     Predicate<ServerPlayer> mayAffectPlayer) {
        Set<UUID> alive = new HashSet<>();
        for (ActiveHazard hazard : manager.all()) {
            alive.add(hazard.id());
            RuntimeState state = states.computeIfAbsent(hazard.id(), ignored -> new RuntimeState());
            ServerLevel level = level(server, hazard.dimension());
            if (level == null) continue;
            long age = Math.max(0L, nowTick - hazard.createdTick());
            renderAndApply(level, manager, hazard, state, age, mayAffectPlayer);
        }
        states.keySet().removeIf(id -> !alive.contains(id));
    }

    public void clearRuntime() {
        states.clear();
    }

    private void renderAndApply(ServerLevel level, HazardManager manager, ActiveHazard hazard,
                                RuntimeState state, long age, Predicate<ServerPlayer> mayAffectPlayer) {
        HazardSpec spec = hazard.spec();
        switch (spec.type()) {
            case METEOR -> tickDrop(level, manager, hazard, state, age, mayAffectPlayer, true);
            case TNT_DROP -> tickDrop(level, manager, hazard, state, age, mayAffectPlayer, false);
            case WEB_BOMB -> tickWeb(level, manager, spec, state, age, mayAffectPlayer);
            case SHOCKWAVE -> tickShockwave(level, manager, spec, state, age, mayAffectPlayer);
            case SMOKE -> tickSmoke(level, manager, spec, age, mayAffectPlayer);
            case CRYO -> tickCryo(level, manager, spec, state, age, mayAffectPlayer);
            case GRAVITY_PULSE -> tickGravity(level, manager, spec, state, age, mayAffectPlayer);
        }
    }

    private void tickDrop(ServerLevel level, HazardManager manager, ActiveHazard hazard,
                          RuntimeState state, long age, Predicate<ServerPlayer> mayAffectPlayer,
                          boolean meteor) {
        HazardSpec s = hazard.spec();
        if (age < DROP_IMPACT_TICK) {
            double progress = age / (double) DROP_IMPACT_TICK;
            double y = s.y() + 18.0 * (1.0 - progress);
            level.sendParticles(meteor ? ParticleTypes.FLAME : ParticleTypes.SMOKE,
                s.x(), y, s.z(), meteor ? 12 : 8, 0.25, 0.55, 0.25, 0.02);
            if (meteor) level.sendParticles(ParticleTypes.LARGE_SMOKE, s.x(), y + 0.3, s.z(), 4, 0.2, 0.4, 0.2, 0.01);
            return;
        }
        if (state.impactApplied) return;
        state.impactApplied = true;
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, s.x(), s.y(), s.z(), 2, 0.1, 0.1, 0.1, 0.0);
        level.sendParticles(meteor ? ParticleTypes.FLAME : ParticleTypes.CLOUD,
            s.x(), s.y() + 0.4, s.z(), 80, s.radius() * 0.35, 1.0, s.radius() * 0.35, 0.08);
        level.playSound(null, s.x(), s.y(), s.z(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 2.0F, meteor ? 0.7F : 0.9F);
        radialDamage(level, manager, s, mayAffectPlayer, true);
    }

    private void tickWeb(ServerLevel level, HazardManager manager, HazardSpec s, RuntimeState state,
                         long age, Predicate<ServerPlayer> mayAffectPlayer) {
        if (age % 5L == 0L) {
            level.sendParticles(ParticleTypes.WHITE_ASH, s.x(), s.y() + 0.8, s.z(), 35,
                s.radius() * 0.45, 1.0, s.radius() * 0.45, 0.01);
        }
        forNearby(level, manager, s, mayAffectPlayer, p ->
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 12, 4, false, false, true)));
        if (!state.impactApplied) {
            state.impactApplied = true;
            level.playSound(null, s.x(), s.y(), s.z(), SoundEvents.WOOL_PLACE, SoundSource.BLOCKS, 1.2F, 0.7F);
        }
    }

    private void tickShockwave(ServerLevel level, HazardManager manager, HazardSpec s, RuntimeState state,
                               long age, Predicate<ServerPlayer> mayAffectPlayer) {
        if (state.impactApplied) return;
        state.impactApplied = true;
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, s.x(), s.y() + 0.4, s.z(), 100,
            s.radius() * 0.6, 0.6, s.radius() * 0.6, 0.15);
        level.playSound(null, s.x(), s.y(), s.z(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.0F, 1.5F);
        radialDamage(level, manager, s, mayAffectPlayer, true);
    }

    private void tickSmoke(ServerLevel level, HazardManager manager, HazardSpec s, long age,
                           Predicate<ServerPlayer> mayAffectPlayer) {
        if (age % 4L == 0L) {
            level.sendParticles(ParticleTypes.LARGE_SMOKE, s.x(), s.y() + 1.2, s.z(), 28,
                s.radius() * 0.45, 1.7, s.radius() * 0.45, 0.015);
        }
        forNearby(level, manager, s, mayAffectPlayer, p ->
            p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 16, 0, false, false, true)));
    }

    private void tickCryo(ServerLevel level, HazardManager manager, HazardSpec s, RuntimeState state,
                          long age, Predicate<ServerPlayer> mayAffectPlayer) {
        if (age % 5L == 0L) {
            level.sendParticles(ParticleTypes.SNOWFLAKE, s.x(), s.y() + 0.8, s.z(), 35,
                s.radius() * 0.5, 1.0, s.radius() * 0.5, 0.02);
        }
        forNearby(level, manager, s, mayAffectPlayer, p ->
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 16, 2, false, false, true)));
        if (!state.impactApplied) {
            state.impactApplied = true;
            radialDamage(level, manager, s, mayAffectPlayer, false);
        }
    }

    private void tickGravity(ServerLevel level, HazardManager manager, HazardSpec s, RuntimeState state,
                             long age, Predicate<ServerPlayer> mayAffectPlayer) {
        if (age < GRAVITY_IMPACT_TICK) {
            if (age % 3L == 0L) {
                level.sendParticles(ParticleTypes.PORTAL, s.x(), s.y() + 0.8, s.z(), 20,
                    s.radius() * 0.55, 1.0, s.radius() * 0.55, 0.12);
            }
            return;
        }
        if (state.impactApplied) return;
        state.impactApplied = true;
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, s.x(), s.y() + 0.5, s.z(), 90,
            s.radius() * 0.5, 0.8, s.radius() * 0.5, 0.18);
        level.playSound(null, s.x(), s.y(), s.z(), SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 1.2F, 0.55F);
        radialDamage(level, manager, s, mayAffectPlayer, false);
        forNearby(level, manager, s, mayAffectPlayer, p -> {
            double dx = p.getX() - s.x();
            double dz = p.getZ() - s.z();
            double len = Math.max(0.25, Math.sqrt(dx * dx + dz * dz));
            p.push((dx / len) * 1.15, 0.45, (dz / len) * 1.15);
        });
    }

    private void radialDamage(ServerLevel level, HazardManager manager, HazardSpec s,
                              Predicate<ServerPlayer> mayAffectPlayer, boolean knockback) {
        forNearby(level, manager, s, mayAffectPlayer, p -> {
            double distance = Math.sqrt(p.distanceToSqr(s.x(), s.y(), s.z()));
            double scale = Math.max(0.20, 1.0 - distance / Math.max(0.1, s.radius()));
            if (s.damage() > 0.0) p.hurt(p.damageSources().magic(), (float) (s.damage() * scale));
            if (knockback) {
                double dx = p.getX() - s.x();
                double dz = p.getZ() - s.z();
                double len = Math.max(0.25, Math.sqrt(dx * dx + dz * dz));
                p.push((dx / len) * (0.65 + scale), 0.25 + scale * 0.35, (dz / len) * (0.65 + scale));
            }
        });
    }

    private void forNearby(ServerLevel level, HazardManager manager, HazardSpec s,
                           Predicate<ServerPlayer> mayAffectPlayer,
                           java.util.function.Consumer<ServerPlayer> action) {
        double r2 = s.radius() * s.radius();
        for (ServerPlayer player : level.players()) {
            if (!mayAffectPlayer.test(player)) continue;
            if (!manager.mayDamage(level.dimension().location().toString(), player.getX(), player.getY(), player.getZ())) continue;
            if (player.distanceToSqr(s.x(), s.y(), s.z()) > r2) continue;
            action.accept(player);
        }
    }

    private ServerLevel level(MinecraftServer server, String dimension) {
        for (ServerLevel level : server.getAllLevels()) {
            if (level.dimension().location().toString().equals(dimension)) return level;
        }
        return null;
    }
}

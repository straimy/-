package arena.forge;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Lightweight bridge to SAuth 2.1+.
 * SAuth marks an authenticated session with the scoreboard tag
 * "sauth_authenticated". Console is always allowed.
 */
public final class AuthGate {
    public static final String AUTH_TAG = "sauth_authenticated";
    private final Set<UUID> initialized = new HashSet<>();

    public boolean isAuthenticated(ServerPlayer player) {
        return player.getTags().contains(AUTH_TAG);
    }

    public boolean commandSourceAllowed(CommandSourceStack source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) return true;
        return isAuthenticated(player);
    }

    public boolean markInitialized(ServerPlayer player) {
        return initialized.add(player.getUUID());
    }

    public boolean isInitialized(ServerPlayer player) {
        return initialized.contains(player.getUUID());
    }

    public void forget(ServerPlayer player) {
        initialized.remove(player.getUUID());
    }

    public void deny(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("[GA] Сначала войдите: /login <пароль> или /register <пароль>")
            .withStyle(ChatFormatting.YELLOW));
    }

    public void enforceLobby(MinecraftServer server, ServerPlayer player, arena.forge.spawn.SpawnManager spawns) {
        spawns.lobby().ifPresent(point -> spawns.teleport(server, player, point));
        player.setDeltaMovement(0, 0, 0);
        player.fallDistance = 0;
    }
}

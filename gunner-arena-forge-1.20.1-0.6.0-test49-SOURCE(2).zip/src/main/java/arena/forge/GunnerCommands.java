package arena.forge;

import arena.forge.player.ArenaPlayerSession;
import arena.forge.net.ArenaNetwork;
import arena.forge.spawn.ArenaPoint;
import arena.round.CGBetaRegenerator;
import arena.round.CGBetaSnapshot;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import arena.profile.PlayerProfile;
import arena.profile.RoundSession;
import arena.loadout.LoadoutManager;
import arena.ammo.AmmoManager;
import arena.ammo.point.AmmoPoint;
import arena.weapon.WeaponSafetyPolicy;
import arena.hazard.HazardType;
import arena.hazard.HazardPresets;

import java.util.List;

public final class GunnerCommands {
    private GunnerCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher, ArenaRuntime runtime) {
        dispatcher.register(Commands.literal("ga").requires(src -> runtime.auth().commandSourceAllowed(src))
            .then(Commands.literal("menu").executes(ctx -> openUi(ctx.getSource(), ArenaNetwork.UiTarget.MAIN)))
            .then(Commands.literal("debug")
                .then(Commands.literal("round").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> debugRound(ctx.getSource(), runtime)))
                .then(Commands.literal("generator").executes(ctx -> debugGenerator(ctx.getSource(), runtime)))
                .then(Commands.literal("player").executes(ctx -> debugSelf(ctx.getSource(), runtime)))
                .then(Commands.literal("damage").executes(ctx -> debugDamage(ctx.getSource(), runtime)))
                .then(Commands.literal("ammo").executes(ctx -> debugAmmo(ctx.getSource(), runtime)))
                .then(Commands.literal("entities").executes(ctx -> debugEntities(ctx.getSource(), runtime)))
                .then(Commands.literal("quarantine").executes(ctx -> debugQuarantine(ctx.getSource())))
                .then(Commands.literal("hazards").executes(ctx -> debugHazards(ctx.getSource(), runtime)))
                .then(Commands.literal("doctor").executes(ctx -> doctor(ctx.getSource(), runtime)))
                .then(Commands.literal("stage1").executes(ctx -> stage1Evidence(ctx.getSource(), runtime))))
            .then(Commands.literal("generator").requires(src -> src.hasPermission(2))
                .then(Commands.literal("start").executes(ctx -> generatorStart(ctx.getSource(), runtime))))
            .then(Commands.literal("cleanup").requires(src -> src.hasPermission(2))
                .then(Commands.literal("legacy").executes(ctx -> cleanupLegacy(ctx.getSource(), runtime))))
            .then(Commands.literal("spawn").requires(src -> runtime.auth().commandSourceAllowed(src))
                .then(Commands.literal("setlobby").requires(src -> src.hasPermission(2)).executes(ctx -> setLobby(ctx.getSource(), runtime)))
                .then(Commands.literal("add").requires(src -> src.hasPermission(2)).executes(ctx -> addSpawn(ctx.getSource(), runtime)))
                .then(Commands.literal("clear").requires(src -> src.hasPermission(2)).executes(ctx -> clearSpawns(ctx.getSource(), runtime)))
                .then(Commands.literal("list").executes(ctx -> listSpawns(ctx.getSource(), runtime)))
                .then(Commands.literal("remove-nearest").requires(src -> src.hasPermission(2)).executes(ctx -> removeNearest(ctx.getSource(), runtime)))));

        dispatcher.register(Commands.literal("round").requires(src -> runtime.auth().commandSourceAllowed(src))
            .then(Commands.literal("status").executes(ctx -> debugRound(ctx.getSource(), runtime)))
            .then(Commands.literal("start").requires(src -> src.hasPermission(2)).executes(ctx -> {
                runtime.forceStartRound();
                ok(ctx.getSource(), "Round started");
                return 1;
            }))
            .then(Commands.literal("restart").requires(src -> src.hasPermission(2)).executes(ctx -> generatorStart(ctx.getSource(), runtime)))
            .then(Commands.literal("time").requires(src -> src.hasPermission(2))
                .then(Commands.argument("seconds", IntegerArgumentType.integer(1, 3600)).executes(ctx -> {
                    int seconds = IntegerArgumentType.getInteger(ctx, "seconds");
                    runtime.rounds().setRoundSeconds(seconds);
                    ok(ctx.getSource(), "Round time set to " + seconds + "s");
                    return 1;
                }))));

        dispatcher.register(Commands.literal("setspawn").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> setLobby(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("addspawn").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> addSpawn(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("clearspawns").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> clearSpawns(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("listspawns").requires(src -> runtime.auth().commandSourceAllowed(src))
            .executes(ctx -> listSpawns(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("removespawn").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .then(Commands.literal("nearest").executes(ctx -> removeNearest(ctx.getSource(), runtime))));

        dispatcher.register(Commands.literal("setspawnpatron1").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> addAmmoPoint(ctx.getSource(), runtime, AmmoManager.PointType.PRIMARY)));
        dispatcher.register(Commands.literal("setspawnpatron2").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> addAmmoPoint(ctx.getSource(), runtime, AmmoManager.PointType.SECONDARY)));
        dispatcher.register(Commands.literal("clearspawnpatron1").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> clearAmmoPoints(ctx.getSource(), runtime, AmmoManager.PointType.PRIMARY)));
        dispatcher.register(Commands.literal("clearspawnpatron2").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> clearAmmoPoints(ctx.getSource(), runtime, AmmoManager.PointType.SECONDARY)));
        dispatcher.register(Commands.literal("listspawnpatron1").requires(src -> runtime.auth().commandSourceAllowed(src))
            .executes(ctx -> listAmmoPoints(ctx.getSource(), runtime, AmmoManager.PointType.PRIMARY)));
        dispatcher.register(Commands.literal("listspawnpatron2").requires(src -> runtime.auth().commandSourceAllowed(src))
            .executes(ctx -> listAmmoPoints(ctx.getSource(), runtime, AmmoManager.PointType.SECONDARY)));
        dispatcher.register(Commands.literal("removespawnpatron1").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .then(Commands.literal("nearest").executes(ctx -> removeAmmoPoint(ctx.getSource(), runtime, AmmoManager.PointType.PRIMARY))));
        dispatcher.register(Commands.literal("removespawnpatron2").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .then(Commands.literal("nearest").executes(ctx -> removeAmmoPoint(ctx.getSource(), runtime, AmmoManager.PointType.SECONDARY))));
        dispatcher.register(Commands.literal("showspawnpatrons").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .executes(ctx -> showAmmoPoints(ctx.getSource(), runtime)));

        dispatcher.register(Commands.literal("reload").requires(src -> runtime.auth().commandSourceAllowed(src))
            .executes(ctx -> customReload(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("firemode").requires(src -> runtime.auth().commandSourceAllowed(src))
            .executes(ctx -> customFireMode(ctx.getSource(), runtime)));

        dispatcher.register(Commands.literal("spawnregion").requires(src -> src.hasPermission(2))
            .then(Commands.literal("pos1").executes(ctx -> safePos(ctx.getSource(), runtime, true)))
            .then(Commands.literal("pos2").executes(ctx -> safePos(ctx.getSource(), runtime, false)))
            .then(Commands.literal("create")
                .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> safeCreate(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "id")))))
            .then(Commands.literal("remove")
                .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> safeRemove(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "id")))))
            .then(Commands.literal("show")
                .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> safeShow(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "id")))))
            .then(Commands.literal("list").executes(ctx -> safeList(ctx.getSource(), runtime))));

        dispatcher.register(Commands.literal("hazard")
            .requires(src -> runtime.auth().commandSourceAllowed(src) && src.hasPermission(2))
            .then(Commands.literal("meteor").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.METEOR)))
            .then(Commands.literal("tnt").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.TNT_DROP)))
            .then(Commands.literal("web").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.WEB_BOMB)))
            .then(Commands.literal("shockwave").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.SHOCKWAVE)))
            .then(Commands.literal("smoke").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.SMOKE)))
            .then(Commands.literal("cryo").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.CRYO)))
            .then(Commands.literal("gravity").executes(ctx -> queueHazard(ctx.getSource(), runtime, HazardType.GRAVITY_PULSE)))
            .then(Commands.literal("status").executes(ctx -> debugHazards(ctx.getSource(), runtime)))
            .then(Commands.literal("clear").executes(ctx -> clearHazards(ctx.getSource(), runtime))));

        // Bot clients authenticate before SAuth using a short-lived server-issued secret bound to their reserved name.
        dispatcher.register(Commands.literal("botauth")
            .then(Commands.argument("token", StringArgumentType.word()).executes(ctx -> botAuth(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "token")))));

        dispatcher.register(Commands.literal("bots").requires(src -> src.hasPermission(2))
            .then(Commands.literal("status").executes(ctx -> botsStatus(ctx.getSource(), runtime)))
            .then(Commands.literal("list").executes(ctx -> botsList(ctx.getSource(), runtime)))
            .then(Commands.literal("rotate").executes(ctx -> botsRotate(ctx.getSource(), runtime)))
            .then(Commands.literal("autofill")
                .then(Commands.literal("on").executes(ctx -> botsAutofill(ctx.getSource(), runtime, true)))
                .then(Commands.literal("off").executes(ctx -> botsAutofill(ctx.getSource(), runtime, false))))
            .then(Commands.literal("target")
                .then(Commands.argument("count", IntegerArgumentType.integer(0, 8)).executes(ctx -> botsTarget(ctx.getSource(), runtime, IntegerArgumentType.getInteger(ctx, "count"))))));

        dispatcher.register(Commands.literal("menu").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> openUi(ctx.getSource(), ArenaNetwork.UiTarget.MAIN)));
        dispatcher.register(Commands.literal("shop").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> openUi(ctx.getSource(), ArenaNetwork.UiTarget.SHOP)));
        dispatcher.register(Commands.literal("profile").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> openUi(ctx.getSource(), ArenaNetwork.UiTarget.PROFILE)));
        dispatcher.register(Commands.literal("play").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> play(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("spawn").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> lobby(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("balance").requires(src -> runtime.auth().commandSourceAllowed(src)).executes(ctx -> balance(ctx.getSource(), runtime)));
        dispatcher.register(Commands.literal("buy").requires(src -> runtime.auth().commandSourceAllowed(src))
            .then(Commands.argument("weapon", StringArgumentType.greedyString()).executes(ctx -> buy(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "weapon")))));



        dispatcher.register(Commands.literal("skills").requires(src -> runtime.auth().commandSourceAllowed(src))
            .then(Commands.literal("list").executes(ctx -> skillsList(ctx.getSource(), runtime)))
            .then(Commands.literal("unlock")
                .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> skillUnlockSelf(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "id")))))
            .then(Commands.literal("reset").requires(src -> src.hasPermission(2)).executes(ctx -> skillResetSelf(ctx.getSource(), runtime))));

        dispatcher.register(Commands.literal("specialization").requires(src -> runtime.auth().commandSourceAllowed(src))
            .then(Commands.literal("choose")
                .then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> specializationChoose(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "id"))))));

        dispatcher.register(Commands.literal("xp").requires(src -> src.hasPermission(2))
            .then(Commands.literal("give")
                .then(Commands.argument("player", StringArgumentType.word())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(1, 10_000_000)).executes(ctx -> xpGive(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "player"), IntegerArgumentType.getInteger(ctx, "amount")))))));

        dispatcher.register(Commands.literal("skillpoints").requires(src -> src.hasPermission(2))
            .then(Commands.literal("give")
                .then(Commands.argument("player", StringArgumentType.word())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(1, 100_000)).executes(ctx -> skillPointsGive(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "player"), IntegerArgumentType.getInteger(ctx, "amount")))))));

        dispatcher.register(Commands.literal("credits").requires(src -> runtime.auth().commandSourceAllowed(src)).requires(src -> src.hasPermission(2))
            .then(Commands.literal("get")
                .then(Commands.argument("player", StringArgumentType.word()).executes(ctx -> creditsGet(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "player")))))
            .then(Commands.literal("give")
                .then(Commands.argument("player", StringArgumentType.word())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0, 1_000_000)).executes(ctx -> creditsGive(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "player"), IntegerArgumentType.getInteger(ctx, "amount"))))))
            .then(Commands.literal("set")
                .then(Commands.argument("player", StringArgumentType.word())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0, 1_000_000)).executes(ctx -> creditsSet(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "player"), IntegerArgumentType.getInteger(ctx, "amount"))))))
            .then(Commands.literal("take")
                .then(Commands.argument("player", StringArgumentType.word())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(0, 1_000_000)).executes(ctx -> creditsTake(ctx.getSource(), runtime, StringArgumentType.getString(ctx, "player"), IntegerArgumentType.getInteger(ctx, "amount")))))));
    }

    private static int openUi(CommandSourceStack source, ArenaNetwork.UiTarget target) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        ArenaNetwork.openUi(player, target);
        return 1;
    }

    private static int setLobby(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        runtime.spawns().setLobby(player);
        ok(source, "Lobby spawn saved");
        return 1;
    }

    private static int addSpawn(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        int count = runtime.spawns().addCombatSpawn(player);
        ok(source, "Combat spawn added. Total=" + count);
        return 1;
    }

    private static int clearSpawns(CommandSourceStack source, ArenaRuntime runtime) {
        runtime.spawns().clearCombatSpawns();
        ok(source, "All combat spawns cleared");
        return 1;
    }

    private static int listSpawns(CommandSourceStack source, ArenaRuntime runtime) {
        List<ArenaPoint> points = runtime.spawns().combatSpawns();
        source.sendSuccess(() -> Component.literal("[GA] combat spawns=" + points.size()), false);
        int i = 1;
        for (ArenaPoint p : points) {
            final int index = i++;
            source.sendSuccess(() -> Component.literal("  #" + index + " " + p.dimension().location()
                + " " + fmt(p.x()) + " " + fmt(p.y()) + " " + fmt(p.z())), false);
        }
        return points.size();
    }

    private static int removeNearest(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        boolean removed = runtime.spawns().removeNearest(player, 10.0).isPresent();
        if (removed) ok(source, "Nearest combat spawn removed");
        else source.sendFailure(Component.literal("[GA] Нет spawn-точки ближе 10 блоков"));
        return removed ? 1 : 0;
    }

    private static int addAmmoPoint(CommandSourceStack source, ArenaRuntime runtime, AmmoManager.PointType type) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        AmmoPoint point = runtime.ammoPoints().add(player, type);
        ok(source, (type == AmmoManager.PointType.PRIMARY ? "Patron1" : "Patron2")
            + " added at " + fmt(point.x()) + " " + fmt(point.y()) + " " + fmt(point.z())
            + ". Total=" + runtime.ammoPoints().points(type).size());
        return 1;
    }

    private static int clearAmmoPoints(CommandSourceStack source, ArenaRuntime runtime, AmmoManager.PointType type) {
        int removed = runtime.ammoPoints().clear(type);
        ok(source, "Removed " + removed + " " + (type == AmmoManager.PointType.PRIMARY ? "Patron1" : "Patron2") + " points");
        return removed;
    }

    private static int listAmmoPoints(CommandSourceStack source, ArenaRuntime runtime, AmmoManager.PointType type) {
        List<AmmoPoint> points = runtime.ammoPoints().points(type);
        source.sendSuccess(() -> Component.literal("[GA] " + (type == AmmoManager.PointType.PRIMARY ? "Patron1" : "Patron2")
            + " points=" + points.size()), false);
        for (int i = 0; i < points.size(); i++) {
            AmmoPoint p = points.get(i);
            final int index = i + 1;
            long cooldown = runtime.ammoPoints().cooldownRemaining(p, runtime.serverTick());
            source.sendSuccess(() -> Component.literal("  #" + index + " " + p.dimension() + " "
                + fmt(p.x()) + " " + fmt(p.y()) + " " + fmt(p.z())
                + (cooldown > 0 ? " cooldown=" + String.format(java.util.Locale.ROOT, "%.1fs", cooldown / 20.0) : " READY")), false);
        }
        return points.size();
    }

    private static int removeAmmoPoint(CommandSourceStack source, ArenaRuntime runtime, AmmoManager.PointType type) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        AmmoPoint removed = runtime.ammoPoints().removeNearest(player, type);
        if (removed == null) {
            source.sendFailure(Component.literal("[GA] Нет подходящей ammo-точки ближе 8 блоков"));
            return 0;
        }
        ok(source, "Nearest " + (type == AmmoManager.PointType.PRIMARY ? "Patron1" : "Patron2") + " removed");
        return 1;
    }

    private static int showAmmoPoints(CommandSourceStack source, ArenaRuntime runtime) {
        runtime.ammoPoints().showFor(runtime.serverTick(), 30);
        ok(source, "Ammo points highlighted for 30 seconds. Total=" + runtime.ammoPoints().all().size());
        return 1;
    }

    private static int play(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        runtime.players().requestPlay(source.getServer(), player, runtime.rounds().state(), runtime.rounds().roundNumber(), runtime.serverTick());
        return 1;
    }

    private static int lobby(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        if (!runtime.players().sendLobby(source.getServer(), player)) {
            source.sendFailure(Component.literal("[GA] Lobby spawn не установлен. Админ: /setspawn"));
            return 0;
        }
        return 1;
    }

    private static int generatorStart(CommandSourceStack source, ArenaRuntime runtime) {
        runtime.beginRegeneration(source.getServer().overworld());
        ok(source, "CG BETA regeneration requested");
        return 1;
    }

    private static int debugRound(CommandSourceStack source, ArenaRuntime runtime) {
        source.sendSuccess(() -> Component.literal("[GA] state=" + runtime.rounds().state()
            + " round=" + runtime.rounds().roundNumber()
            + " remainingTicks=" + runtime.rounds().remainingTicks()), false);
        return 1;
    }

    private static int debugSelf(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        ArenaPlayerSession session = runtime.players().session(player);
        long protection = Math.max(0L, session.protectionUntilTick() - runtime.serverTick());
        source.sendSuccess(() -> Component.literal("[GA] playerState=" + session.state()
            + " protectionTicks=" + protection), false);
        return 1;
    }

    private static int debugGenerator(CommandSourceStack source, ArenaRuntime runtime) {
        CGBetaSnapshot s = runtime.currentSnapshot();
        CGBetaRegenerator.State gs = runtime.rounds().generator().state();
        int progress = CGBetaRegenerator.normalizedProgress(s);
        source.sendSuccess(() -> Component.literal("[GA] generator=" + gs + " progress=" + progress + "%"
            + " chunks=" + s.cgChunkCount() + "/64"
            + " unfinished=" + s.unfinishedChunks()
            + " empty=" + s.emptyCount() + "/" + s.emptyMax()
            + " gun=" + s.gunCount() + "/" + s.gunMax()
            + " health=" + s.healthCount() + "/" + s.healthMax()), false);
        return 1;
    }



    private static int doctor(CommandSourceStack source, ArenaRuntime runtime) {
        var server = source.getServer();
        var level = server.overworld();
        int problems = 0;

        boolean dataObjective = server.getScoreboard().getObjective("data") != null;
        boolean jegAssault = net.minecraftforge.registries.ForgeRegistries.ITEMS.containsKey(new net.minecraft.resources.ResourceLocation("jeg", "assault_rifle"));
        boolean jegPistolAmmo = net.minecraftforge.registries.ForgeRegistries.ITEMS.containsKey(new net.minecraft.resources.ResourceLocation("jeg", "pistol_ammo"));
        int spawnCount = runtime.spawns().combatSpawns().size();
        boolean lobbySet = runtime.spawns().lobby().isPresent();
        int p1 = runtime.ammoPoints().points(AmmoManager.PointType.PRIMARY).size();
        int p2 = runtime.ammoPoints().points(AmmoManager.PointType.SECONDARY).size();
        var triggerBlock = level.getBlockState(CGBetaForgeAdapter.GENERATOR_TRIGGER).getBlock();

        source.sendSuccess(() -> Component.literal("[GA DOCTOR] Java=" + System.getProperty("java.version")
            + " | round=" + runtime.rounds().state()), false);
        source.sendSuccess(() -> Component.literal("[GA DOCTOR] JEG assault_rifle=" + jegAssault
            + " pistol_ammo=" + jegPistolAmmo), false);
        source.sendSuccess(() -> Component.literal("[GA DOCTOR] scoreboard:data=" + dataObjective
            + " | triggerBlock=" + net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(triggerBlock)), false);
        source.sendSuccess(() -> Component.literal("[GA DOCTOR] lobby=" + lobbySet + " | combatSpawns=" + spawnCount
            + " | patron1=" + p1 + " | patron2=" + p2), false);

        if (!jegAssault || !jegPistolAmmo) problems++;
        if (!dataObjective) problems++;
        if (!lobbySet) problems++;
        if (spawnCount == 0) problems++;

        final int result = problems;
        if (result == 0) {
            source.sendSuccess(() -> Component.literal("[GA DOCTOR] OK: базовые зависимости и настройки найдены."), false);
            return 1;
        }
        source.sendFailure(Component.literal("[GA DOCTOR] Найдено проблем: " + result + ". Исправь строки false/0 выше перед live-тестом."));
        return 0;
    }

    /**
     * Stage-1 runtime evidence command. This intentionally does not mutate the world.
     * It prints the exact checks needed before Forge build/runtime can be called complete.
     */
    private static int stage1Evidence(CommandSourceStack source, ArenaRuntime runtime) {
        var server = source.getServer();
        String javaVersion = System.getProperty("java.version", "unknown");
        boolean java17 = javaVersion.startsWith("17.") || javaVersion.equals("17");
        boolean lobbySet = runtime.spawns().lobby().isPresent();
        int combatSpawns = runtime.spawns().combatSpawns().size();
        int safeRegions = runtime.safeRegions().registry().all().size();
        boolean jegPresent = net.minecraftforge.registries.ForgeRegistries.ITEMS.containsKey(
            new net.minecraft.resources.ResourceLocation("jeg", "assault_rifle"));
        boolean flareQuarantined = WeaponSafetyPolicy.isQuarantined("jeg:flare_gun");
        boolean dataObjective = server.getScoreboard().getObjective("data") != null;
        int problems = 0;
        if (!java17) problems++;
        if (!lobbySet) problems++;
        if (combatSpawns == 0) problems++;
        if (safeRegions == 0) problems++;
        if (!jegPresent) problems++;
        if (!flareQuarantined) problems++;
        if (!dataObjective) problems++;

        source.sendSuccess(() -> Component.literal("[GA STAGE1] Java17=" + java17 + " (" + javaVersion + ")"), false);
        source.sendSuccess(() -> Component.literal("[GA STAGE1] lobby=" + lobbySet + " combatSpawns=" + combatSpawns
            + " safeRegions=" + safeRegions), false);
        source.sendSuccess(() -> Component.literal("[GA STAGE1] JEG=" + jegPresent + " flareQuarantine=" + flareQuarantined
            + " scoreboard:data=" + dataObjective), false);
        source.sendSuccess(() -> Component.literal("[GA STAGE1] round=" + runtime.rounds().state()
            + " hazards=" + runtime.hazards().size() + " loadedPlayers=" + server.getPlayerCount()), false);

        final int result = problems;
        if (result == 0) {
            source.sendSuccess(() -> Component.literal("[GA STAGE1] STATIC_RUNTIME_READY — теперь нужны live-действия: login -> safe zone -> JEG fence -> /play -> regen."), false);
            return 1;
        }
        source.sendFailure(Component.literal("[GA STAGE1] BLOCKED: проблем=" + result + ". Смотри false/0 выше."));
        return 0;
    }

    private static int debugAmmo(CommandSourceStack source, ArenaRuntime runtime) {
        int p1 = runtime.ammoPoints().points(AmmoManager.PointType.PRIMARY).size();
        int p2 = runtime.ammoPoints().points(AmmoManager.PointType.SECONDARY).size();
        int a1 = runtime.ammoPoints().activeCount(AmmoManager.PointType.PRIMARY, runtime.serverTick());
        int a2 = runtime.ammoPoints().activeCount(AmmoManager.PointType.SECONDARY, runtime.serverTick());
        source.sendSuccess(() -> Component.literal("[GA] ammo primary=" + a1 + "/" + p1
            + " secondary=" + a2 + "/" + p2
            + " cooldowns=20s/15s"), false);
        return 1;
    }

    private static int debugDamage(CommandSourceStack source, ArenaRuntime runtime) {
        source.sendSuccess(() -> Component.literal("[GA] trackedDamageVictims=" + runtime.damageTracker().trackedVictims()), false);
        return 1;
    }

    private static int debugQuarantine(CommandSourceStack source) {
        var quarantined = WeaponSafetyPolicy.all();
        if (quarantined.isEmpty()) {
            source.sendSuccess(() -> Component.literal("[GA] weapon quarantine: empty"), false);
            return 1;
        }
        source.sendSuccess(() -> Component.literal("[GA] weapon quarantine (" + quarantined.size() + ")"), false);
        quarantined.forEach((id, reason) ->
            source.sendSuccess(() -> Component.literal(" - " + id + " :: " + reason), false));
        return quarantined.size();
    }

    private static int debugEntities(CommandSourceStack source, ArenaRuntime runtime) {
        int total = 0;
        for (var level : source.getServer().getAllLevels()) {
            for (var entity : level.getAllEntities()) total++;
        }
        final int count = total;
        source.sendSuccess(() -> Component.literal("[GA] loadedEntities=" + count
            + " ammoPoints=" + runtime.ammoPoints().all().size()), false);
        return 1;
    }

    private static int cleanupLegacy(CommandSourceStack source, ArenaRuntime runtime) {
        int removed = runtime.legacyCleanup().cleanupAll(source.getServer());
        ok(source, "Legacy GunnerArena entities removed=" + removed);
        return removed;
    }

    private static int buy(CommandSourceStack source, ArenaRuntime runtime, String weaponId) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        if (runtime.rounds().state() != arena.round.RoundState.PLAYING) {
            source.sendFailure(Component.literal("[GA] Покупать оружие можно только во время раунда"));
            return 0;
        }
        String normalizedWeaponId = weaponId.trim();
        if (WeaponSafetyPolicy.isQuarantined(normalizedWeaponId)) {
            source.sendFailure(Component.literal("[GA] Это оружие временно отключено из-за расследования краша: " + normalizedWeaponId));
            return 0;
        }
        RoundSession round = runtime.players().roundSession(player);
        LoadoutManager.BuyResult result = runtime.forgeLoadouts().buyAndGive(player, round, normalizedWeaponId);
        switch (result) {
            case OK -> { ok(source, "Куплено: " + weaponId + " | Credits=$" + round.credits()); return 1; }
            case NOT_ENOUGH_CREDITS -> source.sendFailure(Component.literal("[GA] Недостаточно Credits"));
            case UNAVAILABLE_ITEM -> source.sendFailure(Component.literal("[GA] Предмет пока не зарегистрирован на сервере: " + weaponId));
            default -> source.sendFailure(Component.literal("[GA] Неизвестное оружие: " + weaponId));
        }
        return 0;
    }

    private static int balance(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        RoundSession round = runtime.players().roundSession(player);
        PlayerProfile profile = runtime.players().profile(player);
        long coins = profile == null ? 0 : profile.coins;
        long crystals = profile == null ? 0 : profile.crystals;
        int level = profile == null ? 1 : profile.level;
        source.sendSuccess(() -> Component.literal("[GA] Credits=$" + round.credits()
            + " | Coins=" + coins + " | Crystals=" + crystals + " | Lv." + level), false);
        return 1;
    }

    private static ServerPlayer onlinePlayer(CommandSourceStack source, String name) {
        ServerPlayer player = source.getServer().getPlayerList().getPlayerByName(name);
        if (player == null) source.sendFailure(Component.literal("[GA] Игрок не найден онлайн: " + name));
        return player;
    }

    private static int creditsGet(CommandSourceStack source, ArenaRuntime runtime, String name) {
        ServerPlayer player = onlinePlayer(source, name);
        if (player == null) return 0;
        int value = runtime.players().roundSession(player).credits();
        ok(source, name + " Credits=$" + value);
        return value;
    }

    private static int creditsGive(CommandSourceStack source, ArenaRuntime runtime, String name, int amount) {
        ServerPlayer player = onlinePlayer(source, name);
        if (player == null) return 0;
        RoundSession round = runtime.players().roundSession(player);
        round.addCredits(amount);
        ok(source, "Added $" + amount + " to " + name + ". Balance=$" + round.credits());
        return 1;
    }

    private static int creditsSet(CommandSourceStack source, ArenaRuntime runtime, String name, int amount) {
        ServerPlayer player = onlinePlayer(source, name);
        if (player == null) return 0;
        RoundSession round = runtime.players().roundSession(player);
        round.setCredits(amount);
        ok(source, "Set " + name + " Credits=$" + round.credits());
        return 1;
    }

    private static int creditsTake(CommandSourceStack source, ArenaRuntime runtime, String name, int amount) {
        ServerPlayer player = onlinePlayer(source, name);
        if (player == null) return 0;
        RoundSession round = runtime.players().roundSession(player);
        round.setCredits(Math.max(0, round.credits() - amount));
        ok(source, "Removed up to $" + amount + " from " + name + ". Balance=$" + round.credits());
        return 1;
    }

    private static int queueHazard(CommandSourceStack source, ArenaRuntime runtime, HazardType type) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        var look = player.getLookAngle();
        double x = player.getX() + look.x * 8.0;
        double y = player.getY() + 1.0 + look.y * 8.0;
        double z = player.getZ() + look.z * 8.0;
        String dimension = player.level().dimension().location().toString();
        try {
            var h = runtime.hazards().spawn(dimension, HazardPresets.at(type, x, y, z), runtime.serverTick());
            ok(source, "Hazard " + type + " queued @ " + fmt(x) + " " + fmt(y) + " " + fmt(z) + " id=" + h.id());
            return 1;
        } catch (IllegalStateException ex) {
            source.sendFailure(Component.literal("[GA] " + ex.getMessage()));
            return 0;
        }
    }

    private static int clearHazards(CommandSourceStack source, ArenaRuntime runtime) {
        int count = runtime.hazards().size();
        runtime.hazards().clear();
        ok(source, "Temporary hazards cleared: " + count);
        return count;
    }

    private static ServerPlayer requirePlayer(CommandSourceStack source) {
        try { return source.getPlayerOrException(); }
        catch (Exception ex) {
            source.sendFailure(Component.literal("[GA] Эта команда выполняется игроком"));
            return null;
        }
    }

    private static String fmt(double value) { return String.format(java.util.Locale.ROOT, "%.1f", value); }

    private static int safePos(CommandSourceStack source, ArenaRuntime runtime, boolean first) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        if (first) runtime.safeRegions().setPos1(player); else runtime.safeRegions().setPos2(player);
        ok(source, "Safe region " + (first ? "pos1" : "pos2") + " = " + fmt(player.getX()) + " " + fmt(player.getY()) + " " + fmt(player.getZ()));
        return 1;
    }

    private static int safeCreate(CommandSourceStack source, ArenaRuntime runtime, String id) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        try {
            var r = runtime.safeRegions().create(player, id);
            ok(source, "Safe region '" + r.id() + "' saved: " + r.dimension());
            return 1;
        } catch (IllegalStateException e) {
            source.sendFailure(Component.literal("[GA] " + e.getMessage()));
            return 0;
        }
    }

    private static int safeRemove(CommandSourceStack source, ArenaRuntime runtime, String id) {
        boolean removed = runtime.safeRegions().remove(id);
        if (removed) ok(source, "Safe region '" + id + "' removed");
        else source.sendFailure(Component.literal("[GA] Safe region not found: " + id));
        return removed ? 1 : 0;
    }

    private static int safeList(CommandSourceStack source, ArenaRuntime runtime) {
        var regions = runtime.safeRegions().registry().all();
        source.sendSuccess(() -> Component.literal("[GA] safe regions=" + regions.size()), false);
        for (var r : regions) {
            source.sendSuccess(() -> Component.literal("  " + r.id() + " " + r.dimension()
                + " [" + fmt(r.minX()) + "," + fmt(r.minY()) + "," + fmt(r.minZ()) + "] -> ["
                + fmt(r.maxX()) + "," + fmt(r.maxY()) + "," + fmt(r.maxZ()) + "]"), false);
        }
        return regions.size();
    }

    private static int safeShow(CommandSourceStack source, ArenaRuntime runtime, String id) {
        if (!runtime.safeRegions().show(id, runtime.serverTick(), 20)) {
            source.sendFailure(Component.literal("[GA] Safe region not found: " + id));
            return 0;
        }
        ok(source, "Safe region '" + id + "' highlighted for 20 seconds");
        return 1;
    }

    private static int debugHazards(CommandSourceStack source, ArenaRuntime runtime) {
        var active = runtime.hazards().all();
        source.sendSuccess(() -> Component.literal("[GA] active hazards=" + active.size()
            + " | visualizedSafeRegions=" + runtime.safeRegions().visualizedCount(runtime.serverTick())), false);
        for (var h : active) {
            long age = Math.max(0L, runtime.serverTick() - h.createdTick());
            source.sendSuccess(() -> Component.literal("  " + h.spec().type() + " id=" + h.id()
                + " age=" + String.format(java.util.Locale.ROOT, "%.1fs", age / 20.0)
                + " @ " + fmt(h.spec().x()) + " " + fmt(h.spec().y()) + " " + fmt(h.spec().z())), false);
        }
        return active.size();
    }

    private static int customReload(CommandSourceStack source, ArenaRuntime runtime) {
        try {
            ServerPlayer player = source.getPlayerOrException();
            if (!runtime.isCustomCombatAllowed(player)) {
                source.sendFailure(Component.literal("[GA] Перезарядка доступна только живому игроку в активном раунде."));
                return 0;
            }
            var result = runtime.customWeaponCombat().requestReload(player, runtime.serverTick() * 50L);
            if (result.success()) ok(source, result.message());
            else source.sendFailure(Component.literal("[GA] " + result.message()));
            return result.success() ? 1 : 0;
        } catch (Exception ex) {
            source.sendFailure(Component.literal("[GA] Команда доступна только игроку."));
            return 0;
        }
    }

    private static int customFireMode(CommandSourceStack source, ArenaRuntime runtime) {
        try {
            ServerPlayer player = source.getPlayerOrException();
            if (!runtime.isCustomCombatAllowed(player)) {
                source.sendFailure(Component.literal("[GA] Смена режима доступна только живому игроку в активном раунде."));
                return 0;
            }
            var result = runtime.customWeaponCombat().cycleMode(player);
            if (result.success()) ok(source, result.message());
            else source.sendFailure(Component.literal("[GA] " + result.message()));
            return result.success() ? 1 : 0;
        } catch (Exception ex) {
            source.sendFailure(Component.literal("[GA] Команда доступна только игроку."));
            return 0;
        }
    }

    private static int botAuth(CommandSourceStack source, ArenaRuntime runtime, String token) {
        try {
            ServerPlayer player = source.getPlayerOrException();
            String name = player.getGameProfile().getName();
            if (!runtime.bots().authenticate(name, token)) {
                source.sendFailure(Component.literal("[GA] Неверный или устаревший bot token."));
                return 0;
            }
            player.addTag("gunnerarena_bot");
            player.addTag(AuthGate.AUTH_TAG);
            ok(source, "AI Gunner authenticated as PLAYER: " + name);
            return 1;
        } catch (Exception ex) {
            source.sendFailure(Component.literal("[GA] /botauth доступен только подключённому bot-клиенту."));
            return 0;
        }
    }

    private static int botsStatus(CommandSourceStack source, ArenaRuntime runtime) {
        int real = 0;
        var server = source.getServer();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) if (!p.getTags().contains("gunnerarena_bot")) real++;
        int desired = runtime.bots().desired(real);
        int reserved = runtime.bots().slots().size();
        long connected = runtime.bots().slots().stream().filter(arena.bot.BotSlot::connected).count();
        source.sendSuccess(() -> Component.literal("[GA] bots autofill=" + runtime.bots().autofill()
            + " real=" + real + " desired=" + desired + " reserved=" + reserved + " connected=" + connected), false);
        return reserved;
    }

    private static int botsList(CommandSourceStack source, ArenaRuntime runtime) {
        var slots = runtime.bots().slots();
        source.sendSuccess(() -> Component.literal("[GA] bot slots=" + slots.size()), false);
        for (var s : slots) {
            long left = Math.max(0L, s.rotateAtTick() - runtime.serverTick());
            source.sendSuccess(() -> Component.literal("  " + s.name() + " | " + s.profile()
                + " | " + (s.connected() ? "ONLINE" : "WAITING") + " | rotate~" + (left / 20L) + "s"
                + " | token=" + s.launchToken()), false);
        }
        return slots.size();
    }

    private static int botsRotate(CommandSourceStack source, ArenaRuntime runtime) {
        boolean ok = runtime.bots().rotateOne(runtime.serverTick());
        if (ok) ok(source, "One bot slot rotated");
        else source.sendFailure(Component.literal("[GA] No bot slots to rotate."));
        return ok ? 1 : 0;
    }

    private static int botsAutofill(CommandSourceStack source, ArenaRuntime runtime, boolean enabled) {
        runtime.bots().autofill(enabled);
        ok(source, "Bot autofill " + (enabled ? "enabled" : "disabled"));
        return 1;
    }

    private static int botsTarget(CommandSourceStack source, ArenaRuntime runtime, int count) {
        runtime.bots().targetOverride(count);
        ok(source, "Bot target override=" + count + " (0..8)");
        return 1;
    }


    private static int skillsList(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        PlayerProfile profile = runtime.players().profile(player);
        if (profile == null) return 0;
        source.sendSuccess(() -> Component.literal("[GA] Skill Tree • Lv." + profile.level + " • points=" + profile.skillPoints + " • spec=" + profile.specialization), false);
        for (var branch : arena.rpg.SkillBranch.values()) {
            source.sendSuccess(() -> Component.literal("  " + branch + ":"), false);
            for (var skill : runtime.rpg().catalog().branch(branch)) {
                boolean unlocked = profile.unlockedSkills.contains(skill.id());
                String state = unlocked ? "✓" : "·";
                source.sendSuccess(() -> Component.literal("    " + state + " " + skill.id() + " | " + skill.name()
                    + " | cost=" + skill.cost() + " | lvl=" + skill.minLevel()
                    + (skill.prerequisites().isEmpty() ? "" : " | req=" + String.join("+", skill.prerequisites()))), false);
            }
        }
        return profile.unlockedSkills.size();
    }

    private static int skillUnlockSelf(CommandSourceStack source, ArenaRuntime runtime, String id) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        PlayerProfile profile = runtime.players().profile(player);
        if (profile == null) return 0;
        var result = runtime.rpg().unlock(profile, id);
        if (!result.ok()) {
            source.sendFailure(Component.literal("[GA] Skill unlock: " + result.code()));
            return 0;
        }
        runtime.profiles().markDirty(player.getUUID());
        ok(source, "Навык открыт: " + result.skill().name() + " • осталось " + profile.skillPoints + " очков");
        ArenaNetwork.sendSnapshot(player);
        return 1;
    }

    private static int skillResetSelf(CommandSourceStack source, ArenaRuntime runtime) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        PlayerProfile profile = runtime.players().profile(player);
        if (profile == null) return 0;
        int refunded = runtime.rpg().resetSkills(profile);
        runtime.profiles().markDirty(player.getUUID());
        ok(source, "Skill Tree сброшено. Возвращено " + refunded + " очков.");
        ArenaNetwork.sendSnapshot(player);
        return 1;
    }

    private static int specializationChoose(CommandSourceStack source, ArenaRuntime runtime, String id) {
        ServerPlayer player = requirePlayer(source);
        if (player == null) return 0;
        PlayerProfile profile = runtime.players().profile(player);
        if (profile == null) return 0;
        var code = runtime.rpg().chooseSpecialization(profile, id);
        if (code != arena.rpg.RpgService.SpecCode.OK) {
            source.sendFailure(Component.literal("[GA] Specialization: " + code));
            return 0;
        }
        runtime.profiles().markDirty(player.getUUID());
        ok(source, "Специализация выбрана: " + profile.specialization);
        ArenaNetwork.sendSnapshot(player);
        return 1;
    }

    private static int xpGive(CommandSourceStack source, ArenaRuntime runtime, String name, int amount) {
        ServerPlayer player = onlinePlayer(source, name);
        if (player == null) return 0;
        PlayerProfile profile = runtime.players().profile(player);
        if (profile == null) return 0;
        var result = runtime.rpg().grantXp(profile, amount);
        runtime.profiles().markDirty(player.getUUID());
        ok(source, "XP +" + amount + " → " + name + " Lv." + result.newLevel() + " (skill points +" + result.awardedSkillPoints() + ")");
        ArenaNetwork.sendSnapshot(player);
        return 1;
    }

    private static int skillPointsGive(CommandSourceStack source, ArenaRuntime runtime, String name, int amount) {
        ServerPlayer player = onlinePlayer(source, name);
        if (player == null) return 0;
        PlayerProfile profile = runtime.players().profile(player);
        if (profile == null) return 0;
        profile.skillPoints = Math.min(Integer.MAX_VALUE, profile.skillPoints + amount);
        runtime.profiles().markDirty(player.getUUID());
        ok(source, "Skill points +" + amount + " → " + name + " (" + profile.skillPoints + ")");
        ArenaNetwork.sendSnapshot(player);
        return 1;
    }

    private static void ok(CommandSourceStack source, String message) {
        source.sendSuccess(() -> Component.literal("[GA] " + message), true);
    }
}

package arena.forge.spawn;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

public record ArenaPoint(ResourceKey<Level> dimension, double x, double y, double z, float yaw, float pitch) {
    public double distanceSquared(double px, double py, double pz) {
        double dx = x - px;
        double dy = y - py;
        double dz = z - pz;
        return dx * dx + dy * dy + dz * dz;
    }
}

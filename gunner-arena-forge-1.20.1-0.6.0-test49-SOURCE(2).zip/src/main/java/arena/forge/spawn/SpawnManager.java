package arena.forge.spawn;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public final class SpawnManager {
    private final ArenaSpawnStore store;
    private final List<ArenaPoint> combatSpawns = new ArrayList<>();
    private ArenaPoint lobby;

    public SpawnManager(ArenaSpawnStore store) {
        this.store = store;
        ArenaSpawnStore.Snapshot snapshot = store.load();
        lobby = snapshot.lobby();
        combatSpawns.addAll(snapshot.spawns());
    }

    public synchronized void setLobby(ServerPlayer player) {
        lobby = fromPlayer(player);
        save();
    }

    public synchronized Optional<ArenaPoint> lobby() { return Optional.ofNullable(lobby); }
    public synchronized List<ArenaPoint> combatSpawns() { return List.copyOf(combatSpawns); }

    public synchronized int addCombatSpawn(ServerPlayer player) {
        combatSpawns.add(fromPlayer(player));
        save();
        return combatSpawns.size();
    }

    public synchronized void clearCombatSpawns() {
        combatSpawns.clear();
        save();
    }

    public synchronized Optional<ArenaPoint> removeNearest(ServerPlayer player, double maxDistance) {
        if (combatSpawns.isEmpty()) return Optional.empty();
        ArenaPoint nearest = combatSpawns.stream()
            .filter(p -> p.dimension().equals(player.level().dimension()))
            .min(Comparator.comparingDouble(p -> p.distanceSquared(player.getX(), player.getY(), player.getZ())))
            .orElse(null);
        if (nearest == null || nearest.distanceSquared(player.getX(), player.getY(), player.getZ()) > maxDistance * maxDistance) {
            return Optional.empty();
        }
        combatSpawns.remove(nearest);
        save();
        return Optional.of(nearest);
    }

    public synchronized Optional<ArenaPoint> selectSafeSpawn(MinecraftServer server, ServerPlayer player) {
        if (combatSpawns.isEmpty()) return Optional.empty();
        List<ServerPlayer> enemies = server.getPlayerList().getPlayers().stream()
            .filter(p -> p != player && p.isAlive())
            .toList();

        ArenaPoint best = null;
        double bestScore = Double.NEGATIVE_INFINITY;
        for (ArenaPoint point : combatSpawns) {
            ServerLevel level = server.getLevel(point.dimension());
            if (level == null) continue;
            double nearestEnemy = enemies.stream()
                .filter(p -> p.level().dimension().equals(point.dimension()))
                .mapToDouble(p -> point.distanceSquared(p.getX(), p.getY(), p.getZ()))
                .min().orElse(1_000_000.0);
            double score = Math.min(nearestEnemy, 1_000_000.0);
            if (score > bestScore) {
                bestScore = score;
                best = point;
            }
        }
        return Optional.ofNullable(best);
    }

    public boolean teleport(MinecraftServer server, ServerPlayer player, ArenaPoint point) {
        ServerLevel level = server.getLevel(point.dimension());
        if (level == null) return false;
        player.teleportTo(level, point.x(), point.y(), point.z(), point.yaw(), point.pitch());
        player.setDeltaMovement(0, 0, 0);
        player.fallDistance = 0;
        return true;
    }

    private static ArenaPoint fromPlayer(ServerPlayer player) {
        return new ArenaPoint(player.level().dimension(), player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());
    }

    private synchronized void save() { store.save(lobby, combatSpawns); }
}

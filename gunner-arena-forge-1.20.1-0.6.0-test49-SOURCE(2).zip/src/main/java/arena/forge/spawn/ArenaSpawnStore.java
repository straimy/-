package arena.forge.spawn;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

public final class ArenaSpawnStore {
    private final Path file;

    public ArenaSpawnStore(Path file) {
        this.file = file;
    }

    public Snapshot load() {
        if (!Files.isRegularFile(file)) return new Snapshot(null, List.of());
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            p.load(in);
        } catch (IOException ex) {
            throw new IllegalStateException("Failed to read " + file, ex);
        }

        ArenaPoint lobby = parse(p.getProperty("lobby")).orElse(null);
        int count = parseInt(p.getProperty("spawn.count"), 0);
        List<ArenaPoint> spawns = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            parse(p.getProperty("spawn." + i)).ifPresent(spawns::add);
        }
        return new Snapshot(lobby, List.copyOf(spawns));
    }

    public synchronized void save(ArenaPoint lobby, List<ArenaPoint> spawns) {
        Properties p = new Properties();
        if (lobby != null) p.setProperty("lobby", format(lobby));
        p.setProperty("spawn.count", Integer.toString(spawns.size()));
        for (int i = 0; i < spawns.size(); i++) p.setProperty("spawn." + i, format(spawns.get(i)));

        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                p.store(out, "Gunner Arena spawn data - generated automatically");
            }
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicUnsupported) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            throw new IllegalStateException("Failed to write " + file, ex);
        }
    }

    private static String format(ArenaPoint p) {
        return p.dimension().location() + ";" + p.x() + ";" + p.y() + ";" + p.z() + ";" + p.yaw() + ";" + p.pitch();
    }

    private static Optional<ArenaPoint> parse(String raw) {
        if (raw == null || raw.isBlank()) return Optional.empty();
        try {
            String[] s = raw.split(";");
            if (s.length != 6) return Optional.empty();
            ResourceLocation id = new ResourceLocation(s[0]);
            ResourceKey<Level> dim = ResourceKey.create(net.minecraft.core.registries.Registries.DIMENSION, id);
            return Optional.of(new ArenaPoint(dim,
                Double.parseDouble(s[1]), Double.parseDouble(s[2]), Double.parseDouble(s[3]),
                Float.parseFloat(s[4]), Float.parseFloat(s[5])));
        } catch (RuntimeException ex) {
            return Optional.empty();
        }
    }

    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); }
        catch (RuntimeException ex) { return fallback; }
    }

    public record Snapshot(ArenaPoint lobby, List<ArenaPoint> spawns) {}
}

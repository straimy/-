package arena.forge.cleanup;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;
import java.util.Set;

/**
 * Removes short-lived combat debris when CG BETA regenerates the arena.
 *
 * This deliberately does NOT touch players, persistent arena displays, CG BETA markers,
 * NPC infrastructure or arbitrary living entities. Corpse/blood mods are detected by
 * entity registry id/name heuristics so Gunner Arena does not need a hard dependency on
 * Ragdollified/BloodyBits.
 *
 * Client-only blood particles cannot be deleted server-side; they naturally expire while
 * players are moved out of combat during REGENERATING. Any server-backed blood/gore entity
 * is removed here.
 */
public final class ArenaVisualCleanupService {
    private static final Set<String> TRANSIENT_TAGS = Set.of(
        "gunnerarena:temporary",
        "gunnerarena:temporary_hazard",
        "gunnerarena:combat_debris",
        "ga_temporary",
        "ga_hazard"
    );

    private static final String[] CORPSE_HINTS = {
        "ragdoll", "corpse", "dead_body", "deadbody", "body_part", "bodypart",
        "gore", "blood_pool", "bloodpool", "blood_splatter", "bloodsplatter"
    };

    public CleanupResult cleanupAll(MinecraftServer server) {
        int removed = 0;
        int corpseLike = 0;
        int transientCombat = 0;
        for (ServerLevel level : server.getAllLevels()) {
            CleanupResult r = cleanupLevel(level);
            removed += r.removed();
            corpseLike += r.corpseLike();
            transientCombat += r.transientCombat();
        }
        return new CleanupResult(removed, corpseLike, transientCombat);
    }

    public CleanupResult cleanupLevel(ServerLevel level) {
        int removed = 0;
        int corpseLike = 0;
        int transientCombat = 0;

        for (Entity entity : level.getAllEntities()) {
            Reason reason = cleanupReason(entity);
            if (reason == Reason.KEEP) continue;
            entity.discard();
            removed++;
            if (reason == Reason.CORPSE_OR_BLOOD) corpseLike++;
            else transientCombat++;
        }
        return new CleanupResult(removed, corpseLike, transientCombat);
    }

    private static Reason cleanupReason(Entity entity) {
        for (String tag : entity.getTags()) {
            if (TRANSIENT_TAGS.contains(tag)) return Reason.TRANSIENT_COMBAT;
        }

        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        String registry = id == null ? "" : id.toString().toLowerCase(Locale.ROOT);
        String className = entity.getClass().getName().toLowerCase(Locale.ROOT);
        String customName = entity.hasCustomName()
            ? entity.getCustomName().getString().toLowerCase(Locale.ROOT)
            : "";
        String searchable = registry + " " + className + " " + customName;
        for (String hint : CORPSE_HINTS) {
            if (searchable.contains(hint)) return Reason.CORPSE_OR_BLOOD;
        }

        // Combat leftovers that must never survive a map regeneration.
        if (entity instanceof Projectile
            || entity instanceof ItemEntity
            || entity instanceof ExperienceOrb
            || entity instanceof AreaEffectCloud
            || entity instanceof PrimedTnt
            || entity instanceof FallingBlockEntity) {
            return Reason.TRANSIENT_COMBAT;
        }

        return Reason.KEEP;
    }

    private enum Reason { KEEP, CORPSE_OR_BLOOD, TRANSIENT_COMBAT }

    public record CleanupResult(int removed, int corpseLike, int transientCombat) { }
}

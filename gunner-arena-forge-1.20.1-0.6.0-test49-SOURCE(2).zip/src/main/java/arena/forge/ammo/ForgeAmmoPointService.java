package arena.forge.ammo;

import arena.ammo.AmmoManager;
import arena.ammo.point.AmmoPoint;
import arena.ammo.point.AmmoPointStore;
import arena.forge.player.ArenaPlayerManager;
import arena.forge.player.ArenaPlayerState;
import arena.profile.RoundSession;
import arena.round.RoundState;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Forge bridge for persistent, shared-cooldown PRIMARY/SECONDARY ammo stations. */
public final class ForgeAmmoPointService {
    public static final int PRIMARY_COOLDOWN_TICKS = 20 * 20;
    public static final int SECONDARY_COOLDOWN_TICKS = 15 * 20;
    private static final double PICKUP_RADIUS = 1.65;
    private static final double REMOVE_RADIUS = 8.0;

    private final AmmoManager ammo;
    private final AmmoPointStore store;
    private final Map<String, Long> readyAt = new HashMap<>();
    private final Map<UUID, Long> feedbackAt = new HashMap<>();
    private long showUntilTick;

    public ForgeAmmoPointService(AmmoManager ammo, AmmoPointStore store) {
        this.ammo = ammo;
        this.store = store;
    }

    public AmmoPoint add(ServerPlayer player, AmmoManager.PointType type) {
        String dim = player.level().dimension().location().toString();
        return store.add(type, dim, player.getX(), player.getY(), player.getZ());
    }

    public int clear(AmmoManager.PointType type) {
        int removed = store.clear(type);
        if (removed > 0) readyAt.keySet().removeIf(id -> store.all().stream().noneMatch(p -> p.id().equals(id)));
        return removed;
    }

    public AmmoPoint removeNearest(ServerPlayer player, AmmoManager.PointType type) {
        String dim = player.level().dimension().location().toString();
        AmmoPoint removed = store.removeNearest(type, dim, player.getX(), player.getY(), player.getZ(), REMOVE_RADIUS);
        if (removed != null) readyAt.remove(removed.id());
        return removed;
    }

    public List<AmmoPoint> points(AmmoManager.PointType type) {
        return store.byType(type);
    }

    public List<AmmoPoint> all() { return store.all(); }

    public int activeCount(AmmoManager.PointType type, long tick) {
        int count = 0;
        for (AmmoPoint point : store.byType(type)) if (isReady(point, tick)) count++;
        return count;
    }

    public void showFor(long currentTick, int seconds) {
        showUntilTick = Math.max(showUntilTick, currentTick + Math.max(1, seconds) * 20L);
    }

    public boolean isReady(AmmoPoint point, long tick) {
        return tick >= readyAt.getOrDefault(point.id(), 0L);
    }

    public long cooldownRemaining(AmmoPoint point, long tick) {
        return Math.max(0L, readyAt.getOrDefault(point.id(), 0L) - tick);
    }

    public void resetCooldowns() {
        readyAt.clear();
    }

    /** Called from END server tick. Proximity scan is intentionally throttled to 4 Hz. */
    public void tick(MinecraftServer server, ArenaPlayerManager players, RoundState roundState, long tick) {
        if (tick % 5L != 0L) return;
        renderActivePoints(server, tick);
        if (roundState != RoundState.PLAYING) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (players.session(player).state() != ArenaPlayerState.ALIVE) continue;
            String dim = player.level().dimension().location().toString();
            for (AmmoPoint point : store.all()) {
                if (!point.dimension().equals(dim) || !isReady(point, tick)) continue;
                if (point.distanceSquared(player.getX(), player.getY(), player.getZ()) > PICKUP_RADIUS * PICKUP_RADIUS) continue;
                if (tryPickup(player, players.roundSession(player), point, tick)) break;
            }
        }
    }

    private boolean tryPickup(ServerPlayer player, RoundSession session, AmmoPoint point, long tick) {
        String weaponId = point.type() == AmmoManager.PointType.PRIMARY ? session.primaryWeapon() : session.secondaryWeapon();
        if (weaponId == null || weaponId.isBlank()) {
            feedback(player, point.type() == AmmoManager.PointType.PRIMARY ? "Нужно основное оружие" : "Нужно дополнительное оружие", tick);
            return false;
        }

        // Synchronize the pure reserve model with the real JEG ammo item count before calculating the cap.
        var def = ammoWeapon(point.type(), session);
        if (def == null || def.ammoItem() == null || def.ammoItem().isBlank()) {
            feedback(player, "Для этого оружия не настроены патроны", tick);
            return false;
        }
        Item ammoItem = registeredItem(def.ammoItem());
        if (ammoItem == null) {
            feedback(player, "Ammo item не найден: " + def.ammoItem(), tick);
            return false;
        }

        int realBefore = countItem(player, ammoItem);
        session.setReserveAmmo(def.ammoItem(), realBefore);
        AmmoManager.PickupResult result = ammo.pickup(session, point.type(), 1.0);
        if (!result.consumed()) {
            feedback(player, result.message(), tick);
            return false;
        }

        int inserted = insertWithoutDropping(player, ammoItem, result.amount());
        session.setReserveAmmo(def.ammoItem(), realBefore + inserted);
        if (inserted <= 0) {
            feedback(player, "Нет места для патронов", tick);
            return false;
        }

        int cd = point.type() == AmmoManager.PointType.PRIMARY ? PRIMARY_COOLDOWN_TICKS : SECONDARY_COOLDOWN_TICKS;
        readyAt.put(point.id(), tick + cd);
        player.sendSystemMessage(Component.literal("[GA] +" + inserted + " " + def.ammoItem())
            .withStyle(point.type() == AmmoManager.PointType.PRIMARY ? ChatFormatting.AQUA : ChatFormatting.YELLOW));
        return true;
    }

    /** Runtime catalog bridge. Client requests never provide an ammo item directly. */
    public interface WeaponResolver { arena.weapon.WeaponDefinition resolve(String id); }
    private WeaponResolver resolver;
    public void bindWeaponResolver(WeaponResolver resolver) { this.resolver = resolver; }

    private arena.weapon.WeaponDefinition ammoWeapon(AmmoManager.PointType type, RoundSession session) {
        String weapon = type == AmmoManager.PointType.PRIMARY ? session.primaryWeapon() : session.secondaryWeapon();
        return weapon == null || resolver == null ? null : resolver.resolve(weapon);
    }

    private void feedback(ServerPlayer player, String message, long tick) {
        long next = feedbackAt.getOrDefault(player.getUUID(), 0L);
        if (tick < next) return;
        feedbackAt.put(player.getUUID(), tick + 40L);
        player.displayClientMessage(Component.literal("[GA] " + message).withStyle(ChatFormatting.GRAY), true);
    }

    private void renderActivePoints(MinecraftServer server, long tick) {
        boolean debug = tick <= showUntilTick;
        if (!debug && tick % 10L != 0L) return;
        for (AmmoPoint point : store.all()) {
            ServerLevel level = findLevel(server, point.dimension());
            if (level == null) continue;
            boolean ready = isReady(point, tick);
            if (!ready && !debug) continue;
            double y = point.y() + 0.35 + Math.sin(tick / 8.0) * 0.08;
            var particle = point.type() == AmmoManager.PointType.PRIMARY ? ParticleTypes.END_ROD : ParticleTypes.HAPPY_VILLAGER;
            int count = debug ? 5 : 2;
            level.sendParticles(particle, point.x(), y, point.z(), count, 0.18, 0.12, 0.18, 0.005);
            if (debug) level.sendParticles(ParticleTypes.COMPOSTER, point.x(), point.y() + 1.0, point.z(), 3, 0.08, 0.08, 0.08, 0.0);
        }
    }

    private static ServerLevel findLevel(MinecraftServer server, String dimension) {
        for (ServerLevel level : server.getAllLevels()) {
            if (level.dimension().location().toString().equals(dimension)) return level;
        }
        return null;
    }

    private static int insertWithoutDropping(ServerPlayer player, Item item, int amount) {
        int before = countItem(player, item);
        int remaining = Math.max(0, amount);
        while (remaining > 0) {
            int size = Math.min(remaining, item.getMaxStackSize());
            ItemStack stack = new ItemStack(item, size);
            player.getInventory().add(stack);
            remaining -= size;
            if (!stack.isEmpty()) break; // inventory full; never drop arena ammo on the ground
        }
        return Math.max(0, countItem(player, item) - before);
    }

    private static int countItem(ServerPlayer player, Item item) {
        int count = 0;
        for (ItemStack stack : player.getInventory().items) if (stack.is(item)) count += stack.getCount();
        for (ItemStack stack : player.getInventory().offhand) if (stack.is(item)) count += stack.getCount();
        return count;
    }

    private static Item registeredItem(String id) {
        ResourceLocation key = ResourceLocation.tryParse(id);
        if (key == null || !BuiltInRegistries.ITEM.containsKey(key)) return null;
        Item item = BuiltInRegistries.ITEM.get(key);
        return item == Items.AIR ? null : item;
    }
}

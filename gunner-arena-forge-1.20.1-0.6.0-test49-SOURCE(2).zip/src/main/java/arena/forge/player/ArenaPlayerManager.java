package arena.forge.player;

import arena.economy.CurrencyService;
import arena.forge.spawn.ArenaPoint;
import arena.profile.PlayerProfile;
import arena.profile.ProfileService;
import arena.profile.RoundSession;
import arena.forge.spawn.SpawnManager;
import arena.forge.loadout.ForgeLoadoutService;
import arena.round.RoundState;
import arena.rpg.RpgService;
import arena.rpg.SkillEffect;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

public final class ArenaPlayerManager {
    public static final long SPAWN_PROTECTION_TICKS = 20L * 3L;

    private final SpawnManager spawns;
    private final ProfileService profiles;
    private final CurrencyService currency;
    private ForgeLoadoutService forgeLoadouts;
    private RpgService rpg;
    private final Map<UUID, ArenaPlayerSession> sessions = new ConcurrentHashMap<>();

    public ArenaPlayerManager(SpawnManager spawns, ProfileService profiles, CurrencyService currency) {
        this.spawns = spawns;
        this.profiles = profiles;
        this.currency = currency;
    }

    public void bindLoadouts(ForgeLoadoutService forgeLoadouts) { this.forgeLoadouts = forgeLoadouts; }
    public void bindRpg(RpgService rpg) { this.rpg = rpg; }

    public ArenaPlayerSession session(ServerPlayer player) {
        return sessions.computeIfAbsent(player.getUUID(), ignored -> new ArenaPlayerSession());
    }

    public void onLogin(ServerPlayer player) {
        profiles.login(player.getUUID(), player.getGameProfile().getName());
        ArenaPlayerSession s = session(player);
        s.state(ArenaPlayerState.LOBBY);
        s.clearProtection();
    }

    public void onLogout(ServerPlayer player) { profiles.logout(player.getUUID()); sessions.remove(player.getUUID()); }

    public boolean requestPlay(MinecraftServer server, ServerPlayer player, RoundState roundState, int roundNumber, long tick) {
        ArenaPlayerSession s = session(player);
        if (roundState != RoundState.PLAYING) {
            s.state(ArenaPlayerState.QUEUED);
            player.sendSystemMessage(Component.literal("[GA] Ты в очереди. Вход в арену — после начала раунда.").withStyle(ChatFormatting.YELLOW));
            return false;
        }
        prepareForRound(player, roundNumber);
        return spawnIntoArena(server, player, tick);
    }

    /** Initializes volatile match state exactly once for a given round, including late joins. */
    private void prepareForRound(ServerPlayer player, int roundNumber) {
        ArenaPlayerSession s = session(player);
        if (s.isInRound(roundNumber)) return;
        profiles.resetRound(player.getUUID());
        s.beginRound(roundNumber);
        s.resetKillStreak();
        if (forgeLoadouts != null) {
            forgeLoadouts.clearCombatSlots(player);
            forgeLoadouts.giveKnife(player);
        }
        PlayerProfile profile = profiles.profile(player.getUUID());
        if (profile != null) {
            profile.roundsPlayed++;
            profiles.markDirty(player.getUUID());
        }
    }

    public boolean spawnIntoArena(MinecraftServer server, ServerPlayer player, long tick) {
        ArenaPoint point = spawns.selectSafeSpawn(server, player).orElse(null);
        if (point == null) {
            player.sendSystemMessage(Component.literal("[GA] Нет боевых spawn-точек. Используй /addspawn.").withStyle(ChatFormatting.RED));
            session(player).state(ArenaPlayerState.LOBBY);
            return false;
        }
        ArenaPlayerSession s = session(player);
        s.state(ArenaPlayerState.SPAWNING);
        if (!spawns.teleport(server, player, point)) {
            s.state(ArenaPlayerState.LOBBY);
            return false;
        }
        s.protectionUntilTick(tick + SPAWN_PROTECTION_TICKS);
        if (forgeLoadouts != null) forgeLoadouts.restoreAfterRespawn(player, profiles.round(player.getUUID()));
        s.state(ArenaPlayerState.ALIVE);
        player.sendSystemMessage(Component.literal("[GA] Spawn protection: 3s").withStyle(ChatFormatting.AQUA));
        return true;
    }

    public boolean sendLobby(MinecraftServer server, ServerPlayer player) {
        ArenaPlayerSession s = session(player);
        s.state(ArenaPlayerState.LOBBY);
        s.clearProtection();
        ArenaPoint point = spawns.lobby().orElse(null);
        if (point == null) return false;
        return spawns.teleport(server, player, point);
    }

    public void onDeath(ServerPlayer player) {
        ArenaPlayerSession s = session(player);
        if (s.state() == ArenaPlayerState.ALIVE || s.state() == ArenaPlayerState.SPAWNING) {
            s.state(ArenaPlayerState.DEAD);
            s.clearProtection();
            s.resetKillStreak();
            RoundSession round = profiles.round(player.getUUID());
            round.addDeath();
            PlayerProfile profile = profiles.profile(player.getUUID());
            if (profile != null) { profile.deaths++; profiles.markDirty(player.getUUID()); }
        }
    }

    /** Records a valid arena PvP kill. Returns the credited match Credits. */
    public int rewardKill(ServerPlayer killer, ServerPlayer victim) {
        if (killer == victim) return 0;
        ArenaPlayerSession killerState = session(killer);
        if (killerState.state() != ArenaPlayerState.ALIVE) return 0;
        RoundSession round = profiles.round(killer.getUUID());
        int before = round.credits();
        round.addKill();
        PlayerProfile killerProfileForBonus = profiles.profile(killer.getUUID());
        double creditMultiplier = 1.0 + (rpg == null ? 0.0 : rpg.effects().value(killerProfileForBonus, SkillEffect.Type.CREDIT_GAIN));
        currency.rewardKill(round, creditMultiplier);
        int credited = round.credits() - before;
        PlayerProfile profile = profiles.profile(killer.getUUID());
        if (profile != null) {
            profile.kills++;
            profile.lifetimeCredits += credited;
            int streak = killerState.addKillToStreak();
            profile.bestKillStreak = Math.max(profile.bestKillStreak, streak);
            if (rpg != null) rpg.grantXp(profile, 120);
            profiles.markDirty(killer.getUUID());
        }
        return credited;
    }


    /** Records dealt arena damage for round/lifetime statistics. */
    public void recordDamage(ServerPlayer attacker, double amount) {
        if (attacker == null || amount <= 0.0 || session(attacker).state() != ArenaPlayerState.ALIVE) return;
        long rounded = Math.max(1L, Math.round(amount));
        RoundSession round = profiles.round(attacker.getUUID());
        round.addDamage(rounded);
        PlayerProfile profile = profiles.profile(attacker.getUUID());
        if (profile != null) {
            profile.damageDealt += rounded;
            profiles.markDirty(attacker.getUUID());
        }
    }

    /** Records one server-authoritative custom-weapon shot for lifetime accuracy. */
    public void recordShot(ServerPlayer shooter, boolean hit) {
        if (shooter == null || session(shooter).state() != ArenaPlayerState.ALIVE) return;
        PlayerProfile profile = profiles.profile(shooter.getUUID());
        if (profile == null) return;
        profile.shotsFired++;
        if (hit) profile.shotsHit++;
        profiles.markDirty(shooter.getUUID());
    }

    /** Returns Credits awarded for one qualifying assist. */
    public int rewardAssist(ServerPlayer assistant) {
        if (assistant == null || session(assistant).state() != ArenaPlayerState.ALIVE) return 0;
        RoundSession round = profiles.round(assistant.getUUID());
        int before = round.credits();
        round.addAssist();
        PlayerProfile assistantProfileForBonus = profiles.profile(assistant.getUUID());
        double creditMultiplier = 1.0 + (rpg == null ? 0.0 : rpg.effects().value(assistantProfileForBonus, SkillEffect.Type.CREDIT_GAIN));
        currency.rewardAssist(round, creditMultiplier);
        int credited = round.credits() - before;
        PlayerProfile profile = profiles.profile(assistant.getUUID());
        if (profile != null) {
            profile.assists++;
            profile.lifetimeCredits += credited;
            if (rpg != null) rpg.grantXp(profile, 45);
            profiles.markDirty(assistant.getUUID());
        }
        return credited;
    }

    public void onRespawn(MinecraftServer server, ServerPlayer player, RoundState roundState, long tick) {
        ArenaPlayerSession s = session(player);
        if (s.state() != ArenaPlayerState.DEAD) return;
        if (roundState == RoundState.PLAYING) spawnIntoArena(server, player, tick);
        else sendLobby(server, player);
    }

    /**
     * Starts the round only for players whose authentication/profile session is fully initialized.
     * This avoids creating arena sessions for players who are still sitting at the SAuth gate.
     */
    public void onRoundStarted(MinecraftServer server, int roundNumber, long tick, Predicate<ServerPlayer> eligible) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (eligible != null && !eligible.test(player)) continue;
            ArenaPlayerSession arenaSession = session(player);
            // Lobby spectators did not opt into this match: do not reset their Credits/loadout
            // and do not increment roundsPlayed. Only queued players become participants here.
            if (arenaSession.state() != ArenaPlayerState.QUEUED) continue;
            prepareForRound(player, roundNumber);
            spawnIntoArena(server, player, tick);
        }
    }

    /** Sends only fully initialized arena players back to lobby. */
    public void onRoundStopped(MinecraftServer server, Predicate<ServerPlayer> eligible) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (eligible != null && !eligible.test(player)) continue;
            ArenaPlayerSession arenaSession = session(player);
            ArenaPlayerState state = arenaSession.state();
            if (state == ArenaPlayerState.ALIVE || state == ArenaPlayerState.SPAWNING || state == ArenaPlayerState.DEAD) {
                sendLobby(server, player);
            }
            arenaSession.endRound();
        }
    }

    public PlayerProfile profile(ServerPlayer player) { return profiles.profile(player.getUUID()); }
    public RoundSession roundSession(ServerPlayer player) { return profiles.round(player.getUUID()); }
    public void saveDirtyProfiles() { profiles.saveDirty(); }
    public void saveAllProfiles() { profiles.saveAll(); }

    public boolean isProtected(ServerPlayer player, long tick) { return session(player).protectedAt(tick); }
    public void clearProtection(ServerPlayer player) { session(player).clearProtection(); }
}

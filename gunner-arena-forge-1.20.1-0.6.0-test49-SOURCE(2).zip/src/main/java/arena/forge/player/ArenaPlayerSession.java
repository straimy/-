package arena.forge.player;

public final class ArenaPlayerSession {
    private ArenaPlayerState state = ArenaPlayerState.LOBBY;
    private long protectionUntilTick;
    private int killStreak;
    private int activeRoundNumber;

    public ArenaPlayerState state() { return state; }
    public void state(ArenaPlayerState state) { this.state = state; }
    public long protectionUntilTick() { return protectionUntilTick; }
    public void protectionUntilTick(long tick) { protectionUntilTick = tick; }
    public boolean protectedAt(long tick) { return tick < protectionUntilTick; }
    public void clearProtection() { protectionUntilTick = 0; }
    public int killStreak() { return killStreak; }
    public int addKillToStreak() { return ++killStreak; }
    public void resetKillStreak() { killStreak = 0; }

    /** Round identity prevents stale Credits/loadout/stat state leaking into a later match. */
    public int activeRoundNumber() { return activeRoundNumber; }
    public boolean isInRound(int roundNumber) { return roundNumber > 0 && activeRoundNumber == roundNumber; }
    public void beginRound(int roundNumber) { activeRoundNumber = Math.max(0, roundNumber); }
    public void endRound() { activeRoundNumber = 0; }
}

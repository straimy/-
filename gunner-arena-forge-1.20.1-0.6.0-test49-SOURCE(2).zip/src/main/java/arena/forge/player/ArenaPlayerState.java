package arena.forge.player;

public enum ArenaPlayerState {
    LOBBY,
    QUEUED,
    SPAWNING,
    ALIVE,
    DEAD,
    SPECTATING,
    DUEL,
    AFK
}

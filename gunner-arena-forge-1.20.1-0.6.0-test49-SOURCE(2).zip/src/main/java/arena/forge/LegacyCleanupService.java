package arena.forge;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Interaction;

import java.util.Set;

/** Conservative cleanup for entities created by old GunnerArena builds only. */
public final class LegacyCleanupService {
    private static final Set<String> LEGACY_TAGS = Set.of(
        "gunnerarena_npc", "gunnerarena_holo", "gunnerarena_ammo",
        "ga_npc", "ga_hologram", "ga_ammo", "ga_interaction",
        "gunnerarena:legacy", "gunnerarena:temporary"
    );

    public int cleanupAll(MinecraftServer server) {
        int removed = 0;
        for (ServerLevel level : server.getAllLevels()) removed += cleanupLevel(level);
        return removed;
    }

    public int cleanupLevel(ServerLevel level) {
        int removed = 0;
        for (Entity entity : level.getAllEntities()) {
            if (!isLegacyArenaEntity(entity)) continue;
            entity.discard();
            removed++;
        }
        return removed;
    }

    private static boolean isLegacyArenaEntity(Entity entity) {
        if (!(entity instanceof ArmorStand || entity instanceof Display || entity instanceof Interaction)) return false;
        for (String tag : entity.getTags()) if (LEGACY_TAGS.contains(tag)) return true;
        if (entity.hasCustomName()) {
            String name = entity.getCustomName().getString().toLowerCase(java.util.Locale.ROOT);
            return name.contains("gunner arena") || name.contains("gunnerarena") || name.equals("играть") || name.equals("магазин");
        }
        return false;
    }
}

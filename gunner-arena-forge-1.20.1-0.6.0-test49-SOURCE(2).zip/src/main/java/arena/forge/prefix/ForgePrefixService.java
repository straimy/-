package arena.forge.prefix;

import arena.prefix.PrefixResolver;
import arena.prefix.PrefixRole;
import arena.prefix.PrefixStyle;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.server.level.ServerPlayer;

/** Builds one consistent KVICloud prefix for nameplates, chat display names and TAB. */
public final class ForgePrefixService {
    private final PrefixResolver resolver = new PrefixResolver();

    public PrefixRole role(ServerPlayer player) {
        boolean op = player.getServer() != null && player.getServer().getPlayerList().isOp(player.getGameProfile());
        return resolver.roleForPermissionLevel(op ? 2 : 0);
    }

    public Component decoratedName(ServerPlayer player, Component username) {
        PrefixStyle style = resolver.style(role(player));
        MutableComponent out = Component.empty();
        out.append(Component.literal(style.symbol() + " ").withStyle(color(style.rgbStops()[0])));
        out.append(gradient(style.label(), style.rgbStops()));
        out.append(Component.literal(" · ").withStyle(color(0x777777)));
        out.append(username.copy().withStyle(color(role(player) == PrefixRole.ADMIN ? 0xFFF2C2 : 0xFFFFFF)));
        return out;
    }

    public Component joinMessage(ServerPlayer player) {
        return Component.literal("✦ ").withStyle(color(0xFFD34E))
            .append(decoratedName(player, Component.literal(player.getGameProfile().getName())))
            .append(Component.literal(" присоединился к ").withStyle(color(0xA0A0A0)))
            .append(Component.literal("KVICloud").withStyle(color(0xB86CFF)))
            .append(Component.literal(" • рады тебя видеть!").withStyle(color(0xC8C8C8)));
    }

    public Component leaveMessage(ServerPlayer player) {
        return Component.literal("✦ ").withStyle(color(0xB0B0B0))
            .append(decoratedName(player, Component.literal(player.getGameProfile().getName())))
            .append(Component.literal(" покинул KVICloud • ждём снова!").withStyle(color(0x8E8E8E)));
    }

    private static MutableComponent gradient(String text, int[] stops) {
        MutableComponent result = Component.empty();
        if (text.isEmpty()) return result;
        for (int i = 0; i < text.length(); i++) {
            double t = text.length() <= 1 ? 0.0 : i / (double) (text.length() - 1);
            int rgb = interpolateStops(stops, t);
            result.append(Component.literal(String.valueOf(text.charAt(i))).withStyle(color(rgb)));
        }
        return result;
    }

    private static int interpolateStops(int[] stops, double t) {
        if (stops.length == 1) return stops[0];
        double scaled = Math.max(0.0, Math.min(1.0, t)) * (stops.length - 1);
        int index = Math.min(stops.length - 2, (int) Math.floor(scaled));
        double local = scaled - index;
        int a = stops[index];
        int b = stops[index + 1];
        int r = lerp((a >> 16) & 0xFF, (b >> 16) & 0xFF, local);
        int g = lerp((a >> 8) & 0xFF, (b >> 8) & 0xFF, local);
        int bl = lerp(a & 0xFF, b & 0xFF, local);
        return (r << 16) | (g << 8) | bl;
    }

    private static int lerp(int a, int b, double t) {
        return (int) Math.round(a + (b - a) * t);
    }

    private static Style color(int rgb) {
        return Style.EMPTY.withColor(TextColor.fromRgb(rgb));
    }
}

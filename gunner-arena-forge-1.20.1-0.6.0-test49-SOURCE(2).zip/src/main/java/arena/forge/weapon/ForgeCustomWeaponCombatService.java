package arena.forge.weapon;

import arena.forge.item.ArenaWeaponItem;
import arena.weapon.CustomWeaponArsenal;
import arena.weapon.WeaponCatalog;
import arena.weapon.WeaponDefinition;
import arena.weapon.WeaponRuntimeController;
import arena.weapon.WeaponTuning;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Objects;
import java.util.function.ToDoubleFunction;

/**
 * Forge-side combat adapter for Gunner Arena-owned weapons.
 *
 * The trigger cadence, fire mode, magazine and reload decisions remain in the pure
 * {@link WeaponRuntimeController}. This adapter only reads the held registered item,
 * performs a server-side hitscan and applies the already-approved damage.
 */
public final class ForgeCustomWeaponCombatService {
    private final WeaponCatalog catalog;
    private final CustomWeaponArsenal arsenal;
    private final WeaponRuntimeController runtime = new WeaponRuntimeController();
    private ToDoubleFunction<ServerPlayer> damageMultiplier = ignored -> 1.0D;

    public ForgeCustomWeaponCombatService(WeaponCatalog catalog, CustomWeaponArsenal arsenal) {
        this.catalog = Objects.requireNonNull(catalog, "catalog");
        this.arsenal = Objects.requireNonNull(arsenal, "arsenal");
        arsenal.validateAgainst(catalog);
    }

    public void bindDamageMultiplier(ToDoubleFunction<ServerPlayer> resolver) {
        this.damageMultiplier = resolver == null ? ignored -> 1.0D : resolver;
    }

    /** Advances held-trigger state once per server tick. Returns a shot result only when cadence released a round. */
    public TickResult tick(ServerPlayer player, boolean combatAllowed, long nowMillis) {
        ItemStack stack = player.getMainHandItem();
        ArenaWeaponItem item = customItem(stack);
        if (item == null) return TickResult.idle();

        WeaponDefinition definition = catalog.get(item.weaponId());
        WeaponTuning tuning = arsenal.get(item.weaponId());
        if (definition == null || tuning == null) return TickResult.idle();

        boolean triggerHeld = combatAllowed && player.isUsingItem() && player.getUseItem() == stack;
        WeaponRuntimeController.RuntimeUpdate update = runtime.update(actor(player), definition, tuning, triggerHeld, nowMillis);
        if (!update.fired()) {
            if (update.shotBlockReason() == arena.weapon.AmmoStateController.ShotBlockReason.EMPTY_MAGAZINE
                    && update.ammo().reserve() > 0 && !update.ammo().reloading()) {
                runtime.reload(actor(player), definition, tuning, nowMillis);
            }
            return new TickResult(false, false, false, update.ammo().magazine(), update.ammo().reserve(), update.fire().mode().name());
        }

        ShotOutcome shot = fireHitscan(player, tuning);
        return new TickResult(true, shot.hit(), shot.headshot(), update.ammo().magazine(), update.ammo().reserve(), update.fire().mode().name());
    }

    public CommandResult requestReload(ServerPlayer player, long nowMillis) {
        ItemStack stack = player.getMainHandItem();
        ArenaWeaponItem item = customItem(stack);
        if (item == null) return new CommandResult(false, "Возьми кастомное оружие Gunner Arena в основную руку.");
        WeaponDefinition definition = catalog.get(item.weaponId());
        WeaponTuning tuning = arsenal.get(item.weaponId());
        if (definition == null || tuning == null) return new CommandResult(false, "У оружия нет боевого профиля.");
        var result = runtime.reload(actor(player), definition, tuning, nowMillis);
        if (!result.started()) {
            String reason = switch (result.reason()) {
                case ALREADY_RELOADING -> "Перезарядка уже идёт.";
                case MAGAZINE_FULL -> "Магазин уже полный.";
                case NO_RESERVE -> "Нет патронов в резерве.";
                default -> "Перезарядка недоступна.";
            };
            return new CommandResult(false, reason);
        }
        return new CommandResult(true, "Перезарядка • " + result.ammo().magazine() + "/" + result.ammo().reserve());
    }

    public CommandResult cycleMode(ServerPlayer player) {
        ItemStack stack = player.getMainHandItem();
        ArenaWeaponItem item = customItem(stack);
        if (item == null) return new CommandResult(false, "Возьми кастомное оружие Gunner Arena в основную руку.");
        WeaponTuning tuning = arsenal.get(item.weaponId());
        if (tuning == null) return new CommandResult(false, "У оружия нет боевого профиля.");
        WeaponDefinition.FireMode mode = runtime.cycleMode(actor(player), tuning);
        return new CommandResult(true, "Режим огня: " + mode.name());
    }

    public void showAmmo(ServerPlayer player, long nowMillis) {
        ArenaWeaponItem item = customItem(player.getMainHandItem());
        if (item == null) return;
        WeaponDefinition definition = catalog.get(item.weaponId());
        if (definition == null) return;
        var ammo = runtime.ammo(actor(player), definition, nowMillis);
        String suffix = ammo.reloading() ? " • ПЕРЕЗАРЯДКА" : "";
        player.displayClientMessage(Component.literal("▣ " + ammo.magazine() + "/" + ammo.reserve() + suffix).withStyle(ChatFormatting.AQUA), true);
    }

    public void forget(ServerPlayer player) { runtime.forgetActor(actor(player)); }

    /** Hard lifecycle boundary used on round regeneration/server stop. */
    public void clearAll() { runtime.clearAll(); }

    private ShotOutcome fireHitscan(ServerPlayer shooter, WeaponTuning tuning) {
        ServerLevel level = shooter.serverLevel();
        double range = rangeFor(tuning.weaponId());
        Vec3 start = shooter.getEyePosition();
        Vec3 direction = shooter.getLookAngle().normalize();
        Vec3 intendedEnd = start.add(direction.scale(range));

        HitResult blockHit = level.clip(new ClipContext(start, intendedEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
        Vec3 end = blockHit.getType() == HitResult.Type.MISS ? intendedEnd : blockHit.getLocation();
        AABB search = shooter.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0D);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(
                level,
                shooter,
                start,
                end,
                search,
                entity -> entity instanceof ServerPlayer target && target != shooter && target.isAlive() && target.isPickable(),
                0.0F);

        if (entityHit == null || !(entityHit.getEntity() instanceof ServerPlayer target)) return ShotOutcome.miss();
        boolean headshot = isHeadshot(target, entityHit.getLocation());
        double mult = Math.max(0.5D, Math.min(1.25D, damageMultiplier.applyAsDouble(shooter)));
        float damage = (float) ((headshot ? tuning.headDamage() : tuning.bodyDamage()) * mult);
        boolean hurt = target.hurt(shooter.damageSources().playerAttack(shooter), damage);
        return hurt ? new ShotOutcome(true, headshot, target) : ShotOutcome.miss();
    }

    private static boolean isHeadshot(ServerPlayer target, Vec3 hit) {
        AABB box = target.getBoundingBox();
        double threshold = box.minY + (box.maxY - box.minY) * 0.72D;
        return hit.y >= threshold;
    }

    private static double rangeFor(String weaponId) {
        return switch (weaponId) {
            case "gunnerarena:p9" -> 42.0D;
            case "gunnerarena:px18" -> 38.0D;
            case "gunnerarena:vkr47" -> 72.0D;
            case "gunnerarena:raven_m96" -> 128.0D;
            default -> 48.0D;
        };
    }

    private static ArenaWeaponItem customItem(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.getItem() instanceof ArenaWeaponItem item ? item : null;
    }

    private static String actor(ServerPlayer player) { return player.getUUID().toString(); }

    public record TickResult(boolean fired, boolean hit, boolean headshot, int magazine, int reserve, String mode) {
        public TickResult {
            if (magazine < 0 || reserve < 0) throw new IllegalArgumentException("ammo");
            Objects.requireNonNull(mode, "mode");
        }
        public static TickResult idle() { return new TickResult(false, false, false, 0, 0, "NONE"); }
    }
    public record CommandResult(boolean success, String message) { public CommandResult { Objects.requireNonNull(message); } }
    private record ShotOutcome(boolean hit, boolean headshot, Entity target) {
        static ShotOutcome miss() { return new ShotOutcome(false, false, null); }
    }
}

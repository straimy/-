package arena.forge;

import arena.forge.net.ArenaNetwork;

import arena.economy.CurrencyService;
import arena.forge.player.ArenaPlayerManager;
import arena.profile.ProfileService;
import arena.profile.ProfileStorage;
import arena.forge.spawn.ArenaSpawnStore;
import arena.forge.spawn.SpawnManager;
import arena.round.CGBetaRegenerator;
import arena.round.CGBetaSnapshot;
import arena.round.RoundManager;
import arena.round.RoundState;
import arena.weapon.WeaponCatalog;
import arena.weapon.CustomWeaponArsenal;
import arena.weapon.CustomWeaponCombatPolicy;
import arena.forge.weapon.ForgeCustomWeaponCombatService;
import arena.forge.item.ArenaWeaponItem;
import arena.loadout.LoadoutManager;
import arena.forge.loadout.ForgeLoadoutService;
import arena.combat.DamageTracker;
import arena.combat.DeathEventGuard;
import arena.ammo.AmmoManager;
import arena.ammo.point.AmmoPointStore;
import arena.forge.ammo.ForgeAmmoPointService;
import arena.region.SafeRegionRegistry;
import arena.region.SafeRegionStore;
import arena.region.SafeRegionPresenceTracker;
import arena.hazard.HazardManager;
import arena.forge.hazard.ForgeHazardExecutor;
import arena.forge.prefix.ForgePrefixService;
import arena.weapon.WeaponSafetyPolicy;
import arena.net.ArenaSnapshot;
import arena.bot.BotDirector;
import arena.rpg.RpgService;
import arena.rpg.SkillCatalog;
import arena.rpg.SkillEffect;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.server.ServerLifecycleHooks;

public final class ArenaRuntime {
    private final RoundManager rounds = new RoundManager();
    private final CGBetaForgeAdapter cgBeta = new CGBetaForgeAdapter();
    private final WeaponCatalog weapons = new WeaponCatalog();
    private final CustomWeaponArsenal customArsenal = new CustomWeaponArsenal();
    private final ForgeCustomWeaponCombatService customWeaponCombat = new ForgeCustomWeaponCombatService(weapons, customArsenal);
    private final CurrencyService currency = new CurrencyService();
    private final LoadoutManager loadouts = new LoadoutManager(weapons, currency);
    private final ForgeLoadoutService forgeLoadouts = new ForgeLoadoutService(weapons, loadouts);
    private final AmmoManager ammo = new AmmoManager(weapons);
    private final ForgeAmmoPointService ammoPoints = new ForgeAmmoPointService(ammo, new AmmoPointStore(
        FMLPaths.CONFIGDIR.get().resolve("gunnerarena").resolve("ammo-points.properties")));
    private final DamageTracker damage = new DamageTracker();
    private final DeathEventGuard deathGuard = new DeathEventGuard();
    private final ProfileService profiles = new ProfileService(new ProfileStorage(
        FMLPaths.CONFIGDIR.get().resolve("gunnerarena").resolve("players")), currency);
    private final SpawnManager spawns = new SpawnManager(new ArenaSpawnStore(
        FMLPaths.CONFIGDIR.get().resolve("gunnerarena").resolve("arena-spawns.properties")));
    private final ArenaPlayerManager players = new ArenaPlayerManager(spawns, profiles, currency);
    private final LegacyCleanupService legacyCleanup = new LegacyCleanupService();
    private final AuthGate auth = new AuthGate();
    private final SafeRegionService safeRegions = new SafeRegionService(new SafeRegionRegistry(new SafeRegionStore(
        FMLPaths.CONFIGDIR.get().resolve("gunnerarena").resolve("safe-regions.properties"))));
    private final SafeRegionPresenceTracker safePresence = new SafeRegionPresenceTracker();
    private final HazardManager hazards = new HazardManager(safeRegions.registry());
    private final ForgeHazardExecutor hazardExecutor = new ForgeHazardExecutor();
    private final ForgePrefixService prefixes = new ForgePrefixService();
    private final BotDirector bots = new BotDirector();
    private final RpgService rpg = new RpgService(new SkillCatalog());

    public ArenaRuntime() {
        players.bindLoadouts(forgeLoadouts);
        players.bindRpg(rpg);
        customWeaponCombat.bindDamageMultiplier(player -> 1.0D + rpg.effects().value(players.profile(player), SkillEffect.Type.DAMAGE_MULT));
        ammoPoints.bindWeaponResolver(weapons::get);
    }
    private long serverTick;
    private boolean triggerIssued;
    private long pendingRoundStartAtTick = -1L;

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        GunnerCommands.register(event.getDispatcher(), this);
    }

    @SubscribeEvent
    public void onNameFormat(PlayerEvent.NameFormat event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            event.setDisplayname(prefixes.decoratedName(player, event.getDisplayname()));
        }
    }

    @SubscribeEvent
    public void onTabListNameFormat(PlayerEvent.TabListNameFormat event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            event.setDisplayName(prefixes.decoratedName(player, Component.literal(player.getGameProfile().getName())));
        }
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            // SAuth intentionally starts every connection unauthenticated.
            // Do not create an arena session or profile session until login/register succeeds.
            player.sendSystemMessage(Component.literal("Gunner Arena Core loaded").withStyle(ChatFormatting.DARK_AQUA));
            MinecraftServer server = player.getServer();
            if (server != null && !auth.isAuthenticated(player)) auth.enforceLobby(server, player, spawns);
        }
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            if (auth.isInitialized(player)) {
                MinecraftServer server = player.getServer();

                // Combat-log fence: disconnecting shortly after meaningful PvP damage
                // cannot erase the death/kill/assist from the active round. Normal
                // disconnects with no recent qualifying damage are never punished.
                boolean aliveInRound = rounds.state() == RoundState.PLAYING
                    && players.session(player).state() == arena.forge.player.ArenaPlayerState.ALIVE;
                if (aliveInRound) {
                    var logout = damage.consumeCombatLogout(player.getUUID(), serverTick, player.getMaxHealth());
                    if (logout.inCombat()) {
                        players.onDeath(player);
                        if (server != null && logout.killer() != null) {
                            ServerPlayer killer = server.getPlayerList().getPlayer(logout.killer());
                            if (killer != null && isArenaReady(killer)
                                && players.session(killer).state() == arena.forge.player.ArenaPlayerState.ALIVE) {
                                int reward = players.rewardKill(killer, player);
                                if (reward > 0) killer.sendSystemMessage(Component.literal("[GA] Combat logout kill +$" + reward).withStyle(ChatFormatting.GREEN));
                            }
                            for (var uuid : logout.assistants()) {
                                ServerPlayer assistant = server.getPlayerList().getPlayer(uuid);
                                if (assistant == null || !isArenaReady(assistant)
                                    || players.session(assistant).state() != arena.forge.player.ArenaPlayerState.ALIVE) continue;
                                int reward = players.rewardAssist(assistant);
                                if (reward > 0) assistant.sendSystemMessage(Component.literal("[GA] Combat logout assist +$" + reward).withStyle(ChatFormatting.YELLOW));
                            }
                        }
                    }
                }

                if (server != null) server.getPlayerList().broadcastSystemMessage(prefixes.leaveMessage(player), false);
                players.onLogout(player);
            }
            auth.forget(player);
            damage.clear(player.getUUID());
            damage.forgetAttacker(player.getUUID());
            deathGuard.forget(player.getUUID());
            safePresence.forget(player.getUUID());
            ArenaNetwork.forget(player);
            customWeaponCombat.forget(player);
            if (player.getTags().contains("gunnerarena_bot")) bots.disconnected(player.getGameProfile().getName());
        }
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        if (!isArenaReady(victim)) return;
        if (safeRegions.isSafe(victim)) { event.setCanceled(true); return; }
        if (rounds.state() != RoundState.PLAYING) return;
        if (players.session(victim).state() != arena.forge.player.ArenaPlayerState.ALIVE) return;
        ServerPlayer attacker = resolvePlayerAttacker(event.getSource());
        if (attacker == null || attacker == victim) return;
        if (!isArenaReady(attacker) || players.session(attacker).state() != arena.forge.player.ArenaPlayerState.ALIVE) return;
        // Do not inflate damage statistics with overkill damage from high-power JEG weapons.
        // LivingHurtEvent may expose a hit larger than the victim's remaining health.
        double amount = Math.min(Math.max(0.0, event.getAmount()), Math.max(0.0F, victim.getHealth()));
        if (amount <= 0.0) return;
        damage.record(victim.getUUID(), attacker.getUUID(), amount, serverTick);
        players.recordDamage(attacker, amount);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onKnockBack(LivingKnockBackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!auth.isAuthenticated(player) || safeRegions.isSafe(player)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        if (!isArenaReady(victim)) return;
        if (safeRegions.isSafe(victim)) {
            event.setCanceled(true);
            victim.setHealth(Math.max(1.0F, victim.getMaxHealth()));
            victim.clearFire();
            return;
        }
        boolean arenaDeath = rounds.state() == RoundState.PLAYING
            && players.session(victim).state() == arena.forge.player.ArenaPlayerState.ALIVE;
        if (arenaDeath && !deathGuard.tryAccept(victim.getUUID(), serverTick)) {
            // Explicit one-shot fence for overlapping fatal callbacks from gun/projectile mods.
            // No duplicate death, kill, assist or Credits mutation may pass this point.
            damage.clear(victim.getUUID());
            return;
        }
        ServerPlayer killer = resolvePlayerAttacker(event.getSource());
        var assistants = arenaDeath
            ? damage.consumeAssists(victim.getUUID(), killer == null ? null : killer.getUUID(), serverTick, victim.getMaxHealth())
            : java.util.List.<java.util.UUID>of();
        // Any real death is a hard per-life weapon boundary, even outside an active arena round.
        customWeaponCombat.forget(victim);
        if (!arenaDeath) {
            damage.clear(victim.getUUID());
            return;
        }
        players.onDeath(victim);
        if (killer != null && killer != victim && players.session(killer).state() == arena.forge.player.ArenaPlayerState.ALIVE) {
            int reward = players.rewardKill(killer, victim);
            if (reward > 0) killer.sendSystemMessage(Component.literal("[GA] Kill +$" + reward).withStyle(ChatFormatting.GREEN));
        }
        if (arenaDeath) {
            for (var uuid : assistants) {
                ServerPlayer assistant = victim.getServer() == null ? null : victim.getServer().getPlayerList().getPlayer(uuid);
                if (assistant == null || !isArenaReady(assistant)) continue;
                if (players.session(assistant).state() != arena.forge.player.ArenaPlayerState.ALIVE) continue;
                int reward = players.rewardAssist(assistant);
                if (reward > 0) assistant.sendSystemMessage(Component.literal("[GA] Assist +$" + reward).withStyle(ChatFormatting.YELLOW));
            }
        }
    }

    private static ServerPlayer resolvePlayerAttacker(DamageSource source) {
        if (source.getEntity() instanceof ServerPlayer player) return player;
        if (source.getDirectEntity() instanceof Projectile projectile && projectile.getOwner() instanceof ServerPlayer player) return player;
        return null;
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!isArenaReady(player)) return;
        MinecraftServer server = player.getServer();
        deathGuard.onRespawn(player.getUUID());
        damage.clear(player.getUUID());
        customWeaponCombat.forget(player);
        if (server != null) players.onRespawn(server, player, rounds.state(), serverTick);
    }

    @SubscribeEvent
    public void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer victim)) return;
        ServerPlayer sourcePlayer = resolvePlayerAttacker(event.getSource());
        if (!isArenaReady(victim) || (sourcePlayer != null && !isArenaReady(sourcePlayer))) {
            event.setCanceled(true);
            return;
        }
        // Safe-region combat fence: neither attacks into nor out of lobby are allowed.
        if (safeRegions.isSafe(victim) || (sourcePlayer != null && safeRegions.isSafe(sourcePlayer))) {
            event.setCanceled(true);
            return;
        }
        if (players.isProtected(victim, serverTick)) {
            event.setCanceled(true);
            return;
        }
        ServerPlayer attacker = sourcePlayer;
        if (attacker != null && players.isProtected(attacker, serverTick)) {
            // First offensive action consumes protection and cannot deal damage itself.
            // resolvePlayerAttacker also covers projectile/JEG-style indirect sources.
            players.clearProtection(attacker);
            event.setCanceled(true);
        }
    }


    /**
     * Defense in depth for SAuth: before authentication a player may only use
     * /login and /register. This is intentionally enforced in Gunner Arena too,
     * so a future SAuth regression cannot expose /play, /buy, /spawn, admin UI,
     * or other gameplay commands before authentication.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onCommand(CommandEvent event) {
        Object sourceObj = event.getParseResults().getContext().getSource();
        if (!(sourceObj instanceof net.minecraft.commands.CommandSourceStack source)) return;
        if (!(source.getEntity() instanceof ServerPlayer player)) return;
        if (auth.isAuthenticated(player)) return;

        String raw = event.getParseResults().getReader().getString().trim();
        if (raw.startsWith("/")) raw = raw.substring(1);
        String root = raw.isEmpty() ? "" : raw.split("\\s+", 2)[0].toLowerCase(java.util.Locale.ROOT);
        if (root.equals("login") || root.equals("register")) return;

        event.setCanceled(true);
        auth.deny(player);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onBreakBlock(BlockEvent.BreakEvent event) {
        if (event.getPlayer() instanceof ServerPlayer player && (!auth.isAuthenticated(player) || safeRegions.isSafe(player))) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (event.getEntity() instanceof ServerPlayer player && (!auth.isAuthenticated(player) || safeRegions.isSafe(player))) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (event.getEntity() instanceof ServerPlayer player && (!auth.isAuthenticated(player) || safeRegions.isSafe(player))) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!auth.isAuthenticated(player)) { event.setCanceled(true); return; }
        if (isQuarantined(event.getItemStack())) {
            event.setCanceled(true);
            player.sendSystemMessage(Component.literal("[GA] Это оружие отключено: риск падения dedicated server.").withStyle(ChatFormatting.RED));
            return;
        }
        if (event.getItemStack().getItem() instanceof ArenaWeaponItem) {
            if (!isCustomCombatAllowed(player)) {
                event.setCanceled(true);
                player.displayClientMessage(Component.literal("✦ Сейчас стрелять нельзя.").withStyle(ChatFormatting.YELLOW), true);
                return;
            }
            if (player.isCrouching()) {
                event.setCanceled(true);
                var changed = customWeaponCombat.cycleMode(player);
                player.displayClientMessage(Component.literal(changed.message()).withStyle(ChatFormatting.AQUA), true);
                return;
            }
        }
        if (safeRegions.isSafe(player) && forgeLoadouts.isArenaBound(event.getItemStack())) {
            event.setCanceled(true);
            player.sendSystemMessage(Component.literal("✦ Безопасная зона — оружие здесь отключено.").withStyle(ChatFormatting.YELLOW));
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getEntity() instanceof ServerPlayer player && (!auth.isAuthenticated(player) || safeRegions.isSafe(player))) event.setCanceled(true);
    }

    /**
     * Hard safe-zone projectile fence. JEG can fire through custom network handlers that do not
     * necessarily pass through RightClickItem, so cancel the projectile itself when its owner
     * is unauthenticated or standing in a safe region. This avoids depending on JEG internals.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (!(event.getEntity() instanceof Projectile projectile)) return;

        // Confirmed JEG 0.13.2 dedicated-server crash guard.
        // FlareProjectileEntity#onProjectileTick tries to load ClientLevel on DEDICATED_SERVER.
        // Cancel the entity before its first world tick regardless of how it was spawned
        // (/give, JEG custom packet, command, legacy inventory, etc.).
        if (isQuarantinedProjectile(projectile)) {
            event.setCanceled(true);
            if (projectile.getOwner() instanceof ServerPlayer owner) {
                owner.sendSystemMessage(Component.literal("[GA] Flare Gun отключён: его снаряд аварийно ломает dedicated server.").withStyle(ChatFormatting.RED));
            }
            return;
        }

        if (!(projectile.getOwner() instanceof ServerPlayer owner)) return;
        if (!auth.isAuthenticated(owner) || safeRegions.isSafe(owner)) {
            event.setCanceled(true);
            if (safeRegions.isSafe(owner)) {
                owner.displayClientMessage(Component.literal("✦ Безопасная зона — стрельба отключена.").withStyle(ChatFormatting.YELLOW), true);
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onPickup(EntityItemPickupEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && (!auth.isAuthenticated(player) || safeRegions.isSafe(player))) event.setCanceled(true);
    }

    @SubscribeEvent
    public void onItemToss(ItemTossEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player)) return;
        if (!auth.isAuthenticated(player) || safeRegions.isSafe(player)) {
            event.setCanceled(true);
            return;
        }
        var stack = event.getEntity().getItem();
        if (forgeLoadouts.isArenaBound(stack)) {
            event.setCanceled(true);
            player.sendSystemMessage(Component.literal("[GA] Боевые предметы Gunner Arena нельзя выбрасывать.").withStyle(ChatFormatting.YELLOW));
        }
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        serverTick++;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!auth.isAuthenticated(player)) {
                // Freeze at the configured Gunner Arena lobby, not at the arbitrary join coordinate.
                // SAuth 2.1 also blocks commands/interactions; this is a second server-side fence.
                if (serverTick % 5L == 0L) auth.enforceLobby(server, player, spawns);
                continue;
            }
            if (!auth.isInitialized(player)) {
                players.onLogin(player);
                auth.markInitialized(player);
                player.refreshTabListName();
                server.getPlayerList().broadcastSystemMessage(prefixes.joinMessage(player), false);
                player.sendSystemMessage(Component.literal("[GA] Авторизация подтверждена. Можно играть.").withStyle(ChatFormatting.GREEN));
            }
            if (serverTick % 20L == 0L) purgeQuarantined(player);
            if (serverTick % 100L == 0L) player.refreshTabListName();
            // Recovery fence: a malformed teleport, map hole or void fall must not strand an
            // authenticated player below the playable world. Recover to the configured lobby,
            // clear velocity/fire/fall damage and heal. This is deliberately server-authoritative.
            if (needsVoidRecovery(player)) {
                recoverToLobby(server, player);
                continue;
            }

            var transition = safePresence.update(player.getUUID(), safeRegions.isSafe(player));
            if (transition == SafeRegionPresenceTracker.Transition.ENTERED) {
                player.displayClientMessage(Component.literal("✦ БЕЗОПАСНАЯ ЗОНА • оружие отключено").withStyle(ChatFormatting.AQUA), true);
                player.setHealth(player.getMaxHealth());
                player.clearFire();
            } else if (transition == SafeRegionPresenceTracker.Transition.LEFT) {
                player.displayClientMessage(Component.literal("⚔ БОЕВАЯ ЗОНА").withStyle(ChatFormatting.RED), true);
            }

            var customShot = customWeaponCombat.tick(player, isCustomCombatAllowed(player), serverTick * 50L);
            if (customShot.fired()) {
                players.recordShot(player, customShot.hit());
                customWeaponCombat.showAmmo(player, serverTick * 50L);
                if (customShot.headshot()) {
                    player.displayClientMessage(Component.literal("✦ HEADSHOT").withStyle(ChatFormatting.GOLD), true);
                }
            }
        }
        // Autofill orchestration reserves 0/2/4 AI Gunner identities based on REAL players only.
        // The server never counts authenticated bot clients as human population.
        if (serverTick % 20L == 0L) {
            int realPlayers = 0;
            for (ServerPlayer online : server.getPlayerList().getPlayers()) {
                if (!online.getTags().contains("gunnerarena_bot")) realPlayers++;
            }
            bots.tick(realPlayers, serverTick);
        }

        safeRegions.tickVisualization(server, serverTick);
        hazards.cleanup(serverTick);
        if (serverTick % (20L * 30L) == 0L) damage.pruneExpired(serverTick);
        hazardExecutor.tick(server, hazards, serverTick, player -> isArenaReady(player) && !safeRegions.isSafe(player));
        if (serverTick % (20L * 30L) == 0) players.saveDirtyProfiles();
        ServerLevel level = server.overworld();
        ammoPoints.tick(server, players, rounds.state(), serverTick);

        if (rounds.state() == RoundState.PLAYING) {
            rounds.tickPlaying();
            if (rounds.remainingTicks() <= 0) beginRegeneration(level);
        } else if (rounds.state() == RoundState.WAITING) {
            if (pendingRoundStartAtTick >= 0L && serverTick >= pendingRoundStartAtTick) {
                pendingRoundStartAtTick = -1L;
                forceStartRound();
            }
        } else if (rounds.state() == RoundState.REGENERATING) {
            if (!triggerIssued) {
                cgBeta.trigger(level);
                triggerIssued = true;
            }
            CGBetaSnapshot snapshot = cgBeta.snapshot(server, level);
            CGBetaRegenerator.State gs = rounds.generator().update(snapshot, serverTick);
            rounds.onGeneratorState(gs);
            if (rounds.state() == RoundState.WAITING && gs == CGBetaRegenerator.State.READY) {
                triggerIssued = false;
                // Five-second pre-round grace period after the generator really reports READY.
                pendingRoundStartAtTick = serverTick + 20L * 5L;
            }
        }
    }


    @SubscribeEvent
    public void onServerStopping(ServerStoppingEvent event) {
        deathGuard.clear();
        damage.clearAll();
        hazards.clear();
        hazardExecutor.clearRuntime();
        safePresence.clear();
        customWeaponCombat.clearAll();
        bots.clear();
        players.saveAllProfiles();
    }

    public void beginRegeneration(ServerLevel level) {
        MinecraftServer server = level.getServer();
        players.onRoundStopped(server, this::isArenaReady);
        damage.clearAll();
        deathGuard.clear();
        hazards.clear();
        hazardExecutor.clearRuntime();
        ammoPoints.resetCooldowns();
        customWeaponCombat.clearAll();
        rounds.beginRegeneration(serverTick);
        triggerIssued = false;
        pendingRoundStartAtTick = -1L;
    }

    public void forceStartRound() {
        // A new round is a hard combat-evidence boundary: no prior hit/death state may leak in.
        damage.clearAll();
        deathGuard.clear();
        customWeaponCombat.clearAll();
        rounds.startPlaying();
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) {
            ammoPoints.resetCooldowns();
            players.onRoundStarted(server, rounds.roundNumber(), serverTick, this::isArenaReady);
        }
    }

    public RoundManager rounds() { return rounds; }
    public WeaponCatalog weapons() { return weapons; }
    public CGBetaForgeAdapter cgBeta() { return cgBeta; }
    public SpawnManager spawns() { return spawns; }
    public ArenaPlayerManager players() { return players; }
    public CurrencyService currency() { return currency; }
    public LoadoutManager loadouts() { return loadouts; }
    public ForgeLoadoutService forgeLoadouts() { return forgeLoadouts; }
    public DamageTracker damageTracker() { return damage; }
    public ForgeAmmoPointService ammoPoints() { return ammoPoints; }
    public ProfileService profiles() { return profiles; }
    public LegacyCleanupService legacyCleanup() { return legacyCleanup; }
    public AuthGate auth() { return auth; }
    public SafeRegionService safeRegions() { return safeRegions; }
    public HazardManager hazards() { return hazards; }
    public ForgePrefixService prefixes() { return prefixes; }
    public BotDirector bots() { return bots; }
    public RpgService rpg() { return rpg; }
    public long serverTick() { return serverTick; }

    public ForgeCustomWeaponCombatService customWeaponCombat() { return customWeaponCombat; }

    public boolean isCustomCombatAllowed(ServerPlayer player) {
        if (player == null) return false;
        return CustomWeaponCombatPolicy.decide(
            auth.isAuthenticated(player),
            auth.isInitialized(player),
            rounds.state() == RoundState.PLAYING,
            auth.isInitialized(player) && players.session(player).state() == arena.forge.player.ArenaPlayerState.ALIVE,
            safeRegions.isSafe(player)
        ).allowed();
    }

    /** Builds a read-only server-authoritative snapshot for the optional client UI. */
    public ArenaSnapshot createSnapshot(ServerPlayer player) {
        boolean authenticated = player != null && auth.isAuthenticated(player);
        boolean initialized = player != null && auth.isInitialized(player);
        String name = player == null ? "" : player.getGameProfile().getName();
        if (!authenticated || !initialized) {
            return ArenaSnapshot.unauthenticated(name, rounds.state().name(), rounds.roundNumber(), rounds.remainingTicks());
        }
        var profile = players.profile(player);
        var round = players.roundSession(player);
        if (profile == null || round == null) {
            return new ArenaSnapshot(true, false, name, rounds.state().name(), rounds.roundNumber(), rounds.remainingTicks(),
                0, 0, 0, 1, 0, 0,
                0, 0, 0, 0, 0, 0, 0,
                0, 0, 0,
                0, 0, 0, 0);
        }
        return new ArenaSnapshot(true, true, name, rounds.state().name(), rounds.roundNumber(), rounds.remainingTicks(),
            round.credits(), profile.coins, profile.crystals, profile.level, profile.xp, profile.skillPoints,
            profile.kills, profile.deaths, profile.assists, profile.damageDealt, profile.shotsFired, profile.shotsHit,
            profile.bestKillStreak, profile.roundsPlayed, profile.roundsWon, profile.playTimeSeconds,
            round.roundKills(), round.roundDeaths(), round.roundAssists(), round.roundDamage());
    }

    /** A player is gameplay-ready only after SAuth AND the Arena profile/session bridge completed. */
    private boolean isArenaReady(ServerPlayer player) {
        return player != null && auth.isAuthenticated(player) && auth.isInitialized(player);
    }

    private boolean needsVoidRecovery(ServerPlayer player) {
        if (player == null) return false;
        double x = player.getX(), y = player.getY(), z = player.getZ();
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) return true;
        int min = player.serverLevel().getMinBuildHeight();
        return y < min - 16.0D;
    }

    private void recoverToLobby(MinecraftServer server, ServerPlayer player) {
        boolean teleported = spawns.lobby().map(point -> spawns.teleport(server, player, point)).orElse(false);
        player.clearFire();
        player.fallDistance = 0.0F;
        player.setDeltaMovement(0.0D, 0.0D, 0.0D);
        player.setHealth(player.getMaxHealth());
        if (teleported) {
            player.displayClientMessage(Component.literal("✦ Восстановление: возвращаем на безопасный спавн.").withStyle(ChatFormatting.AQUA), true);
        } else {
            player.sendSystemMessage(Component.literal("[GA] Не удалось восстановить игрока: lobby spawn не установлен (/setspawn).").withStyle(ChatFormatting.RED));
        }
    }

    private static boolean isQuarantinedProjectile(Projectile projectile) {
        // Do not reference FlareProjectileEntity.class directly: keeping this as a class-name
        // comparison prevents Gunner Arena itself from acquiring a hard JEG linkage.
        return projectile != null
            && "ttv.migami.jeg.entity.projectile.FlareProjectileEntity".equals(projectile.getClass().getName());
    }

    private static boolean isQuarantined(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
        return id != null && WeaponSafetyPolicy.isQuarantined(id.toString());
    }

    private static void purgeQuarantined(ServerPlayer player) {
        int removed = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (isQuarantined(stack)) { removed += stack.getCount(); stack.setCount(0); }
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (isQuarantined(stack)) { removed += stack.getCount(); stack.setCount(0); }
        }
        if (removed > 0) {
            player.sendSystemMessage(Component.literal("[GA] Удалено опасное оружие из quarantine: " + removed).withStyle(ChatFormatting.RED));
        }
    }

    public CGBetaSnapshot currentSnapshot() {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return new CGBetaSnapshot(0,0,0,0,0,0,0,0,false);
        return cgBeta.snapshot(server, server.overworld());
    }
}

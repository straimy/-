package arena.forge.item;

import java.util.Set;

/** Combat readiness gate for registered Gunner Arena weapon items. */
public final class CustomWeaponAvailability {
    private static final Set<String> REGISTERED_CUSTOM = Set.of(
        "gunnerarena:p9", "gunnerarena:px18", "gunnerarena:vkr47", "gunnerarena:raven_m96"
    );
    private static final Set<String> COMBAT_READY = Set.of(
        "gunnerarena:p9", "gunnerarena:px18", "gunnerarena:vkr47", "gunnerarena:raven_m96"
    );

    private CustomWeaponAvailability() {}
    public static boolean isRegisteredCustom(String id) { return REGISTERED_CUSTOM.contains(id); }
    public static boolean isCombatReady(String id) { return !isRegisteredCustom(id) || COMBAT_READY.contains(id); }
}

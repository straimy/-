package arena.forge.item;

import arena.GunnerArenaMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Forge item registration for the first four custom arena weapons. */
public final class GunnerArenaItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, GunnerArenaMod.MODID);

    public static final RegistryObject<Item> P9 = ITEMS.register("p9", () -> new ArenaWeaponItem("gunnerarena:p9"));
    public static final RegistryObject<Item> PX18 = ITEMS.register("px18", () -> new ArenaWeaponItem("gunnerarena:px18"));
    public static final RegistryObject<Item> VKR47 = ITEMS.register("vkr47", () -> new ArenaWeaponItem("gunnerarena:vkr47"));
    public static final RegistryObject<Item> RAVEN_M96 = ITEMS.register("raven_m96", () -> new ArenaWeaponItem("gunnerarena:raven_m96"));

    private GunnerArenaItems() {}
    public static void register(IEventBus modBus) { ITEMS.register(modBus); }
}

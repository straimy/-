package arena.forge.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import java.util.List;

/** Registered backing item for a Gunner Arena custom weapon. Combat is still server-authoritative. */
public final class ArenaWeaponItem extends Item {
    private final String weaponId;

    public ArenaWeaponItem(String weaponId) {
        super(new Item.Properties().stacksTo(1));
        this.weaponId = weaponId;
    }

    public String weaponId() { return weaponId; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public int getUseDuration(ItemStack stack) { return 72000; }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("KVICloud • Gunner Arena"));
        tooltip.add(Component.literal("ID: " + weaponId));
        tooltip.add(Component.literal("Стрельба управляется сервером"));
    }
}

package arena.forge;

import arena.region.CuboidRegion;
import arena.region.SafeRegionRegistry;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import net.minecraft.core.particles.ParticleTypes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Forge-facing admin selection + lookup service for persistent safe regions. */
public final class SafeRegionService {
    private final SafeRegionRegistry registry;
    private final Map<UUID, Selection> selections = new HashMap<>();
    private final Map<String, Long> visualizeUntil = new HashMap<>();

    public SafeRegionService(SafeRegionRegistry registry) {
        this.registry = registry;
    }

    public void setPos1(ServerPlayer player) {
        selection(player).a = point(player);
    }

    public void setPos2(ServerPlayer player) {
        selection(player).b = point(player);
    }

    public CuboidRegion create(ServerPlayer player, String id) {
        Selection s = selection(player);
        if (s.a == null || s.b == null) throw new IllegalStateException("Select pos1 and pos2 first");
        if (!s.a.dimension.equals(s.b.dimension)) throw new IllegalStateException("Selection points must be in one dimension");
        CuboidRegion region = new CuboidRegion(id, s.a.dimension,
            s.a.x, s.a.y, s.a.z, s.b.x, s.b.y, s.b.z);
        registry.put(region);
        return region;
    }

    public boolean remove(String id) {
        visualizeUntil.remove(id);
        return registry.remove(id);
    }
    public SafeRegionRegistry registry() { return registry; }

    public boolean show(String id, long nowTick, int seconds) {
        if (registry.all().stream().noneMatch(r -> r.id().equals(id))) return false;
        visualizeUntil.put(id, nowTick + Math.max(1, seconds) * 20L);
        return true;
    }

    public int visualizedCount(long nowTick) {
        visualizeUntil.entrySet().removeIf(e -> e.getValue() <= nowTick);
        return visualizeUntil.size();
    }

    public void tickVisualization(MinecraftServer server, long nowTick) {
        visualizeUntil.entrySet().removeIf(e -> e.getValue() <= nowTick);
        if (visualizeUntil.isEmpty() || nowTick % 5L != 0L) return;
        for (CuboidRegion r : registry.all()) {
            if (!visualizeUntil.containsKey(r.id())) continue;
            ServerLevel level = findLevel(server, r.dimension());
            if (level == null) continue;
            drawBox(level, r);
        }
    }

    private static ServerLevel findLevel(MinecraftServer server, String dimension) {
        for (ServerLevel level : server.getAllLevels()) {
            if (level.dimension().location().toString().equals(dimension)) return level;
        }
        return null;
    }

    private static void drawBox(ServerLevel level, CuboidRegion r) {
        double minX = Math.min(r.minX(), r.maxX()), maxX = Math.max(r.minX(), r.maxX());
        double minY = Math.min(r.minY(), r.maxY()), maxY = Math.max(r.minY(), r.maxY());
        double minZ = Math.min(r.minZ(), r.maxZ()), maxZ = Math.max(r.minZ(), r.maxZ());
        double step = 1.25D;
        for (double x = minX; x <= maxX + 0.001; x += step) {
            edge(level, x, minY, minZ); edge(level, x, minY, maxZ);
            edge(level, x, maxY, minZ); edge(level, x, maxY, maxZ);
        }
        for (double z = minZ; z <= maxZ + 0.001; z += step) {
            edge(level, minX, minY, z); edge(level, maxX, minY, z);
            edge(level, minX, maxY, z); edge(level, maxX, maxY, z);
        }
        for (double y = minY; y <= maxY + 0.001; y += step) {
            edge(level, minX, y, minZ); edge(level, minX, y, maxZ);
            edge(level, maxX, y, minZ); edge(level, maxX, y, maxZ);
        }
    }

    private static void edge(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    public CuboidRegion containing(ServerPlayer player) {
        return registry.containing(dimension(player), player.getX(), player.getY(), player.getZ());
    }

    public boolean isSafe(ServerPlayer player) { return containing(player) != null; }

    private Selection selection(ServerPlayer player) {
        return selections.computeIfAbsent(player.getUUID(), ignored -> new Selection());
    }

    private static Point point(ServerPlayer p) {
        return new Point(dimension(p), p.getX(), p.getY(), p.getZ());
    }

    private static String dimension(ServerPlayer p) {
        return p.level().dimension().location().toString();
    }

    private static final class Selection { Point a; Point b; }
    private record Point(String dimension, double x, double y, double z) {}
}

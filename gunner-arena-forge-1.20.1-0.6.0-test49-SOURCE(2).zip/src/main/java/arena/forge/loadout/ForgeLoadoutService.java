package arena.forge.loadout;

import arena.loadout.LoadoutManager;
import arena.forge.item.CustomWeaponAvailability;
import arena.profile.RoundSession;
import arena.weapon.WeaponCatalog;
import arena.weapon.WeaponDefinition;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Bridges the pure loadout/economy core to real Minecraft/JEG ItemStacks. */
public final class ForgeLoadoutService {
    public static final int KNIFE_SLOT = 0;
    public static final int SECONDARY_SLOT = 1;
    public static final int PRIMARY_SLOT = 2;
    private static final String KNIFE_TAG = "GunnerArenaKnife";
    private static final String BOUND_TAG = "GunnerArenaBound";

    private final WeaponCatalog catalog;
    private final LoadoutManager loadouts;

    public ForgeLoadoutService(WeaponCatalog catalog, LoadoutManager loadouts) {
        this.catalog = catalog;
        this.loadouts = loadouts;
    }

    public void giveKnife(ServerPlayer player) {
        ItemStack knife = new ItemStack(Items.IRON_SWORD);
        knife.setHoverName(Component.literal("Тактический нож").withStyle(ChatFormatting.AQUA));
        knife.getOrCreateTag().putBoolean("Unbreakable", true);
        knife.getOrCreateTag().putBoolean(KNIFE_TAG, true);
        knife.getOrCreateTag().putBoolean(BOUND_TAG, true);
        player.getInventory().setItem(KNIFE_SLOT, knife);
    }

    public boolean isArenaKnife(ItemStack stack) {
        return !stack.isEmpty() && stack.hasTag() && stack.getTag().getBoolean(KNIFE_TAG);
    }

    public boolean isArenaBound(ItemStack stack) {
        return !stack.isEmpty() && stack.hasTag() && stack.getTag().getBoolean(BOUND_TAG);
    }

    /** True only when the weapon definition exists and its backing item is registered on this server. */
    public boolean isAvailable(String weaponId) {
        WeaponDefinition def = catalog.get(weaponId);
        return def != null && registeredItem(def.id()) != null && CustomWeaponAvailability.isCombatReady(def.id());
    }

    /**
     * Performs server-authoritative purchase in the pure core, then materializes the registered item.
     * Planned GunnerArena weapons intentionally fail until their actual items are registered later.
     */
    public LoadoutManager.BuyResult buyAndGive(ServerPlayer player, RoundSession session, String weaponId) {
        WeaponDefinition def = catalog.get(weaponId);
        if (def == null) return LoadoutManager.BuyResult.UNKNOWN_WEAPON;
        Item item = registeredItem(def.id());
        if (item == null) return LoadoutManager.BuyResult.UNAVAILABLE_ITEM;

        LoadoutManager.BuyResult result = loadouts.buy(session, weaponId);
        if (result != LoadoutManager.BuyResult.OK) return result;
        ItemStack weapon = new ItemStack(item);
        weapon.getOrCreateTag().putBoolean(BOUND_TAG, true);
        putWeapon(player, def, weapon);
        ensureAmmo(player, def.ammoItem(), def.startingReserve());
        return result;
    }

    public void restoreAfterRespawn(ServerPlayer player, RoundSession session) {
        giveKnife(player);
        loadouts.onRespawn(session);
        restoreWeapon(player, session.secondaryWeapon());
        restoreWeapon(player, session.primaryWeapon());
    }

    public void clearCombatSlots(ServerPlayer player) {
        // Remove every arena-bound combat item, not only the expected three hotbar slots.
        // This closes simple inventory-move duplication between rounds.
        for (ItemStack stack : player.getInventory().items) {
            if (isArenaBound(stack)) stack.setCount(0);
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (isArenaBound(stack)) stack.setCount(0);
        }
        player.getInventory().setItem(KNIFE_SLOT, ItemStack.EMPTY);
        player.getInventory().setItem(SECONDARY_SLOT, ItemStack.EMPTY);
        player.getInventory().setItem(PRIMARY_SLOT, ItemStack.EMPTY);
        clearManagedAmmo(player);
    }

    private void restoreWeapon(ServerPlayer player, String weaponId) {
        if (weaponId == null || weaponId.isBlank()) return;
        WeaponDefinition def = catalog.get(weaponId);
        if (def == null) return;
        Item item = registeredItem(def.id());
        if (item == null) return;
        ItemStack weapon = new ItemStack(item);
        weapon.getOrCreateTag().putBoolean(BOUND_TAG, true);
        putWeapon(player, def, weapon);
        ensureAmmo(player, def.ammoItem(), Math.max(1, def.magazineSize()));
    }

    private void putWeapon(ServerPlayer player, WeaponDefinition def, ItemStack stack) {
        int slot = def.slot() == WeaponDefinition.Slot.PRIMARY ? PRIMARY_SLOT : SECONDARY_SLOT;
        player.getInventory().setItem(slot, stack);
    }

    private void ensureAmmo(ServerPlayer player, String ammoId, int minimum) {
        if (ammoId == null || ammoId.isBlank() || minimum <= 0) return;
        Item ammo = registeredItem(ammoId);
        if (ammo == null) return;
        int existing = countItem(player, ammo);
        int missing = minimum - existing;
        if (missing <= 0) return;
        while (missing > 0) {
            int stackSize = Math.min(missing, ammo.getMaxStackSize());
            ItemStack stack = new ItemStack(ammo, stackSize);
            player.getInventory().add(stack);
            // Never drop arena ammo on the ground if the inventory is full.
            if (!stack.isEmpty()) break;
            missing -= stackSize;
        }
    }

    private void clearManagedAmmo(ServerPlayer player) {
        java.util.Set<Item> managed = new java.util.HashSet<>();
        for (WeaponDefinition def : catalog.all()) {
            if (def.ammoItem() == null || def.ammoItem().isBlank()) continue;
            Item item = registeredItem(def.ammoItem());
            if (item != null) managed.add(item);
        }
        for (ItemStack stack : player.getInventory().items) if (managed.contains(stack.getItem())) stack.setCount(0);
        for (ItemStack stack : player.getInventory().offhand) if (managed.contains(stack.getItem())) stack.setCount(0);
    }

    private static int countItem(ServerPlayer player, Item item) {
        int count = 0;
        for (ItemStack stack : player.getInventory().items) if (stack.is(item)) count += stack.getCount();
        for (ItemStack stack : player.getInventory().offhand) if (stack.is(item)) count += stack.getCount();
        return count;
    }

    private static Item registeredItem(String id) {
        ResourceLocation key = ResourceLocation.tryParse(id);
        if (key == null || !BuiltInRegistries.ITEM.containsKey(key)) return null;
        Item item = BuiltInRegistries.ITEM.get(key);
        return item == Items.AIR ? null : item;
    }
}

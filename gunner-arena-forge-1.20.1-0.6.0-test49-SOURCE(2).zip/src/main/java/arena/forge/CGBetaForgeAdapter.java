package arena.forge;

import arena.round.CGBetaSnapshot;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;

import java.util.List;

/** Typed Minecraft/Forge bridge for the command-block generator in CG BETA. */
public final class CGBetaForgeAdapter {
    public static final BlockPos GENERATOR_TRIGGER = new BlockPos(44, 63, 3);
    private static final AABB GENERATOR_SCAN = new AABB(0, -64, 0, 160, 320, 160);

    public void trigger(ServerLevel level) {
        // Pulse the actual CG BETA redstone input. Clearing it first guarantees a fresh
        // neighbour update even if a previous generation left the trigger powered.
        level.setBlockAndUpdate(GENERATOR_TRIGGER, Blocks.AIR.defaultBlockState());
        level.setBlockAndUpdate(GENERATOR_TRIGGER, Blocks.REDSTONE_BLOCK.defaultBlockState());
    }

    public CGBetaSnapshot snapshot(MinecraftServer server, ServerLevel level) {
        int chunks = score(server, "#cg_chunk_count", "data");
        int empty = score(server, "#empty_cg_chunks_count", "data");
        int emptyMax = score(server, "#empty_cg_chunks_max", "data");
        int guns = score(server, "#gun_cg_chunks_count", "data");
        int gunsMax = score(server, "#gun_cg_chunks_max", "data");
        int health = score(server, "#s_health_cg_chunks_count", "data");
        int healthMax = score(server, "#s_health_cg_chunks_max", "data");

        List<? extends Entity> markers = level.getEntities(EntityType.MARKER, GENERATOR_SCAN,
            e -> e.getTags().contains("cg_random_chunk"));
        int unfinished = 0;
        for (Entity marker : markers) {
            if (!marker.getTags().contains("filled")) unfinished++;
        }
        boolean hasGeneratorMarkers = !markers.isEmpty();
        return new CGBetaSnapshot(chunks, empty, emptyMax, guns, gunsMax, health, healthMax, unfinished, hasGeneratorMarkers);
    }

    private static int score(MinecraftServer server, String holder, String objectiveName) {
        Scoreboard scoreboard = server.getScoreboard();
        Objective objective = scoreboard.getObjective(objectiveName);
        if (objective == null) return 0;
        return scoreboard.getOrCreatePlayerScore(holder, objective).getScore();
    }
}

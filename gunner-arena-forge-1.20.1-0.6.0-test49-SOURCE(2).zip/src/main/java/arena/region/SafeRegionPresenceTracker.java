package arena.region;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Tracks per-player safe-zone enter/leave transitions without depending on Forge. */
public final class SafeRegionPresenceTracker {
    public enum Transition { NONE, ENTERED, LEFT }

    private final Map<UUID, Boolean> safe = new HashMap<>();

    public synchronized Transition update(UUID playerId, boolean nowSafe) {
        Boolean before = safe.put(playerId, nowSafe);
        if (before == null) return nowSafe ? Transition.ENTERED : Transition.NONE;
        if (!before && nowSafe) return Transition.ENTERED;
        if (before && !nowSafe) return Transition.LEFT;
        return Transition.NONE;
    }

    public synchronized void forget(UUID playerId) {
        safe.remove(playerId);
    }

    public synchronized void clear() {
        safe.clear();
    }
}

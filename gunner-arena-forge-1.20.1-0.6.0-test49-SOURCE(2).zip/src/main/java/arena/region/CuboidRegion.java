package arena.region;

/** Pure-data axis-aligned region used by the Forge SafeRegion adapter. */
public record CuboidRegion(String id, String dimension,
                           double minX, double minY, double minZ,
                           double maxX, double maxY, double maxZ) {
    public CuboidRegion {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("id");
        if (dimension == null || dimension.isBlank()) throw new IllegalArgumentException("dimension");
        double aMinX = Math.min(minX, maxX), aMaxX = Math.max(minX, maxX);
        double aMinY = Math.min(minY, maxY), aMaxY = Math.max(minY, maxY);
        double aMinZ = Math.min(minZ, maxZ), aMaxZ = Math.max(minZ, maxZ);
        minX = aMinX; maxX = aMaxX;
        minY = aMinY; maxY = aMaxY;
        minZ = aMinZ; maxZ = aMaxZ;
    }

    public boolean contains(String dimensionId, double x, double y, double z) {
        return dimension.equals(dimensionId)
            && x >= minX && x <= maxX
            && y >= minY && y <= maxY
            && z >= minZ && z <= maxZ;
    }
}

package arena.region;

import java.util.*;

/** Pure region registry; Forge layer owns selections/particles/events. */
public final class SafeRegionRegistry {
    private final SafeRegionStore store;
    private final Map<String, CuboidRegion> regions = new LinkedHashMap<>();
    public SafeRegionRegistry(SafeRegionStore store) {
        this.store = Objects.requireNonNull(store);
        for (CuboidRegion r : store.load()) regions.put(r.id().toLowerCase(Locale.ROOT), r);
    }
    public synchronized CuboidRegion put(CuboidRegion region) {
        regions.put(region.id().toLowerCase(Locale.ROOT), region); persist(); return region;
    }
    public synchronized boolean remove(String id) {
        boolean removed = regions.remove(id.toLowerCase(Locale.ROOT)) != null; if (removed) persist(); return removed;
    }
    public synchronized CuboidRegion get(String id) { return regions.get(id.toLowerCase(Locale.ROOT)); }
    public synchronized List<CuboidRegion> all() { return List.copyOf(regions.values()); }
    public synchronized CuboidRegion containing(String dimension, double x, double y, double z) {
        for (CuboidRegion r : regions.values()) if (r.contains(dimension, x, y, z)) return r;
        return null;
    }
    private void persist() { store.save(regions.values()); }
}

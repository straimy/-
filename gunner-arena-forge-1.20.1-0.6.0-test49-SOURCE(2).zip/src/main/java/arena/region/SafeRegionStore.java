package arena.region;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Atomic persistent storage for admin-defined safe regions. */
public final class SafeRegionStore {
    private final Path file;
    public SafeRegionStore(Path file) { this.file = Objects.requireNonNull(file); }

    public List<CuboidRegion> load() {
        if (!Files.isRegularFile(file)) return List.of();
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) { p.load(in); }
        catch (IOException e) { throw new IllegalStateException("Failed to read " + file, e); }
        int count = parseInt(p.getProperty("region.count"), 0);
        List<CuboidRegion> out = new ArrayList<>();
        for (int i = 0; i < count; i++) parse(p.getProperty("region." + i)).ifPresent(out::add);
        return List.copyOf(out);
    }

    public synchronized void save(Collection<CuboidRegion> regions) {
        Properties p = new Properties();
        List<CuboidRegion> list = List.copyOf(regions);
        p.setProperty("region.count", Integer.toString(list.size()));
        for (int i = 0; i < list.size(); i++) p.setProperty("region." + i, format(list.get(i)));
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) { p.store(out, "Gunner Arena safe regions"); }
            try { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (IOException unsupported) { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException e) { throw new IllegalStateException("Failed to write " + file, e); }
    }

    private static String format(CuboidRegion r) {
        return String.join(";", r.id(), r.dimension(),
            Double.toString(r.minX()), Double.toString(r.minY()), Double.toString(r.minZ()),
            Double.toString(r.maxX()), Double.toString(r.maxY()), Double.toString(r.maxZ()));
    }
    private static Optional<CuboidRegion> parse(String raw) {
        if (raw == null || raw.isBlank()) return Optional.empty();
        try {
            String[] s = raw.split(";");
            if (s.length != 8) return Optional.empty();
            return Optional.of(new CuboidRegion(s[0], s[1],
                Double.parseDouble(s[2]), Double.parseDouble(s[3]), Double.parseDouble(s[4]),
                Double.parseDouble(s[5]), Double.parseDouble(s[6]), Double.parseDouble(s[7])));
        } catch (RuntimeException e) { return Optional.empty(); }
    }
    private static int parseInt(String s, int fallback) { try { return Integer.parseInt(s); } catch (RuntimeException e) { return fallback; } }
}

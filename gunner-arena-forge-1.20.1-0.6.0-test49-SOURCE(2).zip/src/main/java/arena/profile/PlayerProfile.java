package arena.profile;

import java.util.*;

public final class PlayerProfile {
    public static final int DATA_VERSION = 2;
    public int dataVersion = DATA_VERSION;
    public UUID uuid;
    public String lastKnownName = "";

    public long coins;
    public long crystals;
    public long lifetimeCredits;

    public int level = 1;
    public long xp;
    public int skillPoints;
    public int prestige;
    public String specialization = "NONE";

    public long kills;
    public long deaths;
    public long assists;
    public long damageDealt;
    public long shotsFired;
    public long shotsHit;
    public int bestKillStreak;
    public long roundsPlayed;
    public long roundsWon;
    public long playTimeSeconds;

    public final Set<String> unlockedSkills = new LinkedHashSet<>();
    public final Map<String, WeaponMastery> weaponMastery = new LinkedHashMap<>();

    public static final class WeaponMastery {
        public long xp;
        public int level;
        public long kills;
        public long shots;
        public long hits;
        public long headshots;
    }
}

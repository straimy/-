package arena.profile;

import arena.economy.CurrencyService;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Owns persistent profiles and volatile per-round sessions. */
public final class ProfileService {
    private final ProfileStorage storage;
    private final CurrencyService currency;
    private final Map<UUID, PlayerProfile> profiles = new ConcurrentHashMap<>();
    private final Map<UUID, RoundSession> rounds = new ConcurrentHashMap<>();
    private final Set<UUID> dirty = ConcurrentHashMap.newKeySet();
    private final Set<UUID> retainedOffline = ConcurrentHashMap.newKeySet();
    private volatile long saveFailures;

    public ProfileService(ProfileStorage storage, CurrencyService currency) {
        this.storage = storage;
        this.currency = currency;
    }

    public PlayerProfile login(UUID uuid, String name) {
        // If the previous logout could not persist, the in-memory profile is newer than disk.
        // Reuse it rather than silently rolling progression back on a quick reconnect.
        PlayerProfile profile = retainedOffline.remove(uuid) ? profiles.get(uuid) : null;
        if (profile == null) profile = storage.load(uuid, name);
        profile.lastKnownName = name == null ? "" : name;
        profiles.put(uuid, profile);
        rounds.put(uuid, new RoundSession());
        dirty.add(uuid);
        return profile;
    }

    /**
     * Saves before detaching. A failed save deliberately retains the latest profile in memory
     * for autosave/reconnect recovery instead of discarding unsaved progression.
     */
    public boolean logout(UUID uuid) {
        boolean saved = save(uuid);
        rounds.remove(uuid);
        if (saved) {
            profiles.remove(uuid);
            dirty.remove(uuid);
            retainedOffline.remove(uuid);
        } else {
            retainedOffline.add(uuid);
        }
        return saved;
    }

    public PlayerProfile profile(UUID uuid) { return profiles.get(uuid); }
    public RoundSession round(UUID uuid) { return rounds.computeIfAbsent(uuid, ignored -> new RoundSession()); }

    public void resetRound(UUID uuid) {
        currency.resetRound(round(uuid));
    }

    public void markDirty(UUID uuid) { if (profiles.containsKey(uuid)) dirty.add(uuid); }

    public boolean save(UUID uuid) {
        PlayerProfile profile = profiles.get(uuid);
        if (profile == null) return true;
        try {
            storage.save(profile);
            dirty.remove(uuid);
            if (retainedOffline.remove(uuid)) profiles.remove(uuid);
            return true;
        } catch (IOException ex) {
            dirty.add(uuid);
            saveFailures++;
            System.err.println("[GunnerArena] Failed to save profile " + uuid + ": " + ex.getMessage());
            return false;
        }
    }

    public void saveDirty() {
        for (UUID uuid : List.copyOf(dirty)) save(uuid);
    }

    public void saveAll() {
        for (UUID uuid : List.copyOf(profiles.keySet())) save(uuid);
    }

    public int dirtyCount() { return dirty.size(); }
    public long saveFailures() { return saveFailures; }
    public int retainedOfflineCount() { return retainedOffline.size(); }
}

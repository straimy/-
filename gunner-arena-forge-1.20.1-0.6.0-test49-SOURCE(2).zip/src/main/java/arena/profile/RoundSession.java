package arena.profile;

import java.util.LinkedHashMap;
import java.util.Map;

/** Volatile data that is reset at the beginning of each arena round. */
public final class RoundSession {
    private int credits = 500;
    private String primaryWeapon;
    private String secondaryWeapon;
    private final Map<String, Integer> reserveAmmo = new LinkedHashMap<>();
    private int roundKills;
    private int roundDeaths;
    private int roundAssists;
    private long roundDamage;

    public int credits() { return credits; }
    public void setCredits(int value) { credits = Math.max(0, value); }
    public void addCredits(int value) { setCredits(credits + value); }
    public boolean spendCredits(int value) {
        if (value < 0 || credits < value) return false;
        credits -= value;
        return true;
    }

    public String primaryWeapon() { return primaryWeapon; }
    public String secondaryWeapon() { return secondaryWeapon; }
    public void setPrimaryWeapon(String id) { primaryWeapon = id; }
    public void setSecondaryWeapon(String id) { secondaryWeapon = id; }

    public int reserveAmmo(String ammoId) { return reserveAmmo.getOrDefault(ammoId, 0); }
    public void setReserveAmmo(String ammoId, int amount) {
        if (amount <= 0) reserveAmmo.remove(ammoId);
        else reserveAmmo.put(ammoId, amount);
    }
    public Map<String, Integer> reserveAmmoView() { return Map.copyOf(reserveAmmo); }

    public void addKill() { roundKills++; }
    public void addDeath() { roundDeaths++; }
    public void addAssist() { roundAssists++; }
    public void addDamage(long amount) { roundDamage += Math.max(0, amount); }
    public int roundKills() { return roundKills; }
    public int roundDeaths() { return roundDeaths; }
    public int roundAssists() { return roundAssists; }
    public long roundDamage() { return roundDamage; }

    public void resetForNewRound(int startingCredits) {
        credits = Math.max(0, startingCredits);
        primaryWeapon = null;
        secondaryWeapon = null;
        reserveAmmo.clear();
        roundKills = roundDeaths = roundAssists = 0;
        roundDamage = 0;
    }
}

package arena.profile;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Simple dependency-free persistent storage for player progression during TEST3. */
public final class ProfileStorage {
    private final Path directory;

    public ProfileStorage(Path directory) {
        this.directory = directory;
    }

    public PlayerProfile load(UUID uuid, String lastKnownName) {
        PlayerProfile profile = new PlayerProfile();
        profile.uuid = uuid;
        profile.lastKnownName = lastKnownName == null ? "" : lastKnownName;
        Path file = file(uuid);
        if (!Files.exists(file)) return profile;

        Properties p = new Properties();
        try (Reader reader = Files.newBufferedReader(file)) {
            p.load(reader);
        } catch (IOException ex) {
            return profile; // keep a safe empty profile; caller may log the failure later
        }

        profile.dataVersion = intValue(p, "dataVersion", PlayerProfile.DATA_VERSION);
        profile.lastKnownName = p.getProperty("lastKnownName", profile.lastKnownName);
        profile.coins = longValue(p, "coins", 0);
        profile.crystals = longValue(p, "crystals", 0);
        profile.lifetimeCredits = longValue(p, "lifetimeCredits", 0);
        profile.level = Math.max(1, intValue(p, "level", 1));
        profile.xp = longValue(p, "xp", 0);
        profile.skillPoints = Math.max(0, intValue(p, "skillPoints", 0));
        profile.prestige = Math.max(0, intValue(p, "prestige", 0));
        profile.specialization = p.getProperty("specialization", "NONE");
        profile.kills = longValue(p, "kills", 0);
        profile.deaths = longValue(p, "deaths", 0);
        profile.assists = longValue(p, "assists", 0);
        profile.damageDealt = longValue(p, "damageDealt", 0);
        profile.shotsFired = longValue(p, "shotsFired", 0);
        profile.shotsHit = longValue(p, "shotsHit", 0);
        profile.bestKillStreak = intValue(p, "bestKillStreak", 0);
        profile.roundsPlayed = longValue(p, "roundsPlayed", 0);
        profile.roundsWon = longValue(p, "roundsWon", 0);
        profile.playTimeSeconds = longValue(p, "playTimeSeconds", 0);

        String skills = p.getProperty("unlockedSkills", "");
        if (!skills.isBlank()) {
            for (String skill : skills.split(",")) {
                String id = skill.trim();
                if (!id.isEmpty()) profile.unlockedSkills.add(id);
            }
        }
        return profile;
    }

    public void save(PlayerProfile profile) throws IOException {
        Objects.requireNonNull(profile.uuid, "profile.uuid");
        Files.createDirectories(directory);
        Properties p = new Properties();
        p.setProperty("dataVersion", Integer.toString(PlayerProfile.DATA_VERSION));
        p.setProperty("lastKnownName", profile.lastKnownName == null ? "" : profile.lastKnownName);
        p.setProperty("coins", Long.toString(profile.coins));
        p.setProperty("crystals", Long.toString(profile.crystals));
        p.setProperty("lifetimeCredits", Long.toString(profile.lifetimeCredits));
        p.setProperty("level", Integer.toString(profile.level));
        p.setProperty("xp", Long.toString(profile.xp));
        p.setProperty("skillPoints", Integer.toString(profile.skillPoints));
        p.setProperty("prestige", Integer.toString(profile.prestige));
        p.setProperty("specialization", profile.specialization == null ? "NONE" : profile.specialization);
        p.setProperty("kills", Long.toString(profile.kills));
        p.setProperty("deaths", Long.toString(profile.deaths));
        p.setProperty("assists", Long.toString(profile.assists));
        p.setProperty("damageDealt", Long.toString(profile.damageDealt));
        p.setProperty("shotsFired", Long.toString(profile.shotsFired));
        p.setProperty("shotsHit", Long.toString(profile.shotsHit));
        p.setProperty("bestKillStreak", Integer.toString(profile.bestKillStreak));
        p.setProperty("roundsPlayed", Long.toString(profile.roundsPlayed));
        p.setProperty("roundsWon", Long.toString(profile.roundsWon));
        p.setProperty("playTimeSeconds", Long.toString(profile.playTimeSeconds));
        p.setProperty("unlockedSkills", String.join(",", profile.unlockedSkills));

        Path target = file(profile.uuid);
        Path temp = target.resolveSibling(target.getFileName() + ".tmp");
        try (Writer writer = Files.newBufferedWriter(temp)) {
            p.store(writer, "Gunner Arena player profile");
        }
        try {
            Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ex) {
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private Path file(UUID uuid) { return directory.resolve(uuid.toString() + ".properties"); }

    private static int intValue(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, Integer.toString(fallback))); }
        catch (NumberFormatException ex) { return fallback; }
    }
    private static long longValue(Properties p, String key, long fallback) {
        try { return Math.max(0, Long.parseLong(p.getProperty(key, Long.toString(fallback)))); }
        catch (NumberFormatException ex) { return fallback; }
    }
}

package arena.loadout;

import arena.economy.CurrencyService;
import arena.profile.RoundSession;
import arena.weapon.WeaponCatalog;
import arena.weapon.WeaponDefinition;

public final class LoadoutManager {
    public enum BuyResult { OK, UNKNOWN_WEAPON, UNAVAILABLE_ITEM, NOT_ENOUGH_CREDITS }
    private final WeaponCatalog catalog;
    private final CurrencyService currencies;

    public LoadoutManager(WeaponCatalog catalog, CurrencyService currencies) {
        this.catalog = catalog;
        this.currencies = currencies;
    }

    public BuyResult buy(RoundSession s, String weaponId) {
        WeaponDefinition w = catalog.get(weaponId);
        if (w == null) return BuyResult.UNKNOWN_WEAPON;
        if (!currencies.spendCredits(s, w.price())) return BuyResult.NOT_ENOUGH_CREDITS;
        if (w.slot() == WeaponDefinition.Slot.PRIMARY) s.setPrimaryWeapon(w.id());
        else s.setSecondaryWeapon(w.id());
        s.setReserveAmmo(w.ammoItem(), Math.max(s.reserveAmmo(w.ammoItem()), w.startingReserve()));
        return BuyResult.OK;
    }

    /** Round loadout survives death; reserve is capped to one emergency magazine per owned weapon. */
    public void onRespawn(RoundSession s) {
        restoreEmergencyReserve(s, s.primaryWeapon());
        restoreEmergencyReserve(s, s.secondaryWeapon());
    }

    private void restoreEmergencyReserve(RoundSession s, String weaponId) {
        if (weaponId == null) return;
        WeaponDefinition w = catalog.get(weaponId);
        if (w == null || w.ammoItem() == null || w.ammoItem().isBlank()) return;
        int emergency = Math.max(1, w.magazineSize());
        if (s.reserveAmmo(w.ammoItem()) < emergency) s.setReserveAmmo(w.ammoItem(), emergency);
    }
}

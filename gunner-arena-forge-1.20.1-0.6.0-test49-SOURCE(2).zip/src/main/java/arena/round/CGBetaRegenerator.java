package arena.round;

/** Pure state machine; Forge adapter supplies scoreboard/entity snapshots and executes trigger. */
public final class CGBetaRegenerator {
    public enum State { IDLE, STARTING, GENERATING, FINALIZING, READY, ERROR }
    private State state = State.IDLE;
    private long startedTick = -1;
    private long lastProgressTick = -1;
    private int lastProgress = -1;
    private boolean generationObserved;
    public static final int EXPECTED_CHUNKS = 64;
    public static final int DEFAULT_TIMEOUT_TICKS = 20 * 60;

    public State state() { return state; }

    public void begin(long tick) {
        state = State.STARTING;
        startedTick = tick;
        lastProgressTick = tick;
        lastProgress = -1;
        generationObserved = false;
    }

    public State update(CGBetaSnapshot s, long tick) {
        if (state == State.IDLE || state == State.READY || state == State.ERROR) return state;
        int progress = normalizedProgress(s);
        if (progress > lastProgress) { lastProgress = progress; lastProgressTick = tick; }
        if (s.hasGeneratorMarkers() || s.cgChunkCount() > 0) generationObserved = true;
        if (state == State.STARTING && generationObserved) state = State.GENERATING;

        boolean countersDone = s.cgChunkCount() >= EXPECTED_CHUNKS
            && s.emptyCount() >= s.emptyMax()
            && s.gunCount() >= s.gunMax()
            && s.healthCount() >= s.healthMax();
        boolean chunksDone = s.unfinishedChunks() == 0;

        if (generationObserved && countersDone && chunksDone) {
            state = State.FINALIZING;
            // One stable tick after completion is enough for the Forge adapter to restore our entities.
            state = State.READY;
            return state;
        }
        if (tick - startedTick > DEFAULT_TIMEOUT_TICKS || tick - lastProgressTick > 20 * 30) {
            state = State.ERROR;
        }
        return state;
    }

    public static int normalizedProgress(CGBetaSnapshot s) {
        int a = Math.min(EXPECTED_CHUNKS, Math.max(0, s.cgChunkCount()));
        int b = ratioUnits(s.emptyCount(), s.emptyMax(), 16);
        int c = ratioUnits(s.gunCount(), s.gunMax(), 10);
        int d = ratioUnits(s.healthCount(), s.healthMax(), 4);
        int denom = EXPECTED_CHUNKS + 16 + 10 + 4;
        return Math.min(100, Math.max(0, (a + b + c + d) * 100 / denom));
    }
    private static int ratioUnits(int n, int max, int units) {
        if (max <= 0) return 0;
        return Math.min(units, Math.max(0, n) * units / max);
    }
}

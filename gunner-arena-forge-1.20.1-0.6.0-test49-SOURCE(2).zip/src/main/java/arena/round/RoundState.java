package arena.round;
public enum RoundState { WAITING, PLAYING, REGENERATING, PAUSED, ERROR }

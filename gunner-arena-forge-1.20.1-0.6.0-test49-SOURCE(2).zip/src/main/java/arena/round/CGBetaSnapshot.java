package arena.round;
public record CGBetaSnapshot(
    int cgChunkCount,
    int emptyCount, int emptyMax,
    int gunCount, int gunMax,
    int healthCount, int healthMax,
    int unfinishedChunks,
    boolean hasGeneratorMarkers
) {}

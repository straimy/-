package arena.round;

public final class RoundManager {
    private RoundState state = RoundState.WAITING;
    private int roundNumber;
    private int remainingTicks;
    private int configuredRoundTicks = 20 * 60 * 5;
    private final CGBetaRegenerator generator = new CGBetaRegenerator();

    public RoundState state() { return state; }
    public int roundNumber() { return roundNumber; }
    public int remainingTicks() { return remainingTicks; }
    public CGBetaRegenerator generator() { return generator; }

    public void startPlaying() {
        roundNumber++;
        remainingTicks = configuredRoundTicks;
        state = RoundState.PLAYING;
    }
    public void beginRegeneration(long tick) {
        state = RoundState.REGENERATING;
        generator.begin(tick);
    }
    public void tickPlaying() {
        if (state != RoundState.PLAYING) return;
        if (remainingTicks > 0) remainingTicks--;
    }
    public void onGeneratorState(CGBetaRegenerator.State gs) {
        if (state != RoundState.REGENERATING) return;
        if (gs == CGBetaRegenerator.State.READY) state = RoundState.WAITING;
        else if (gs == CGBetaRegenerator.State.ERROR) state = RoundState.ERROR;
    }
    public void setRoundSeconds(int seconds) { configuredRoundTicks = Math.max(20, seconds * 20); }
    public void pause() { if (state == RoundState.PLAYING) state = RoundState.PAUSED; }
    public void resume() { if (state == RoundState.PAUSED) state = RoundState.PLAYING; }
}

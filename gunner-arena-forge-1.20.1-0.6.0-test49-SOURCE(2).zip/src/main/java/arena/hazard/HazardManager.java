package arena.hazard;

import arena.region.SafeRegionRegistry;
import java.util.*;

/**
 * Pure server-authoritative lifecycle for temporary admin hazards.
 * World effects are executed only by the Forge adapter. This class never mutates blocks.
 */
public final class HazardManager {
    public static final int MAX_ACTIVE_DEFAULT = 20;

    private final SafeRegionRegistry safeRegions;
    private final int maxActive;
    private final LinkedHashMap<UUID, ActiveHazard> active = new LinkedHashMap<>();

    public HazardManager(SafeRegionRegistry safeRegions) {
        this(safeRegions, MAX_ACTIVE_DEFAULT);
    }

    public HazardManager(SafeRegionRegistry safeRegions, int maxActive) {
        this.safeRegions = Objects.requireNonNull(safeRegions);
        if (maxActive < 1) throw new IllegalArgumentException("maxActive");
        this.maxActive = maxActive;
    }

    public synchronized ActiveHazard spawn(String dimension, HazardSpec spec, long nowTick) {
        if (safeRegions.containing(dimension, spec.x(), spec.y(), spec.z()) != null) {
            throw new IllegalStateException("Hazards are forbidden inside a safe region");
        }
        cleanup(nowTick);
        if (active.size() >= maxActive) {
            throw new IllegalStateException("Too many active hazards");
        }
        ActiveHazard hazard = new ActiveHazard(spec, nowTick);
        active.put(hazard.id(), hazard);
        return hazard;
    }

    public synchronized int cleanup(long nowTick) {
        int before = active.size();
        active.values().removeIf(h -> h.expired(nowTick));
        return before - active.size();
    }

    public synchronized void clear() { active.clear(); }
    public synchronized int size() { return active.size(); }
    public synchronized List<ActiveHazard> all() { return List.copyOf(active.values()); }

    public boolean mayDamage(String dimension, double x, double y, double z) {
        return safeRegions.containing(dimension, x, y, z) == null;
    }
}

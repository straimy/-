package arena.hazard;

/** Central balance presets for temporary, non-destructive admin hazards. */
public final class HazardPresets {
    private HazardPresets() {}

    public static HazardSpec at(HazardType type, double x, double y, double z) {
        return switch (type) {
            case TNT_DROP      -> new HazardSpec(type, x, y, z, 7.0, 12.0, 20 * 6);
            case METEOR        -> new HazardSpec(type, x, y, z, 9.0, 15.0, 20 * 8);
            case WEB_BOMB      -> new HazardSpec(type, x, y, z, 5.0,  0.0, 20 * 5);
            case SHOCKWAVE     -> new HazardSpec(type, x, y, z, 8.0,  5.0, 20 * 3);
            case SMOKE         -> new HazardSpec(type, x, y, z, 7.0,  0.0, 20 * 12);
            case CRYO          -> new HazardSpec(type, x, y, z, 6.0,  3.0, 20 * 5);
            case GRAVITY_PULSE -> new HazardSpec(type, x, y, z, 8.0,  4.0, 20 * 4);
        };
    }
}

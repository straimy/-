package arena.hazard;

/** Non-destructive admin event types. World-block mutation is forbidden by contract unless temporary restoration is explicit. */
public enum HazardType {
    TNT_DROP,
    METEOR,
    WEB_BOMB,
    SHOCKWAVE,
    SMOKE,
    CRYO,
    GRAVITY_PULSE
}

package arena.hazard;

/** Server-authoritative hazard request; the Forge renderer/executor is transient and never persisted. */
public record HazardSpec(HazardType type, double x, double y, double z,
                         double radius, double damage, int lifetimeTicks) {
    public HazardSpec {
        if (type == null) throw new IllegalArgumentException("type");
        if (radius < 0 || damage < 0 || lifetimeTicks <= 0) throw new IllegalArgumentException("invalid hazard values");
    }
}

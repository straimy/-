package arena.hazard;

import java.util.UUID;

/** Runtime-only hazard instance. Never persisted between server restarts or arena regenerations. */
public final class ActiveHazard {
    private final UUID id;
    private final HazardSpec spec;
    private final long createdTick;
    private long expiresTick;

    public ActiveHazard(HazardSpec spec, long createdTick) {
        this(UUID.randomUUID(), spec, createdTick, createdTick + spec.lifetimeTicks());
    }

    public ActiveHazard(UUID id, HazardSpec spec, long createdTick, long expiresTick) {
        this.id = id;
        this.spec = spec;
        this.createdTick = createdTick;
        this.expiresTick = expiresTick;
    }

    public UUID id() { return id; }
    public HazardSpec spec() { return spec; }
    public long createdTick() { return createdTick; }
    public long expiresTick() { return expiresTick; }
    public boolean expired(long nowTick) { return nowTick >= expiresTick; }
    public int remainingTicks(long nowTick) { return (int)Math.max(0, expiresTick - nowTick); }
    public void expireNow(long nowTick) { this.expiresTick = nowTick; }
}

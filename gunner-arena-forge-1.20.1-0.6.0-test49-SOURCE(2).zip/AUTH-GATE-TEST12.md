# TEST12 Auth Gate

Audited current SAuth-2.0.0.jar from the server archive.

Current 2.0.0 behavior before auth:
- adds UUID to an unauthenticated set on join;
- teleports the player to their *current* coordinates every tick (freezes in place, does NOT force lobby spawn);
- blocks RightClickBlock;
- sets BreakSpeed to 0;
- blocks AttackEntityEvent;
- does not globally block other commands, so Gunner Arena commands such as /play or /buy could still be parsed/executed;
- does not cover every item/entity interaction path.

TEST12 contract for SAuth 2.1+:
- unauthenticated player has no `sauth_authenticated` scoreboard tag;
- successful /login or /register adds `sauth_authenticated`;
- logout/join removes it again;
- SAuth blocks every command except /login and /register while locked;
- Gunner Arena independently refuses all its commands for locked players;
- Gunner Arena keeps locked players at its configured lobby spawn and does not open a PlayerProfile/RoundSession until authentication succeeds.

# Gunner Arena 0.6.0-test9 — Forge runtime/API audit

This is a pre-ForgeGradle audit. The pure Java core passes Java 17 compilation. Forge-bound code still requires a real Forge 1.20.1 / 47.4.10 build and dedicated-server runtime test before the mod is installable.

## Changes made during audit

1. CG BETA trigger is now pulsed AIR -> REDSTONE_BLOCK so a stale powered trigger cannot silently prevent the next generation cycle.
2. Arena damage/assist tracking only records ALIVE arena players during PLAYING.
3. Lobby/non-arena deaths no longer award kills/assists or mutate arena death stats.
4. Spawn-protection offensive cancellation now resolves indirect/projectile attackers through the same DamageSource resolver used for kills.
5. READY generation now schedules a five-second pre-round grace period, then automatically starts the next round. This closes the previous state-machine gap where READY could leave the server in WAITING forever.
6. Starting regeneration cancels any pending automatic round start.
7. Round reset removes arena-bound items even if players moved them out of slots 1-3.
8. Round reset clears ammo types managed by WeaponCatalog so reserve ammo cannot carry into the next round.
9. Emergency ammo restoration never drops overflow ammo entities on the ground.
10. DamageTracker can explicitly discard stale damage contributions without awarding assists.

## Still requires live Forge/JEG verification

- Exact Forge event signatures after ForgeGradle mapping.
- JEG DamageSource ownership for every gun/projectile type.
- Whether JEG consumes registry ammo items exactly as expected for all configured weapons.
- CG BETA trigger/reset behavior on the live map for at least 3 consecutive cycles.
- Scoreboard READY counters on the actual server world.
- ItemTossEvent behavior with JEG weapon stacks.
- Respawn timing relative to auth/login and any other installed server mods.
- Server-only client compatibility with the final built jar.

## Runtime acceptance gate

Do not promote test9 to a public server build until:

- server reaches Done;
- normal client can join without Gunner Arena Core;
- no Invalid player data / command tree errors;
- /ga debug round and /ga debug generator work;
- /addspawn, /play, death and respawn work;
- economy and /buy work with real JEG items;
- ammo points work with real JEG ammo;
- 3 consecutive timed CG BETA regeneration cycles complete and auto-start the following round.

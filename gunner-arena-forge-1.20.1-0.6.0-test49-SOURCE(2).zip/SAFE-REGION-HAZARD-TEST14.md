# Gunner Arena 0.6.0-test14 — Safe Region + Hazard contracts

## Implemented in pure/source layer
- Atomic persistent cuboid safe regions (`safe-regions.properties`).
- Region containment independent of entities/markers, so CG BETA marker cleanup cannot erase regions.
- Non-destructive hazard type/spec contract for TNT drop, meteor, web bomb, shockwave, smoke, cryo and gravity pulse.

## Forge adapter still required before runtime claim
- `/spawnregion pos1|pos2|create|remove|list|show` commands and optional wand.
- Cancel damage/death/projectiles/weapon use inside safe regions.
- Temporarily hide arena-bound weapons while inside safe region without duplicating ammo on restore.
- Prevent AI target acquisition inside safe regions.
- Transient hazard executor with TTL and SafeRegion immunity.
- Prefix/team rendering (`PLAYER`/`ADMIN`) and custom KVICloud join/leave message.

These items are NOT claimed runtime-tested until ForgeGradle + dedicated server are available.

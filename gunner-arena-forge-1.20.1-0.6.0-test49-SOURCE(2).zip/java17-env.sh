#!/usr/bin/env bash
# May be sourced by build-forge17.sh or executed directly for diagnostics.
set -euo pipefail

_ga_finish() {
  local code="$1"
  if [[ "${BASH_SOURCE[0]}" != "$0" ]]; then
    return "$code"
  fi
  exit "$code"
}

CANDIDATES=()
[[ -n "${JAVA_HOME_17:-}" ]] && CANDIDATES+=("$JAVA_HOME_17")
[[ -n "${JAVA_HOME:-}" ]] && CANDIDATES+=("$JAVA_HOME")
CANDIDATES+=(
  /usr/lib/jvm/temurin-17-jdk-amd64
  /usr/lib/jvm/java-17-openjdk-amd64
  /usr/lib/jvm/jdk-17
  /opt/java/openjdk
  /opt/jdk-17
)

for home in "${CANDIDATES[@]}"; do
  [[ -x "$home/bin/java" ]] || continue
  major="$($home/bin/java -XshowSettings:properties -version 2>&1 | awk -F'= ' '/^[[:space:]]*java.version = /{print $2; exit}' | sed 's/^1\.//' | cut -d. -f1)"
  if [[ "$major" == "17" ]]; then
    export JAVA_HOME="$home"
    export PATH="$JAVA_HOME/bin:$PATH"
    echo "[GA JAVA] Using Java 17 from $JAVA_HOME"
    java -version
    _ga_finish 0
    return 0 2>/dev/null || exit 0
  fi
done

echo '[GA JAVA] JDK 17 not found.' >&2
echo '[GA JAVA] Set JAVA_HOME_17 to a JDK 17 directory, or switch the Pterodactyl image to Java 17.' >&2
_ga_finish 17
return 17 2>/dev/null || exit 17

# Client UI finalize — test39

Status: SOURCE implementation only. Forge compile/runtime is still unproven until the official 1.20.1 / Forge 47.4.10 Java 17 build is run.

Changes:
- common MAIN / SHOP / PROFILE navigation bar across every Arena screen;
- Escape from SHOP/PROFILE returns to MAIN; Escape on MAIN closes the Arena UI;
- no nested Screen parent chain is retained between repeated navigation;
- Profile requests a fresh server snapshot and has explicit stale/auth/init states;
- Main requests a snapshot itself instead of relying on the caller to have done so;
- the F8 developer opener is disabled by default and only registers when JVM property `-Dgunnerarena.ui.devKey=true` is present;
- normal production entry path remains server-driven `OpenUiPacket` (`/menu`, `/shop`, `/profile`, later NPC interaction).

Client UI is now considered SOURCE COMPLETE for the currently scoped UI: fullscreen main screen, shop, profile, responsive layout, server snapshots, server-authoritative purchases, stale-state protection, server-driven opening, navigation, and disconnect cache cleanup. Visual resource-pack art and live Forge validation remain integration/runtime work rather than missing UI source behavior.

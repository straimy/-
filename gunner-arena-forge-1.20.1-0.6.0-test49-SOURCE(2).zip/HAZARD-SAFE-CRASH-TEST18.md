# Gunner Arena 0.6.0-test18 — source stage

Implemented in source (NOT live-installed):
- non-destructive hazard runtime presets and Forge executor: meteor, TNT drop, web, shockwave, smoke, cryo, gravity pulse;
- `/hazard <type>` + `/hazard clear` command registration for OPs;
- hazards are forbidden in SafeRegion and cleared when CG BETA regeneration starts/server stops;
- SafeRegion players get hard damage/death/fire protection plus enter/leave actionbar;
- JEG `jeg:flare_gun` quarantine upgraded from shop-only to inventory scrub + right-click fence, reducing the chance that `/give` or stale inventory can respawn the confirmed crashing FlareProjectileEntity;
- KVICloud prefix component builder is present for later TAB/nameplate wiring.

Validation status:
- pure Java 17 core gate: required;
- ForgeGradle compile: NOT YET run in this container;
- dedicated server runtime: NOT YET run.

# Gunner Arena 0.6.0-test2 source branch

Target: Minecraft 1.20.1, Forge 47.4.10, Java 17.

This branch replaces the old reflection/proxy command registration with normal typed Forge/Brigadier handlers.
Initial test scope:
- mod load/login event
- `/ga debug round`
- `/ga debug generator`
- `/ga generator start`
- `/round status|start|restart|time`
- actual CG BETA redstone input at 44 63 3
- scoreboard + marker based generator READY/error state

Do not deploy a jar until `gradlew build` succeeds against the official Forge 47.4.10 MDK and a dedicated-server smoke test passes.

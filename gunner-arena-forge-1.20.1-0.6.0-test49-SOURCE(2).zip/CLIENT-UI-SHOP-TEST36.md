# Gunner Arena test36 — server-authoritative weapon shop

- Protocol bumped to v2 and now carries catalog, buy request and buy result packets.
- Client sends only a bounded weapon id. Server owns price, slot, ammo, availability and quarantine decisions.
- Core rejects purchases before auth/init, outside PLAYING, while not ALIVE, for quarantined/unregistered ids, insufficient Credits, and rapid spam.
- Catalog marks planned Gunner Arena weapons unavailable until their actual Item is registered.
- UI renders categories, server prices, weapon details, availability state and purchase result.
- Successful purchase refreshes both snapshot and catalog.
- This is source-complete only; Forge 47.4.10 compile/runtime is still required before calling it tested.

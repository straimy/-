#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>
#moj_import <../config.txt>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;
uniform sampler2D Sampler0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ChunkOffset;
uniform float GameTime;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec4 lightColor;
out vec2 texCoord0;
out vec4 normal;
out vec4 glpos;

float rsin(float i, float Wave) {
  return (sin(i) + sin(2 * i) + sin(3 * i) + 2 * sin(3 * i - 3) - 0.15) / 2.22 * sin(i / 2.71) * Wave;
}

float rtan(float i, float Wave) {
  return (sin(i) + sin(2 * i) + sin(3 * i) + 2 * sin(3 * i - 3) + 0.25) / 1.45 * sin(i / 2.71) * Wave;
}

float rcos(float i, float Wave) {
  return (cos(i) + cos(2 * i) + cos(3 * i) + 2 * cos(3 * i - 3) + 0.2) / 1.91 * cos(i / 2.71) * Wave;
}

void wave_render(vec3 position, float waveStrength, float waveSpeed, float waveHeight) {
	float xs = 0.0;
	float ys = 0.0;
	float zs = 0.0;
	xs = rsin((position.x + position.y + waveSpeed) / 2, waveStrength) * -1;
	ys = rtan((position.x + position.y - position.z + waveSpeed) / 2, waveStrength) * waveHeight;
	zs = rcos((position.z + position.y + waveSpeed) / 2, waveStrength) * -1;
	vec4 wavedPos = vec4(position, 1) + vec4(xs / 32, (ys - (waveStrength * (waveHeight * 1.2))) / 32, zs / 32, 0);
	gl_Position = ProjMat * ModelViewMat * wavedPos;
	vertexDistance = fog_distance(wavedPos.xyz, FogShape);
	texCoord0 = UV0;
}

void default_render(vec3 position) {
    gl_Position = ProjMat * ModelViewMat * vec4(position, 1);
    vertexDistance = fog_distance(position, FogShape);
	texCoord0 = UV0;
}

void main() {
    vec3 position = Position + ChunkOffset;
	
	#if defined(Waving_Water) || defined(Waving_Lava) || defined(Dynamic_Slopes)
	if (Waving_Water > 0 || Waving_Lava > 0 || Dynamic_Slopes == true ) {
		int alpha = int(textureLod(Sampler0, UV0, 0).a * 255 + 0.5);
		float waveSpeed = 4000 * GameTime;
		float waveHeight = 0.5; 
        if ( Waving_Water > 0 && alpha == 200 ) { //Cauldron Water
			float waveStrength = Waving_Water; 
			float waveSpeed = 4000 * GameTime;
			float waveHeight = 2; 
			wave_render(position, waveStrength, waveSpeed, waveHeight);
		} else if (Waving_Lava > 0 && alpha == 254 ) { //Lava + Lava Cauldron
			float waveStrength = Waving_Lava; 
			float waveSpeed = 2000 * GameTime;
			float waveHeight = 2; 
			wave_render(position, waveStrength, waveSpeed, waveHeight);
		} else if (Optifine == false && Dynamic_Slopes == true && (alpha == 253 || alpha == 252 || alpha == 251)) { //Dynamic Snow 
			vec3 Pos = Position;
			vertexColor = Color * minecraft_sample_lightmap(Sampler2, UV2);
			texCoord0 = UV0;
			normal = ProjMat * ModelViewMat * vec4(Normal, 0);
			const vec2[4] corners = vec2[4](vec2(0), vec2(0, 1), vec2(1, 1), vec2(1, 0));
			vec2 corner = corners[gl_VertexID % 4];
			if ((alpha == 253 || alpha == 252) && Normal.y > 0) {
				float col = Color.r;
				float slope_offset = clamp((1 - col), 0, ceil(Position.y) - Position.y);
				if (alpha == 253) {
					float elevation = 1 - slope_offset - fract(Position.y);
					texCoord0.y -= elevation * 16 / textureSize(Sampler0, 0).y;
				}
				Pos += vec3(0, 1, 0) * slope_offset;
			} else if (alpha == 251) {
				Pos.y = floor(Pos.y);
			}
			gl_Position = ProjMat * ModelViewMat * vec4(Pos + ChunkOffset, 1);
			vertexDistance = fog_distance(Pos + ChunkOffset, FogShape);
		} else {
			default_render(position);
		}
	} 
	#else
		default_render(position);
	#endif
	
	vertexColor = Color;
	lightColor = minecraft_sample_lightmap(Sampler2, UV2);
	normal = ProjMat * ModelViewMat * vec4(Normal, 0);
	glpos = gl_Position;
}

#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>
#moj_import <../config.txt>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ChunkOffset;
uniform float GameTime;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec4 normal;

float rsin(float i, float Wave) {
  return (sin(i) + sin(2 * i) + sin(3 * i) + 2 * sin(3 * i - 3) - 0.15) / 2.22 * sin(i / 2.71) * Wave;
}

float rtan(float i, float Wave) {
  return (sin(i) + sin(2 * i) + sin(3 * i) + 2 * sin(3 * i - 3) + 0.25) / 1.45 * sin(i / 2.71) * Wave;
}

float rcos(float i, float Wave) {
  return (cos(i) + cos(2 * i) + cos(3 * i) + 2 * cos(3 * i - 3) + 0.2) / 1.91 * cos(i / 2.71) * Wave;
}

void wave_render(vec3 position, float waveStrength, float waveSpeed, float waveHeight) {
	float xs = 0;
	float ys = 0;
	float zs = 0;
	xs = rsin((position.x + position.y + waveSpeed) / 2, waveStrength) * -1;
	ys = rtan((position.x + position.y - position.z + waveSpeed) / 2, waveStrength) * waveHeight;
	zs = rcos((position.z + position.y + waveSpeed) / 2, waveStrength) * -1;
	vec4 wavedPos = vec4(position, 1) + vec4(xs / 32, (ys - (waveStrength * (waveHeight * 1.2))) / 32, zs / 32, 0);
	gl_Position = ProjMat * ModelViewMat * wavedPos;
	vertexDistance = fog_distance(wavedPos.xyz, FogShape);
	texCoord0 = UV0;
}

void default_render(vec3 position) {
	gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);
	vertexDistance = length((ModelViewMat * vec4(Position + ChunkOffset, 1.0)).xyz);
}


void main() {
    vec3 position = Position + ChunkOffset;
	vec4 color = texture(Sampler0, UV0);
	
	#if defined(Waving_Objects)
		int alpha = int(textureLod(Sampler0, UV0, 0).a * 255 + 0.5);
		float waveSpeed = 4000 * GameTime;
		float waveHeight = 0.5; 
        if (Waving_Objects > 0 && alpha == 25 ) { //Tripwire
			float waveStrength = Waving_Objects; 
			wave_render(position, waveStrength, waveSpeed, waveHeight);		
        } else {
			default_render(position);
		}
	#else
		default_render(position);
	#endif

    vertexDistance = fog_distance(position, FogShape);
    vertexColor = Color * minecraft_sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
    normal = ProjMat * ModelViewMat * vec4(Normal, 0.0);
}

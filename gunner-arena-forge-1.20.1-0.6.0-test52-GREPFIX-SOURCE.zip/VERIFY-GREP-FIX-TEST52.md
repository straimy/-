# test52 grep-fix

Fixes the test51 source gate crash:

    grep: Unmatched ) or \)

Cause: the ForgeGradle version assertion used a malformed BRE regex.
Fix: use fixed-string matching (`grep -Fq`) for the exact plugins DSL declaration.

No gameplay logic changed.
